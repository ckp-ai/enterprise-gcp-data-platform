-- Purpose: Normalize the Cloud Billing detailed export behind a stable enterprise view.
-- Prerequisites: Cloud Billing detailed usage export enabled; target project/dataset created; BigQuery permissions granted.
-- Configuration: Replace BILLING_PROJECT, BILLING_DATASET and BILLING_ACCOUNT; set the retained lookback to the approved policy.
-- Error handling: Deployment pipeline must fail when placeholders remain or source fields are unavailable in the current export schema.
-- Logging: Record deployment job ID, source table suffix, row count and reconciliation result in the FinOps release-evidence table.
-- Security considerations: Treat raw billing data as Confidential; restrict source access and publish only authorized curated views.
-- Testing instructions: Reconcile daily and invoice-month net totals to Cloud Billing reports, allowing documented export latency and adjustments.
-- Deployment instructions: Deploy through reviewed BigQuery DDL in the controlled FinOps pipeline after schema compatibility tests.
-- Rollback instructions: Restore the prior view definition from version control; do not delete the raw export dataset.
-- Production limitations: Export fields and latency can change; validate current documentation, dataset location and contractual credits before use.
CREATE OR REPLACE VIEW `finops_curated.v_cost_line_item` AS
SELECT
  DATE(usage_start_time) AS usage_date,
  invoice.month AS invoice_month,
  billing_account_id,
  project.id AS project_id,
  project.name AS project_name,
  service.description AS service_name,
  sku.description AS sku_name,
  location.region AS region,
  currency,
  cost AS gross_cost,
  IFNULL((SELECT SUM(c.amount) FROM UNNEST(credits) c), 0) AS credits,
  cost + IFNULL((SELECT SUM(c.amount) FROM UNNEST(credits) c), 0) AS net_cost,
  ARRAY_TO_STRING(
    ARRAY(SELECT CONCAT(k.key, '=', k.value) FROM UNNEST(labels) k ORDER BY k.key),
    ';'
  ) AS resource_labels,
  _PARTITIONTIME AS export_partition_time
FROM `BILLING_PROJECT.BILLING_DATASET.gcp_billing_export_resource_v1_BILLING_ACCOUNT`
WHERE DATE(usage_start_time) >= DATE_SUB(CURRENT_DATE(), INTERVAL 400 DAY);
