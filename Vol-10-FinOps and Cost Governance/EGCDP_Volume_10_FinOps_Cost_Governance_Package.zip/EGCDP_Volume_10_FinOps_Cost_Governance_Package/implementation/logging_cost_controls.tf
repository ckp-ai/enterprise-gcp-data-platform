# Purpose: Exclude only approved low-value application noise while preserving required audit and incident evidence.
# Prerequisites: Logging policy, data-classification assessment, security approval, test project and current log-volume baseline.
# Configuration: Supply project ID and approved filter; the example targets low-severity health-check request logs only.
# Error handling: Policy tests fail changes that match protected audit/security log names or remove all evidence for a regulated service.
# Logging: Retain exclusion configuration changes and compare log-volume, alert coverage and incident evidence before/after deployment.
# Security considerations: Never exclude mandatory Admin Activity, Policy Denied, regulated Data Access or security-detection evidence for savings alone.
# Testing instructions: Run positive and negative filter tests, alert regression tests and representative incident investigations.
# Deployment instructions: Apply through security-approved IaC with a time-bounded observation period and named owner.
# Rollback instructions: Disable/remove the exclusion and verify ingestion recovery; note that previously excluded entries cannot be reconstructed.
# Production limitations: Filter semantics and service log fields can change; revalidate quarterly and after workload releases.

variable "project_id" {
  type = string
}

resource "google_logging_project_exclusion" "healthcheck_noise" {
  project     = var.project_id
  name        = "exclude-approved-healthcheck-noise"
  description = "Approved low-value application health-check exclusion; review quarterly and after service changes."
  filter      = "resource.type=\"cloud_run_revision\" AND httpRequest.requestUrl:\"/healthz\" AND severity<WARNING"
}
