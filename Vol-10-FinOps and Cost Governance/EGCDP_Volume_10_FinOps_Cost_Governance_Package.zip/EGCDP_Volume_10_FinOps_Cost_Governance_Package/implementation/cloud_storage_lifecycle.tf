# Purpose: Apply evidence-based Cloud Storage lifecycle controls without embedding current product prices.
# Prerequisites: Approved retention/legal-hold policy, bucket project/location, data-access pattern and storage-class economic model.
# Configuration: Supply transition ages, deletion age and storage classes from the approved policy; example defaults are assumptions only.
# Error handling: CI rejects deletion ages that precede transitions or violate the minimum approved retention period.
# Logging: Retain Terraform changes and monitor lifecycle configuration, object age/class distributions and deletion events.
# Security considerations: Uniform bucket-level access is required; legal hold, retention lock and privacy requirements override cost-only changes.
# Testing instructions: Use nonproduction objects, validate rule ordering and test restore/retrieval and minimum-duration implications.
# Deployment instructions: Apply through controlled IaC after data-owner, records-management, privacy and SRE approval.
# Rollback instructions: Restore the prior lifecycle configuration; deleted objects may not be recoverable without versioning/retention controls.
# Production limitations: Lifecycle actions are asynchronous; storage-class pricing and minimum-duration terms require current calculator validation.

variable "bucket_name" {
  type = string
}
variable "project_id" {
  type = string
}
variable "location" {
  type = string
}
variable "nearline_after_days" {
  type    = number
  default = 30
}
variable "coldline_after_days" {
  type    = number
  default = 90
}
variable "archive_after_days" {
  type    = number
  default = 365
}
variable "delete_after_days" {
  type = number
}

resource "google_storage_bucket" "archive" {
  name                        = var.bucket_name
  project                     = var.project_id
  location                    = var.location
  uniform_bucket_level_access = true

  versioning { enabled = true }

  lifecycle_rule {
    condition { age = var.nearline_after_days }
    action {
      type          = "SetStorageClass"
      storage_class = "NEARLINE"
    }
  }
  lifecycle_rule {
    condition { age = var.coldline_after_days }
    action {
      type          = "SetStorageClass"
      storage_class = "COLDLINE"
    }
  }
  lifecycle_rule {
    condition { age = var.archive_after_days }
    action {
      type          = "SetStorageClass"
      storage_class = "ARCHIVE"
    }
  }
  lifecycle_rule {
    condition { age = var.delete_after_days }
    action { type = "Delete" }
  }

  lifecycle {
    precondition {
      condition = (
        var.nearline_after_days < var.coldline_after_days &&
        var.coldline_after_days < var.archive_after_days &&
        var.archive_after_days < var.delete_after_days
      )
      error_message = "Lifecycle ages must increase and deletion must occur last."
    }
  }
}
