"""Route budget or cost-anomaly notifications to the governed FinOps workflow.

Purpose: Parse a Pub/Sub-delivered notification and create an auditable escalation signal.
Prerequisites: Authenticated runtime, Pub/Sub subscription, sanitized notification schema and ticketing integration.
Configuration: Set LOG_LEVEL and ACK_THRESHOLD; map the current provider notification schema before deployment.
Error handling: Reject malformed messages so the platform retry/dead-letter policy can process them.
Logging: Emit structured identifiers, cost/budget values and routing outcome without secrets or sensitive billing metadata.
Security considerations: Use least-privilege workload identity, authenticated push or event delivery and secret-managed ticket credentials.
Testing instructions: Replay sanitized samples, malformed payloads and duplicates; verify idempotency and dead-letter behavior.
Deployment instructions: Package with pinned dependencies, deploy through CI/CD and bind only the required subscriber and ticket roles.
Rollback instructions: Route messages to the prior handler or email-only workflow while retaining the topic and audit history.
Production limitations: Notification schemas and anomaly event payloads require current validation; this sample omits a vendor-specific ticket client.
"""

import base64
import json
import logging
import os
from typing import Any

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
ACK_THRESHOLD = float(os.getenv("ACK_THRESHOLD", "0"))


def handle_pubsub(event: dict[str, Any], context: Any = None) -> None:
    """Handle one event; raise on invalid input so configured retries remain effective."""
    del context
    try:
        payload = event.get("data")
        if payload:
            message = json.loads(base64.b64decode(payload).decode("utf-8"))
        else:
            message = event

        cost = float(message.get("costAmount", message.get("cost", 0)) or 0)
        budget = float(message.get("budgetAmount", message.get("budget", 0)) or 0)
        ratio = cost / budget if budget else None
        event_key = str(
            message.get("anomalyId")
            or message.get("budgetDisplayName")
            or message.get("billingAccountId")
            or "unknown"
        )

        logging.info(
            "finops_notification key=%s cost=%s budget=%s ratio=%s",
            event_key,
            cost,
            budget,
            ratio,
        )
        if ratio is not None and ratio >= max(ACK_THRESHOLD, 1.0):
            # Replace with an idempotent ticket upsert keyed by event_key and accounting period.
            logging.warning("threshold_exceeded key=%s action=create_governed_ticket", event_key)
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        logging.exception("invalid_finops_notification error=%s", exc)
        raise
