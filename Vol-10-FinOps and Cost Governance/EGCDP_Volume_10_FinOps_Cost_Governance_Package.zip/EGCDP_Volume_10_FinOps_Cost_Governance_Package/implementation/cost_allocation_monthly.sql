-- Purpose: Produce a reproducible monthly direct and shared product-cost allocation.
-- Prerequisites: Normalized billing view, governed project-to-product map, approved allocation-driver table and target mart dataset.
-- Configuration: Set p_month or supply it from orchestration; define allocation policy thresholds in the pipeline configuration.
-- Error handling: Fail publication when source totals do not reconcile, required drivers are absent or unallocated cost exceeds policy.
-- Logging: Persist run ID, source watermark, allocation-policy version, row counts, reconciliation variance and approval status.
-- Security considerations: Restrict cost-center and owner mappings; expose product statements through authorized views or row policies.
-- Testing instructions: Test zero-driver handling, late credits, negative adjustments, duplicate mappings and total reconciliation.
-- Deployment instructions: Execute from the governed monthly FinOps workflow after billing-export completeness checks.
-- Rollback instructions: Retain the prior published partition and repoint the statement view to the last approved run.
-- Production limitations: Shared drivers are governance choices, not accounting facts; finance approval is required before chargeback posting.
DECLARE p_month STRING DEFAULT FORMAT_DATE('%Y%m', DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH));

CREATE OR REPLACE TABLE `finops_mart.monthly_product_cost`
PARTITION BY usage_month
CLUSTER BY business_unit, domain, data_product AS
WITH direct AS (
  SELECT
    FORMAT_DATE('%Y%m', usage_date) AS usage_month,
    COALESCE(m.business_unit, 'UNALLOCATED') AS business_unit,
    COALESCE(m.domain, 'UNALLOCATED') AS domain,
    COALESCE(m.data_product, 'UNALLOCATED') AS data_product,
    SUM(v.net_cost) AS direct_net_cost
  FROM `finops_curated.v_cost_line_item` v
  LEFT JOIN `finops_ref.project_product_map` m USING (project_id)
  WHERE FORMAT_DATE('%Y%m', usage_date) = p_month
  GROUP BY 1,2,3,4
),
shared_pool AS (
  SELECT SUM(net_cost) AS shared_cost
  FROM `finops_curated.v_cost_line_item` v
  JOIN `finops_ref.project_product_map` m USING (project_id)
  WHERE FORMAT_DATE('%Y%m', usage_date) = p_month
    AND m.allocation_model = 'SHARED_USAGE'
),
drivers AS (
  SELECT
    usage_month,
    business_unit,
    domain,
    data_product,
    SAFE_DIVIDE(driver_value, SUM(driver_value) OVER (PARTITION BY usage_month)) AS allocation_weight
  FROM `finops_ref.monthly_allocation_driver`
  WHERE usage_month = p_month
)
SELECT
  PARSE_DATE('%Y%m', d.usage_month) AS usage_month,
  d.business_unit,
  d.domain,
  d.data_product,
  d.direct_net_cost,
  s.shared_cost * IFNULL(r.allocation_weight, 0) AS shared_allocated_cost,
  d.direct_net_cost + s.shared_cost * IFNULL(r.allocation_weight, 0) AS total_allocated_cost,
  r.allocation_weight,
  CURRENT_TIMESTAMP() AS calculated_at
FROM direct d
LEFT JOIN drivers r USING (usage_month, business_unit, domain, data_product)
CROSS JOIN shared_pool s;
