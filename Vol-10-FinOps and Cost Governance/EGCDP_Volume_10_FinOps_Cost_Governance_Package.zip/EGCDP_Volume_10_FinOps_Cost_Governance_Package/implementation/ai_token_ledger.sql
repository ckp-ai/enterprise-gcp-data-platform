-- Purpose: Build quality-adjusted AI unit economics from governed runtime usage metadata.
-- Prerequisites: Request-usage ledger with approved model alias, token metadata, outcome classification and allocated net cost.
-- Configuration: Replace datasets; define accepted outcomes, quality gates and model-alias governance in reference tables.
-- Error handling: Quarantine rows with missing application/model identity or invalid token and cost values; fail if coverage drops below policy.
-- Logging: Persist run ID, source watermark, rejected-row count, model catalog version and billing reconciliation result.
-- Security considerations: Do not copy raw prompts, responses or retrieved sensitive content into the cost ledger.
-- Testing instructions: Reconcile request counts and token usage to runtime metadata and cost allocations; test cached-token and zero-outcome cases.
-- Deployment instructions: Run as a scheduled, versioned transformation after AI telemetry and cost allocation are complete.
-- Rollback instructions: Repoint the published view to the last approved partition and preserve rejected rows for investigation.
-- Production limitations: Token fields, caching semantics and model pricing dimensions vary by model and must be revalidated against current terms.
CREATE OR REPLACE TABLE `finops_mart.ai_daily_unit_cost`
PARTITION BY usage_date
CLUSTER BY ai_application, model_alias AS
SELECT
  DATE(request_timestamp) AS usage_date,
  ai_application,
  model_alias,
  SUM(input_tokens) AS input_tokens,
  SUM(output_tokens) AS output_tokens,
  SUM(cached_input_tokens) AS cached_input_tokens,
  COUNT(*) AS requests,
  COUNTIF(outcome = 'accepted') AS accepted_tasks,
  SUM(allocated_net_cost) AS allocated_net_cost,
  SAFE_DIVIDE(SUM(allocated_net_cost), COUNTIF(outcome = 'accepted')) AS cost_per_accepted_task,
  APPROX_QUANTILES(latency_ms, 100)[OFFSET(95)] AS p95_latency_ms
FROM `ai_ops.request_usage_ledger`
GROUP BY 1,2,3;
