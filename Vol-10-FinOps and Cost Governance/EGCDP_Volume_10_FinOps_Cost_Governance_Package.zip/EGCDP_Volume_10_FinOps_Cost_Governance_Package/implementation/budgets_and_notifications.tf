# Purpose: Create a filtered Cloud Billing budget with programmatic Pub/Sub notifications.
# Prerequisites: Billing-account permission, target project, existing Pub/Sub topic and validated Google provider version.
# Configuration: Supply billing account, project, amount, currency and topic; adapt thresholds to enterprise policy.
# Error handling: CI must reject invalid identifiers, nonpositive amounts and plans that remove all notification paths.
# Logging: Retain Terraform plan/apply logs and Pub/Sub delivery telemetry in the centralized audit project.
# Security considerations: Restrict budget administration and topic publishing/subscription; use workload identity for CI.
# Testing instructions: Validate plan, create in nonproduction, trigger threshold simulation and verify duplicate-safe routing.
# Deployment instructions: Apply through the controlled platform pipeline with finance and FinOps approval.
# Rollback instructions: Restore the prior resource version; during an incident, do not delete the notification topic.
# Production limitations: Budgets do not enforce hard spend limits; notification timing and schema require current documentation validation.

variable "billing_account_id" {
  type = string
}
variable "project_id" {
  type = string
}
variable "monthly_budget_amount" {
  type = number
  validation {
    condition     = var.monthly_budget_amount > 0
    error_message = "monthly_budget_amount must be positive."
  }
}
variable "currency_code" {
  type    = string
  default = "USD"
}
variable "notification_topic" {
  type = string
}

resource "google_billing_budget" "domain_monthly" {
  billing_account = var.billing_account_id
  display_name    = "egcdp-domain-monthly"

  budget_filter {
    projects = ["projects/${var.project_id}"]
  }

  amount {
    specified_amount {
      currency_code = var.currency_code
      units         = tostring(floor(var.monthly_budget_amount))
    }
  }

  threshold_rules { threshold_percent = 0.50 }
  threshold_rules { threshold_percent = 0.80 }
  threshold_rules { threshold_percent = 1.00 }
  threshold_rules { threshold_percent = 1.20 }

  all_updates_rule {
    pubsub_topic                   = var.notification_topic
    schema_version                 = "1.0"
    disable_default_iam_recipients = false
  }
}
