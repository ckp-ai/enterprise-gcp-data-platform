-- Purpose: Provide representative KPI queries for allocation, product unit economics and BigQuery efficiency analysis.
-- Prerequisites: FinOps mart, governed business-unit denominators and access to the correct regional INFORMATION_SCHEMA views.
-- Configuration: Replace project, dataset and REGION placeholders; set approved windows and threshold parameters in orchestration.
-- Error handling: Treat missing denominator data, stale marts and unsupported INFORMATION_SCHEMA fields as failed KPI publication.
-- Logging: Store query job IDs, scan/slot consumption, source watermark and KPI calculation version.
-- Security considerations: Restrict user_email and detailed job text to authorized operations and audit personas.
-- Testing instructions: Validate edge cases for zero denominators, late allocation, cancelled jobs and regional view coverage.
-- Deployment instructions: Publish as versioned views or scheduled queries through the FinOps analytics deployment pipeline.
-- Rollback instructions: Restore prior view/query version and retain historical KPI partitions for audit.
-- Production limitations: INFORMATION_SCHEMA retention, fields and regional names require current validation; KPI targets are enterprise policy.

-- Allocation coverage.
SELECT
  usage_month,
  SAFE_DIVIDE(
    SUM(IF(data_product != 'UNALLOCATED', total_allocated_cost, 0)),
    SUM(total_allocated_cost)
  ) AS allocation_coverage
FROM `finops_mart.monthly_product_cost`
GROUP BY usage_month;

-- Unit cost per successful refresh.
SELECT
  c.usage_month,
  c.data_product,
  c.total_allocated_cost,
  u.successful_refreshes,
  SAFE_DIVIDE(c.total_allocated_cost, u.successful_refreshes) AS cost_per_successful_refresh
FROM `finops_mart.monthly_product_cost` c
JOIN `finops_ref.product_business_units` u USING (usage_month, data_product);

-- BigQuery jobs with high billed bytes or resource warnings.
SELECT
  project_id,
  user_email,
  job_id,
  creation_time,
  total_bytes_billed,
  total_slot_ms,
  query_info.resource_warning
FROM `region-REGION`.INFORMATION_SCHEMA.JOBS_BY_ORGANIZATION
WHERE creation_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  AND job_type = 'QUERY'
  AND state = 'DONE'
ORDER BY total_bytes_billed DESC
LIMIT 500;
