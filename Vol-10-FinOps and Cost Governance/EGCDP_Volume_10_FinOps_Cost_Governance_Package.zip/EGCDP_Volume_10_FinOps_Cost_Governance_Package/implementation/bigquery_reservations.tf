# Purpose: Illustrate workload-isolated BigQuery reservations and project assignments.
# Prerequisites: Reservation admin project, supported location/edition, IAM approval and workload-test evidence.
# Configuration: Supply edition, baseline/max slots and assignee projects from approved scenario models; values below are variables, not recommendations.
# Error handling: CI validates nonnegative capacity, max >= baseline, supported location and mutually exclusive assignment policy.
# Logging: Preserve plan/apply logs and periodically export reservation, assignment and slot-utilization evidence.
# Security considerations: Restrict reservation administration; separate production BI and ELT project permissions.
# Testing instructions: Run concurrency/load tests, SLO tests, fallback tests and cost scenarios before production assignment.
# Deployment instructions: Create reservations first, then assignments during an approved change window; monitor queueing and autoscaling.
# Rollback instructions: Revert assignments before reducing/removing reservation capacity; preserve service continuity.
# Production limitations: Edition names, autoscaling semantics, quotas and Terraform provider schema must be validated at implementation time.

variable "admin_project" {
  type = string
}
variable "location" {
  type = string
}
variable "edition" {
  type    = string
  default = "ENTERPRISE"
}
variable "prod_bi_project" {
  type = string
}
variable "prod_elt_project" {
  type = string
}
variable "bi_baseline_slots" {
  type    = number
  default = 100
}
variable "bi_max_slots" {
  type    = number
  default = 500
}
variable "elt_baseline_slots" {
  type    = number
  default = 100
}
variable "elt_max_slots" {
  type    = number
  default = 1000
}

resource "google_bigquery_reservation" "prod_bi" {
  project           = var.admin_project
  location          = var.location
  name              = "prod-bi"
  edition           = var.edition
  slot_capacity     = var.bi_baseline_slots
  ignore_idle_slots = false
  autoscale { max_slots = var.bi_max_slots }

  lifecycle {
    precondition {
      condition     = var.bi_max_slots >= var.bi_baseline_slots
      error_message = "bi_max_slots must be at least bi_baseline_slots."
    }
  }
}

resource "google_bigquery_reservation" "prod_elt" {
  project           = var.admin_project
  location          = var.location
  name              = "prod-elt"
  edition           = var.edition
  slot_capacity     = var.elt_baseline_slots
  ignore_idle_slots = false
  autoscale { max_slots = var.elt_max_slots }

  lifecycle {
    precondition {
      condition     = var.elt_max_slots >= var.elt_baseline_slots
      error_message = "elt_max_slots must be at least elt_baseline_slots."
    }
  }
}

resource "google_bigquery_reservation_assignment" "bi" {
  project     = var.admin_project
  location    = var.location
  reservation = google_bigquery_reservation.prod_bi.id
  assignee    = "projects/${var.prod_bi_project}"
  job_type    = "QUERY"
}

resource "google_bigquery_reservation_assignment" "elt" {
  project     = var.admin_project
  location    = var.location
  reservation = google_bigquery_reservation.prod_elt.id
  assignee    = "projects/${var.prod_elt_project}"
  job_type    = "QUERY"
}
