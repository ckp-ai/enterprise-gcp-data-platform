# ADR-0907 - Use Artifact Registry as the enterprise artifact system of record

## ADR ID
ADR-0907

## Decision title
Use Artifact Registry as the enterprise artifact system of record

## Status
Approved reference decision

## Date
12 July 2026

## Architecture domain
DevSecOps and CI/CD

## Problem
The enterprise requires secure, repeatable and auditable release processes across infrastructure, applications, data pipelines and analytical assets.

## Context
The platform spans AMER, EMEA and APAC, regulated data, federated product teams and multiple Google Cloud services. The delivery system must preserve separation of duties, artifact integrity, environment isolation, SLOs and recovery.

## Decision drivers
Developer velocity, supply-chain integrity, least privilege, reproducibility, auditability, deployment safety, recovery and cost efficiency.

## Constraints
GitHub and Google Cloud product capabilities, regional/private connectivity, third-party actions, service-specific deployment semantics and regulatory approval requirements.

## Assumptions
GitHub Enterprise, Cloud Build, Artifact Registry, Cloud Deploy, WIF, Terraform and the security/operations baselines from Volumes 8, 10 and 11 are available.

## Alternatives considered
Single tool for every asset; manual/console release; long-lived credentials; mutable artifacts; bespoke per-team pipelines.

## Evaluation criteria
Security, provenance, supported targets, developer experience, network reach, audit evidence, operational effort, portability and economics.

## Decision
Store images, packages and modules in regional repositories with immutable tags/digests, scanning, CMEK where required and controlled cleanup.

## Rationale
The selected approach separates source orchestration, trusted build and target-specific delivery while promoting one immutable artifact and preserving evidence.

## Benefits
Consistent controls, keyless authentication, faster feedback, repeatable releases, safer rollback and stronger audit evidence.

## Tradeoffs
Multiple integrated services, golden workflow maintenance, policy tuning and skills are required.

## Positive consequences
Teams consume paved roads and produce standard release evidence.

## Negative consequences
Non-standard tools or assets require adapters and exception review.

## Risks
Provider/action compromise, policy bypass, credential misconfiguration, unsupported target semantics or failed rollback.

## Mitigations
Pinned dependencies, WIF conditions, private builds, attestations, staged policies, independent approvals, canary and exercises.

## Implementation implications
Publish repository standards, golden workflows, IAM modules, artifact policies, release manifest, test stages and service-specific rollback runbooks.

## Cost implications
Build minutes/private pools, artifact storage/scanning, deployment verification and engineering support; measure per release and product.

## Security implications
Eliminates keys, improves provenance and supports admission enforcement, but requires strict identity conditions and supply-chain governance.

## Operational implications
Release SLOs, deployment telemetry, on-call, rollback, change records and vendor escalation must be operational.

## Review triggers
Major product change, supply-chain incident, new regulated workload, repeated release failure, new target or SLSA revision.

## Review date
12 January 2027 or earlier trigger.
