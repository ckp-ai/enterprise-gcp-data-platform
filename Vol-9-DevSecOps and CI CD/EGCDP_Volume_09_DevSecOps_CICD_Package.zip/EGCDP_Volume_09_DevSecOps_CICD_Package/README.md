# EGCDP Volume 09 - DevSecOps and CI/CD

Generated from scratch on 12 July 2026. No output from the stalled Volume 9 execution was reused.

Contents:
- detailed DOCX and PDF
- six multi-format diagrams
- Cloud Build, GitHub Actions, Cloud Deploy, Terraform, Dataform, Dataflow, Airflow, BigQuery, policy, tests and rollback examples
- matrices, service assessments and ten ADRs
- quality reports, manifest and checksums
