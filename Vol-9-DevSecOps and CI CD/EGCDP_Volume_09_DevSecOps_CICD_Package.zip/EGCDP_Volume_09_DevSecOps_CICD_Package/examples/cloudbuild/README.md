# Cloud Build example

Purpose: build, test, publish and policy-check a container in a private worker pool.

Prerequisites: APIs, private pool, Artifact Registry, least-privilege build service account, approved builders and repository policy.

Configuration: replace identifiers with environment configuration; pin builder digests in production.

Error handling and logging: each step fails closed; build logs and test/vulnerability evidence are retained.

Security: no service-account keys; Secret Manager only for unavoidable external secrets; private pool egress is allowlisted.

Testing: run in a non-production project with a deliberately vulnerable image to prove the policy gate.

Deployment: trigger from protected merge or GitHub Actions using WIF; promote the image digest, never rebuild.

Rollback: redeploy the prior approved digest.

Limitations: vulnerability output and builder interfaces change; validate current APIs, formats, quotas and launch stages.