#!/usr/bin/env bash
set -euo pipefail
: "${PROJECT_ID:?}" "${LOCATION:?}" "${MIGRATION_FILE:?}"
# Validate syntax and estimated processing before execution.
bq query --project_id="${PROJECT_ID}" --location="${LOCATION}" --use_legacy_sql=false --dry_run < "${MIGRATION_FILE}"
bq query --project_id="${PROJECT_ID}" --location="${LOCATION}" --use_legacy_sql=false < "${MIGRATION_FILE}"
# Run deployment verification queries separately and retain job IDs as release evidence.
