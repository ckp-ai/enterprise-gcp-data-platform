# BigQuery and schema deployment lane

Purpose: dry-run and execute versioned SQL/schema migrations.

Prerequisites: approved migration, backup/time-travel/snapshot decision, dataset location and deploy identity.

Testing: compatibility, query dry run, assertions, reconciliation, performance and consumer contract tests.

Rollback: forward-fix is preferred for additive migrations; destructive changes require snapshot/restore or compatibility view strategy.

Limitations: DDL rollback semantics differ from application rollback; every migration requires an explicit recovery plan.