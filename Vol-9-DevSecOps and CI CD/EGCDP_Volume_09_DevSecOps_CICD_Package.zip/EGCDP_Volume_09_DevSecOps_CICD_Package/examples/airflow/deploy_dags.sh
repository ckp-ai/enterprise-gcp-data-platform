#!/usr/bin/env bash
set -euo pipefail
: "${DAG_BUCKET:?}" "${RELEASE_DIR:?}"
python -m compileall "${RELEASE_DIR}/dags"
pytest -q "${RELEASE_DIR}/tests"
gcloud storage rsync --recursive --delete-unmatched-destination-objects "${RELEASE_DIR}/dags" "gs://${DAG_BUCKET}/dags"
echo "DAG release synchronized; verify import errors and scheduler health before closing change."
