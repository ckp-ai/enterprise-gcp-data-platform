# Rollback procedure example

Purpose: demonstrate a parameterized, audited rollback entry point.

Prerequisites: known-good release, change/incident ID, operator authorization and tested verification.

Security: invoke using JIT/PAM identity; never embed credentials.

Testing: exercise in staging and production game days.

Limitations: application, Terraform, schema, Dataflow state and data rollback require different service-specific procedures.