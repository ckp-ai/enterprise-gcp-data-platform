#!/usr/bin/env bash
set -euo pipefail
: "${SERVICE:?}" "${REGION:?}" "${PROJECT_ID:?}" "${KNOWN_GOOD_IMAGE:?}" "${CHANGE_ID:?}"
case "${SERVICE}" in
  cloud-run)
    gcloud run services update-traffic customer-api --project="${PROJECT_ID}" --region="${REGION}" --to-revisions="${KNOWN_GOOD_IMAGE}=100"
    ;;
  *) echo "Unsupported service rollback path" >&2; exit 2;;
esac
echo "Rollback executed for change ${CHANGE_ID}; run smoke, SLO, data and security verification."
