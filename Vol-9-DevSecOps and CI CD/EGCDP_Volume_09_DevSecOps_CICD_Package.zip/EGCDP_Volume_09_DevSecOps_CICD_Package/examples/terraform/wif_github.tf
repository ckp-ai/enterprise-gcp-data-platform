resource "google_service_account" "build_submitter" {
  project      = var.project_id
  account_id   = "sa-github-build-submitter"
  display_name = "GitHub Cloud Build submitter"
}

resource "google_iam_workload_identity_pool" "github" {
  project                   = var.project_id
  workload_identity_pool_id = "github-enterprise"
  display_name              = "GitHub Enterprise pipelines"
}

resource "google_iam_workload_identity_pool_provider" "github" {
  project                            = var.project_id
  workload_identity_pool_id          = google_iam_workload_identity_pool.github.workload_identity_pool_id
  workload_identity_pool_provider_id = "github-oidc"
  display_name                       = "GitHub OIDC"

  attribute_mapping = {
    "google.subject"       = "assertion.sub"
    "attribute.repository" = "assertion.repository"
    "attribute.ref"        = "assertion.ref"
    "attribute.workflow"   = "assertion.job_workflow_ref"
  }

  attribute_condition = "assertion.repository_owner == 'enterprise-data-platform' && assertion.ref == 'refs/heads/main'"

  oidc {
    issuer_uri = "https://token.actions.githubusercontent.com"
  }
}

resource "google_service_account_iam_member" "github_build" {
  service_account_id = google_service_account.build_submitter.name
  role               = "roles/iam.workloadIdentityUser"
  member             = "principalSet://iam.googleapis.com/${google_iam_workload_identity_pool.github.name}/attribute.repository/enterprise-data-platform/customer-api"
}
