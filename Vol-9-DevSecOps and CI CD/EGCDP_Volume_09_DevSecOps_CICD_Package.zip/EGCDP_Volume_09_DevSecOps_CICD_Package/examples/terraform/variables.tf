variable "project_id" {
  type        = string
  description = "Google Cloud project that hosts CI/CD foundation resources."
}

variable "region" {
  type        = string
  description = "Approved regional location for repositories and build resources."
}

variable "kms_key_name" {
  type        = string
  description = "CMEK resource name for Artifact Registry."
}
