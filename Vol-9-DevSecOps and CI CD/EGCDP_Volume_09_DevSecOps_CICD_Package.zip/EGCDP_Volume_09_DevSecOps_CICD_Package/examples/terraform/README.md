# Terraform examples

Purpose: provision GitHub Workload Identity Federation and an immutable Artifact Registry repository.

Prerequisites: organization/project APIs, Terraform remote state, plan/apply service accounts and KMS key.

Security: narrow WIF attributes, separate plan/apply identities, state encryption, locking, least privilege and protected apply environment.

Testing: fmt, validate, provider lock, policy tests, plan review and non-production apply.

Deployment: version modules and promote approved plan evidence.

Rollback: revert module version and apply only after resource/state impact review.

Limitations: provider arguments evolve; validate the pinned provider and current API behavior.