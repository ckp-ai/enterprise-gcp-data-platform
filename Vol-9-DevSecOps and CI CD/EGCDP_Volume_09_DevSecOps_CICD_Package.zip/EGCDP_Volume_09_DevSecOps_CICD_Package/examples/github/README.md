# GitHub Actions examples

Purpose: orchestrate validation and keyless submission of trusted Google Cloud builds and Terraform releases.

Prerequisites: GitHub Enterprise organization, protected environments, WIF provider, short-lived service-account impersonation and repository rulesets.

Security: restrict provider attributes to organization, repository, ref, workflow and environment; do not store Google Cloud keys. Pin third-party actions by commit SHA in production.

Testing: exercise untrusted fork behavior, branch restrictions, environment approval, token claims and denied impersonation.

Deployment: manage workflow files through CODEOWNERS and protected pull requests.

Rollback: revert workflow/configuration and revoke or disable the provider/attribute condition if compromised.

Limitations: GitHub features and action versions evolve; validate current enterprise controls and permissions.