# Dataflow release lane

Purpose: test, build and publish a versioned Dataflow Flex Template.

Prerequisites: Artifact Registry, artifact bucket, private worker/build path and Beam tests.

Deployment: create/update jobs from the immutable template path with environment configuration.

Rollback: compatible update to prior template or drain/snapshot/restart/replay according to state compatibility.

Limitations: test Beam/Dataflow version and state compatibility before production update.