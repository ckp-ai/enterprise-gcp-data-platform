# Dataform release lane

Purpose: compile a specific commit and invoke an approved workflow configuration.

Prerequisites: repository/workflow configuration, dedicated identity, BigQuery datasets and assertions.

Error handling: fail on compilation or invocation failure; assertion failures block downstream promotion.

Security: no broad BigQuery owner role; use dedicated workflow identity and controlled repository release.

Testing: compile, dependency graph, assertions, dry-run queries and non-production invocation.

Rollback: rerun the last approved release configuration/commit and reverse incompatible data changes through a governed migration.

Limitations: validate current gcloud command surface and Dataform API.