#!/usr/bin/env bash
set -euo pipefail
: "${PROJECT_ID:?}" "${REGION:?}" "${REPOSITORY:?}" "${COMMIT_SHA:?}" "${WORKFLOW_CONFIG:?}"
COMPILATION="release-${COMMIT_SHA:0:12}"
gcloud dataform compilation-results create "${COMPILATION}" --project="${PROJECT_ID}" --region="${REGION}" --repository="${REPOSITORY}" --git-commitish="${COMMIT_SHA}"
gcloud dataform workflow-configs run "${WORKFLOW_CONFIG}" --project="${PROJECT_ID}" --region="${REGION}" --repository="${REPOSITORY}"
