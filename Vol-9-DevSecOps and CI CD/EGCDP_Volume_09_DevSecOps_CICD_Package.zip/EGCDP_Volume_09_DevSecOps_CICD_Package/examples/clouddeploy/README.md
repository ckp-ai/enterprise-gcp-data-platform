# Cloud Deploy example

Purpose: promote one immutable image release through integration, staging and a verified production canary.

Prerequisites: Cloud Run targets, delivery identities, Skaffold manifests, approval groups and monitoring.

Security: deployment service accounts are target-specific; approvers cannot modify source artifacts; Binary Authorization is enforced separately.

Testing: verify render, deploy hooks, smoke test, canary progression, pause and rollback.

Deployment: create release with a digest-pinned image and release manifest.

Rollback: use Cloud Deploy rollback to a prior release or explicitly promote the known-good release.

Limitations: exact canary/runtime configuration and supported targets change; validate current schema.