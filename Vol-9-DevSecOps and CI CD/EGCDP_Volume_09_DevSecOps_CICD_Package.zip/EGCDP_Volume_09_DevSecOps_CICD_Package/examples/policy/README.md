# Policy-as-code examples

Purpose: fail Terraform or artifact releases that violate mandatory identity and immutability controls.

Testing: maintain positive and negative fixtures; prove policy failure in CI.

Deployment: version policies independently with CODEOWNERS and a compatibility window.

Rollback: restore the previous policy only with risk approval; use audit/dry-run before broad enforcement.

Limitations: input schemas vary by scanner and Terraform version; adapters and tests are required.