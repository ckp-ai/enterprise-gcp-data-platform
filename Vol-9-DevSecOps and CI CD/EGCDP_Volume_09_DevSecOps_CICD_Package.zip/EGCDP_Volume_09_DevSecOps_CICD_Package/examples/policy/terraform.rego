package terraform.egcdp
import rego.v1

deny contains msg if {
  some rc in input.resource_changes
  rc.type == "google_service_account_key"
  msg := sprintf("User-managed service account keys are prohibited: %s", [rc.address])
}
deny contains msg if {
  some rc in input.resource_changes
  rc.type == "google_artifact_registry_repository"
  rc.change.after.format == "DOCKER"
  not rc.change.after.docker_config[0].immutable_tags
  msg := sprintf("Docker repository must enable immutable tags: %s", [rc.address])
}
