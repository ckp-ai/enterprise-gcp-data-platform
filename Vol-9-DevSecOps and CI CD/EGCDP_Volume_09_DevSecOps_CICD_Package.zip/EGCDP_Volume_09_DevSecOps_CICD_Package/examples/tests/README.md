# Test-stage example

Purpose: deterministically validate minimum release evidence before promotion.

Testing: include fixtures for missing fields, failed security, mutable tag and valid digest.

Security: release manifests contain identifiers and results, not secrets or raw sensitive data.

Deployment: run in CI and again at the production approval boundary.

Rollback: use the recorded rollback release and verify it remains retrievable and approved.