"""Validate a release manifest before production promotion."""
import json, pathlib, sys
REQUIRED={"commit_sha","artifact_digest","test_run_id","security_result","rollback_release","owner","change_id"}
def main(path:str)->int:
    data=json.loads(pathlib.Path(path).read_text())
    missing=REQUIRED-set(data)
    if missing:
        print(f"missing release fields: {sorted(missing)}",file=sys.stderr); return 2
    if data["security_result"] != "passed":
        print("security gate did not pass",file=sys.stderr); return 3
    if not str(data["artifact_digest"]).startswith("sha256:"):
        print("artifact must be digest-addressed",file=sys.stderr); return 4
    print("release manifest accepted"); return 0
if __name__=='__main__': raise SystemExit(main(sys.argv[1]))
