# MESH-ADR-004: Use Analytics Hub for managed product sharing

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

Consumers need auditable subscription patterns.

## Context

Direct dataset IAM and unmanaged copies make ownership, consumer inventory, versioning, and revocation difficult to govern.

## Decision drivers

- Auditable sharing
- Producer-consumer separation
- Discoverability
- Controlled subscription
- Reduced copying

## Constraints and assumptions

- Not every interface is suitable for Analytics Hub
- External sharing requires legal review
- Entitlements remain policy controlled

## Alternatives considered

- Direct dataset IAM
- Manual data copies
- Analytics Hub exchanges and listings

## Evaluation criteria

- Auditability
- Ease of subscription
- Revocation
- Metadata
- Cross-project consumption

## Decision

Publish certified products through Analytics Hub exchanges and listings where appropriate.

## Rationale

Managed listings formalize producer-consumer relationships and reduce broad direct grants.

## Benefits

- Controlled subscription
- Clear product publication
- Reduced copying
- Improved consumer inventory

## Tradeoffs

Requires a marketplace operating model.

## Positive consequences

- Products become discoverable through governed channels
- Subscriptions can be reviewed and revoked
- Sharing is less dependent on manual copies

## Negative consequences

- Some low-latency or API products need other interfaces
- Marketplace administration is required

## Risks

Listings may be published without adequate consumer-use controls.

## Mitigations

- Exchange types
- Publication standards
- Legal and security approval for external sharing
- Subscription recertification

## Implementation implications

Define internal, restricted, partner, and external exchange patterns with owner, steward, and security approvals.

## Cost implications

Sharing can reduce duplicate storage but may increase producer query and support costs; attribution rules are required.

## Security implications

Use approved exchanges, subscriber allowlists, row/column controls, and contractual restrictions.

## Operational implications

Marketplace operations maintain exchange taxonomy, publication workflow, and subscription reviews.

## Review trigger

Annual review or material change to Analytics Hub capabilities.
