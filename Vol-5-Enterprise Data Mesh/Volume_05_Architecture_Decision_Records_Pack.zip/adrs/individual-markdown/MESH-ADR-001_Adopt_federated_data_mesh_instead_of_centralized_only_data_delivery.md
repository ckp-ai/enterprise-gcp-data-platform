# MESH-ADR-001: Adopt federated data mesh instead of centralized-only data delivery

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

Centralized data teams cannot scale product delivery across hundreds of domains.

## Context

A Fortune 100 enterprise needs consistent platform controls while allowing business domains to deliver data products at their own pace. A centralized-only delivery organization becomes a queue and weakens business accountability.

## Decision drivers

- Domain scalability
- Business accountability
- Standardized controls
- Reduced delivery bottlenecks
- Regulatory traceability

## Constraints and assumptions

- Central platform standards remain mandatory
- Domains have different maturity levels
- Sensitive data must remain policy controlled
- Adoption must be incremental

## Alternatives considered

- Centralized platform and delivery team only
- Uncoordinated decentralized data marts
- Federated data mesh with central platform capabilities

## Evaluation criteria

- Enterprise scalability
- Governance consistency
- Security
- Time to market
- Operating-model feasibility

## Decision

Adopt a federated data mesh with a central self-service platform and domain-owned data products.

## Rationale

The model preserves enterprise guardrails while moving product accountability and delivery closer to business knowledge.

## Benefits

- Improved domain autonomy
- Clear product accountability
- Reusable platform capabilities
- Scalable ownership model

## Tradeoffs

Requires stronger product ownership and governance automation.

## Positive consequences

- Faster domain delivery
- Central controls are encoded once and reused
- Business meaning remains with accountable domains

## Negative consequences

- Organizational change is substantial
- Capability maturity will vary by domain
- Governance automation requires investment

## Risks

Organizational adoption, inconsistent execution, or control gaps if automation is incomplete.

## Mitigations

- Executive sponsorship
- Domain KPIs
- Automated policy gates
- Progressive maturity model
- Platform onboarding support

## Implementation implications

Create a platform product team, establish domain onboarding, deploy project and data-product factories, and pilot two domains before broader rollout.

## Cost implications

Initial platform and enablement investment increases, while long-term central delivery bottlenecks and duplicate pipelines should decrease.

## Security implications

Central security controls remain non-negotiable; domains receive delegated permissions only through approved patterns.

## Operational implications

Certified products require named support ownership, SLOs, dashboards, runbooks, and escalation paths.

## Review trigger

Annual review or material change to Google Cloud capabilities, regulation, or enterprise operating model.
