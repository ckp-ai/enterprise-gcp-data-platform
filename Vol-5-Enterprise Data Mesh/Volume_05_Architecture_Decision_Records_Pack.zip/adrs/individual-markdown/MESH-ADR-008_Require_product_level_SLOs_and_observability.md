# MESH-ADR-008: Require product-level SLOs and observability

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

Product trust depends on measurable operations.

## Context

Platform availability alone does not prove that a particular product is fresh, complete, accurate, or available to consumers.

## Decision drivers

- Trust
- Operational accountability
- Consumer transparency
- Incident management
- Capacity planning

## Constraints and assumptions

- SLOs must be measurable
- Alert noise must be controlled
- Criticality tiers vary

## Alternatives considered

- Best-effort support
- Platform-only SLOs
- Product-specific SLOs

## Evaluation criteria

- Consumer relevance
- Measurability
- Actionability
- Cost
- Ownership

## Decision

Each certified product has freshness, quality, availability, and support SLOs.

## Rationale

Product-specific service objectives make ownership enforceable and allow consumers to select products based on reliability.

## Benefits

- Transparent reliability
- Faster incident detection
- Clear support commitments
- Improved product comparison

## Tradeoffs

Requires monitoring cost and operational ownership.

## Positive consequences

- Consumers understand fitness for purpose
- Error budgets drive prioritization
- Operations can identify failing products

## Negative consequences

- Telemetry and alerts add cost
- Poor SLO design can create noise

## Risks

Teams may define weak or non-actionable SLOs.

## Mitigations

- Standard SLI catalogue
- Tier-based defaults
- Generated dashboards
- Periodic SLO review

## Implementation implications

Deploy standard metrics, dashboards, alert policies, product scorecards, and error-budget reporting.

## Cost implications

Monitoring, logging, and support costs must be allocated to the product.

## Security implications

Security-related SLOs include access-review completion and unauthorized-access alert response.

## Operational implications

Product teams own alerts, runbooks, on-call routing, and post-incident review.

## Review trigger

Quarterly SLO review and annual architecture review.
