# MESH-ADR-012: Treat AI-ready products as a stricter certification class

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

AI use increases privacy, provenance, and misuse risk.

## Context

Data used for training, grounding, embeddings, and agents can amplify quality defects and expose sensitive information through indirect outputs.

## Decision drivers

- Responsible AI
- Privacy
- Provenance
- Grounding quality
- Permitted use

## Constraints and assumptions

- Not all certified analytical products are suitable for AI
- AI use cases may cross jurisdictions
- Model behavior is probabilistic

## Alternatives considered

- Allow all certified products for AI
- Block enterprise AI use
- Create a stricter AI-ready certification class

## Evaluation criteria

- Risk reduction
- Traceability
- Usability
- Governance effort
- Innovation enablement

## Decision

Create an AI-ready certification class with explicit permitted uses, provenance, quality, privacy, and guardrail requirements.

## Rationale

AI-ready certification provides stronger assurances without blocking all governed AI use.

## Benefits

- Safer RAG and model use
- Clear allowed-use policies
- Better provenance
- Improved evaluation

## Tradeoffs

Requires additional governance and technical evidence.

## Positive consequences

- AI teams discover suitable products quickly
- Sensitive or low-quality products are excluded from automated AI use

## Negative consequences

- Product onboarding takes longer
- New monitoring and evaluation are needed

## Risks

Teams may bypass certification for experimentation.

## Mitigations

- Controlled sandboxes
- AI review checklist
- Model/data access controls
- Audit and egress monitoring

## Implementation implications

Add AI metadata, allowed-use fields, PII checks, provenance, evaluation datasets, and retrieval-quality requirements.

## Cost implications

Additional profiling, evaluation, and monitoring costs apply to AI-ready products.

## Security implications

Products require prompt-injection, data-exfiltration, privacy, and content-safety assessments where applicable.

## Operational implications

AI-ready status is periodically revalidated as data, models, and regulations change.

## Review trigger

At least semiannual review due to rapid AI capability and policy change.
