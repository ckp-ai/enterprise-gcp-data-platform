# MESH-ADR-013: Use chargeback and showback at product and domain level

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

Cost transparency is required for mesh sustainability.

## Context

Shared platform and query costs can become invisible, while domains have limited incentives to optimize products they publish or consume.

## Decision drivers

- Cost accountability
- Optimization
- Funding
- Product economics
- Capacity planning

## Constraints and assumptions

- Shared costs cannot always be attributed exactly
- Query attribution requires job labels or reservations
- Chargeback maturity varies

## Alternatives considered

- Project-only cost reporting
- Domain-level showback
- Product-level showback and targeted chargeback

## Evaluation criteria

- Attribution accuracy
- Actionability
- Administrative cost
- Fairness
- Maturity

## Decision

Use mandatory product and domain labels with billing export for product-level showback and targeted chargeback.

## Rationale

Product economics help owners balance service quality, demand, and cost while retaining central platform transparency.

## Benefits

- Cost ownership
- Optimization incentives
- Funding transparency
- Capacity insight

## Tradeoffs

Attribution is imperfect for shared workloads.

## Positive consequences

- High-cost products and consumers become visible
- Domain budgets can reflect actual usage

## Negative consequences

- Cost allocation rules may be disputed
- Tagging discipline is mandatory

## Risks

Incorrect labels or shared compute can distort reports.

## Mitigations

- Mandatory labels
- Query job tagging
- Reservation mapping
- Allocation rules
- FinOps review

## Implementation implications

Define cost taxonomy, export billing data, publish domain dashboards, and phase from showback to selective chargeback.

## Cost implications

FinOps tooling and governance add overhead but enable measurable savings.

## Security implications

Billing views must not expose sensitive resource metadata beyond authorized stakeholders.

## Operational implications

FinOps, platform, and domain owners review cost, unit metrics, and optimization actions monthly.

## Review trigger

Quarterly cost-allocation review.
