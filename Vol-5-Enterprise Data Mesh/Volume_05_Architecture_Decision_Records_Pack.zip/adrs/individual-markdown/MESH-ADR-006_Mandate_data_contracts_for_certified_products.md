# MESH-ADR-006: Mandate data contracts for certified products

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

Consumers need predictable schema, semantics, and freshness.

## Context

Unmanaged schema changes and undocumented semantics create downstream incidents and hidden coupling.

## Decision drivers

- Interface stability
- Consumer trust
- Change management
- Quality
- Automation

## Constraints and assumptions

- Contracts must be machine-readable
- Breaking changes require versioning
- Legacy producers need transition support

## Alternatives considered

- Informal documentation
- Schema-only contracts
- Full data-product contracts

## Evaluation criteria

- Coverage
- Automatability
- Consumer protection
- Change transparency
- Adoption effort

## Decision

Full data contracts are mandatory for product certification.

## Rationale

Contracts provide a testable agreement for schema, semantics, SLOs, classifications, ownership, and change policy.

## Benefits

- Fewer breaking changes
- Automated validation
- Clear expectations
- Improved onboarding

## Tradeoffs

Increases initial product effort.

## Positive consequences

- Changes can be assessed before release
- Consumers can automate compatibility checks
- Certification evidence improves

## Negative consequences

- Contract maintenance is required
- Legacy products need remediation

## Risks

Contracts may drift from deployed schemas.

## Mitigations

- CI validation
- Schema comparison
- Contract repository
- Release gates

## Implementation implications

Provide YAML/JSON contract templates, schema registry integration, compatibility checks, and release approval workflow.

## Cost implications

Additional engineering effort is offset by lower incident and rework costs.

## Security implications

Contracts include classification, permitted use, retention, and privacy constraints.

## Operational implications

Contract violations generate alerts and can block publication.

## Review trigger

Annual review or material change to product contract standards.
