# MESH-ADR-003: Use Knowledge Catalog as enterprise metadata and discovery plane

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

Consumers need a single context layer for products and governance.

## Context

Metadata is fragmented across engineering tools, spreadsheets, and team-specific documentation, preventing dependable discovery and governance evidence.

## Decision drivers

- Enterprise discovery
- Metadata consistency
- Lineage
- Governance evidence
- AI-ready context

## Constraints and assumptions

- Metadata completeness is a process responsibility
- Non-Google sources may need integration
- Regional support must be validated

## Alternatives considered

- Spreadsheet inventory
- Third-party catalog as primary system
- Knowledge Catalog as Google Cloud-native governance plane

## Evaluation criteria

- Native integration
- Extensibility
- Search
- Lineage coverage
- Operational overhead

## Decision

Use Knowledge Catalog as the Google Cloud-native catalog and governance context layer.

## Rationale

It provides the default metadata plane for Google Cloud data assets and can anchor product discovery, classifications, glossary terms, and certification evidence.

## Benefits

- Unified discovery
- Native asset context
- Reduced duplicate metadata
- Support for lineage and quality context

## Tradeoffs

Requires integration and metadata-completeness discipline.

## Positive consequences

- Consumers gain one searchable experience
- Governance evidence can be automated
- AI use cases gain governed context

## Negative consequences

- External metadata sources require synchronization
- Catalog quality depends on stewardship

## Risks

Incomplete metadata could make the catalog untrusted.

## Mitigations

- CI/CD metadata sync
- Mandatory ownership fields
- Steward scorecards
- Certification gates

## Implementation implications

Define mandatory metadata aspects, integrate product pipelines, register products, and publish glossary and classification standards.

## Cost implications

Scanning, metadata processing, integration, and stewardship have ongoing costs that must be budgeted.

## Security implications

Catalog visibility must not expose restricted metadata or reveal sensitive asset existence to unauthorized users.

## Operational implications

Platform team operates integrations; domain stewards maintain business metadata.

## Review trigger

Annual review or significant change to Google Cloud metadata services.
