# MESH-ADR-002: Use domain-owned data products as the primary delivery unit

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

Datasets without product commitments are hard to trust or reuse.

## Context

The enterprise has many technically accessible datasets but inconsistent ownership, semantics, quality, and support commitments.

## Decision drivers

- Trust
- Reusability
- Accountability
- Consumer experience
- Measurable service levels

## Constraints and assumptions

- Products must map to bounded domains
- Ownership must be funded
- Metadata and SLOs are mandatory for certification

## Alternatives considered

- Dataset ownership only
- Report or dashboard ownership
- Domain-owned data product ownership

## Evaluation criteria

- Consumer usability
- Ownership clarity
- Quality assurance
- Lifecycle management
- Cost transparency

## Decision

Certified data products become the standard unit of enterprise data consumption.

## Rationale

A product definition combines data, interface, documentation, quality, access, support, and lifecycle commitments.

## Benefits

- Clear ownership
- Higher trust
- Improved discovery
- Stable interfaces
- Measurable quality

## Tradeoffs

Adds metadata, quality, support, and SLO obligations.

## Positive consequences

- Consumers can compare and select products
- Products can be certified and deprecated predictably
- Costs can be attributed to owners

## Negative consequences

- Up-front effort is higher than publishing a table
- Some legacy datasets may not immediately qualify

## Risks

Teams may rename datasets as products without assuming product responsibilities.

## Mitigations

- Certification checklist
- Product templates
- Product owner training
- Marketplace publication gates

## Implementation implications

Create a product descriptor, contract template, SLO template, ownership model, and certification workflow integrated with CI/CD.

## Cost implications

Product management adds operational cost but reduces duplicated discovery, reconciliation, and downstream repair work.

## Security implications

Each product carries classification, permitted uses, access groups, and policy enforcement requirements.

## Operational implications

Product owners and technical custodians jointly own incident response and lifecycle management.

## Review trigger

Annual review or material change to data-product operating standards.
