# MESH-ADR-015: Use domain stewards as certification evidence owners

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

Business meaning cannot be delegated entirely to engineers.

## Context

Technical metadata alone does not prove that a product has correct business definitions, quality interpretation, permitted use, or regulatory meaning.

## Decision drivers

- Business accountability
- Semantic consistency
- Quality interpretation
- Regulatory evidence
- Consumer trust

## Constraints and assumptions

- Steward capacity must be funded
- Responsibilities must be explicit
- Technical evidence remains automated

## Alternatives considered

- Engineer-only review
- Central governance-only review
- Domain steward ownership of business certification evidence

## Evaluation criteria

- Business accuracy
- Scalability
- Accountability
- Timeliness
- Auditability

## Decision

Domain data stewards own business metadata, glossary alignment, quality interpretation, and certification evidence.

## Rationale

Stewards are closest to business meaning and can validate whether technical results are fit for intended use.

## Benefits

- Accurate definitions
- Clear accountability
- Better quality decisions
- Stronger audit evidence

## Tradeoffs

Requires dedicated staffing and enablement.

## Positive consequences

- Certification combines technical and business evidence
- Definitions remain aligned with domain policy

## Negative consequences

- Steward bottlenecks are possible
- Role maturity may vary

## Risks

Underfunded stewardship can delay certification or reduce quality.

## Mitigations

- Steward staffing model
- Training
- Workflow automation
- Delegation rules
- Performance metrics

## Implementation implications

Assign stewards per product/domain, define RACI, automate evidence collection, and create approval queues.

## Cost implications

Stewardship is an explicit operating cost and should be included in domain funding.

## Security implications

Stewards validate classification and permitted-use metadata but do not replace security approval.

## Operational implications

Stewards participate in quality incidents, glossary changes, and periodic recertification.

## Review trigger

Annual operating-model review or material governance change.
