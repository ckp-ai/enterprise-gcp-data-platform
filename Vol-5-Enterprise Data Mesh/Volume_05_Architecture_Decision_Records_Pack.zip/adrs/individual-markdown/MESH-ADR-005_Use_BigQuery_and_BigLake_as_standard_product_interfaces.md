# MESH-ADR-005: Use BigQuery and BigLake as standard product interfaces

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

Products must support warehouse and lakehouse patterns.

## Context

The enterprise needs high-performance SQL products and governed access to open-format data without proliferating incompatible serving technologies.

## Decision drivers

- Standard interfaces
- SQL performance
- Open formats
- Fine-grained access
- Interoperability

## Constraints and assumptions

- BigLake performance depends on file layout
- Not all operational patterns belong in analytical interfaces
- Regional alignment is mandatory

## Alternatives considered

- BigQuery only
- Object storage only
- Mixed unmanaged interfaces
- BigQuery plus BigLake standards

## Evaluation criteria

- Performance
- Governance
- Open-format support
- Consumer usability
- Operational complexity

## Decision

Use BigQuery for curated analytical products and BigLake for governed open-format products.

## Rationale

The combination supports warehouse and lakehouse consumption while retaining a common Google Cloud governance and access model.

## Benefits

- High-performance SQL
- Open-format interoperability
- Fine-grained controls
- Reduced technology sprawl

## Tradeoffs

Requires file-layout and interface-selection standards.

## Positive consequences

- Consumers receive predictable interfaces
- Domains can choose native tables or governed open formats
- Platform tooling can standardize both

## Negative consequences

- Two patterns require clear selection guidance
- Poorly organized files can create performance problems

## Risks

Domains may expose raw storage as a product without sufficient curation.

## Mitigations

- Interface decision matrix
- File compaction standards
- Certification tests
- Query performance thresholds

## Implementation implications

Publish standard Terraform modules, dataset policies, BigLake connection patterns, and file-format guidelines.

## Cost implications

BigQuery compute and storage, BigLake metadata/query costs, and cross-region transfer must be measured by product.

## Security implications

Use dataset IAM, policy tags, authorized views, and controlled connections rather than direct bucket grants.

## Operational implications

Product teams monitor freshness, query performance, cost, and file health.

## Review trigger

Annual review or material change to BigQuery or BigLake architecture.
