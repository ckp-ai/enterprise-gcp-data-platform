# MESH-ADR-014: Use versioned deprecation instead of breaking product changes

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

Consumers need stable interfaces.

## Context

Breaking schema or semantic changes can disrupt many downstream consumers and create unplanned enterprise incidents.

## Decision drivers

- Consumer stability
- Change transparency
- Backward compatibility
- Lifecycle control
- Operational safety

## Constraints and assumptions

- Old versions cannot be retained indefinitely
- Usage telemetry is required
- Urgent security changes may need accelerated action

## Alternatives considered

- Immediate breaking changes
- Retain all versions indefinitely
- Versioned releases with planned deprecation

## Evaluation criteria

- Consumer protection
- Operational cost
- Change speed
- Auditability
- Maintainability

## Decision

Breaking changes require a major product version, migration window, usage monitoring, and controlled retirement.

## Rationale

Versioned deprecation balances consumer stability with the need to evolve products.

## Benefits

- Predictable change
- Reduced incidents
- Consumer migration planning
- Clear lifecycle

## Tradeoffs

Multiple versions must be maintained temporarily.

## Positive consequences

- Consumers receive notice and migration support
- Owners can retire obsolete interfaces based on evidence

## Negative consequences

- Temporary duplicate processing and storage costs
- Version management adds complexity

## Risks

Old versions may persist because consumers fail to migrate.

## Mitigations

- Usage monitoring
- Retirement deadlines
- Escalation
- Migration tooling
- Executive exception approval

## Implementation implications

Use semantic versioning, compatibility tests, deprecation metadata, consumer notifications, and retirement gates.

## Cost implications

Temporary parallel versions increase cost; retirement discipline is required.

## Security implications

Critical security fixes can override normal windows with documented emergency governance.

## Operational implications

Product owners maintain migration plans and monitor remaining consumers.

## Review trigger

Review with each major version and annually.
