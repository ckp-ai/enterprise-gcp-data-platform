# MESH-ADR-007: Use policy tags, row policies, and masking for sensitive products

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

Sensitive products need fine-grained controls.

## Context

Dataset-level access is too coarse for products containing mixed sensitivity, geography, or legal-use restrictions.

## Decision drivers

- Least privilege
- Privacy
- Regulatory compliance
- Reusable products
- Reduced copying

## Constraints and assumptions

- Taxonomy governance is required
- Policies must align with regions and datasets
- Access paths must be tested

## Alternatives considered

- Dataset-only IAM
- Separate masked copies
- Fine-grained policies with authorized interfaces

## Evaluation criteria

- Security strength
- Operational maintainability
- Consumer usability
- Auditability
- Data duplication

## Decision

Use policy tags, row access policies, dynamic masking, and authorized interfaces for sensitive products.

## Rationale

Fine-grained controls allow one governed product to support multiple authorized consumer populations.

## Benefits

- Least privilege
- Reduced duplicate datasets
- Central policy enforcement
- Improved auditability

## Tradeoffs

Requires taxonomy and entitlement governance.

## Positive consequences

- Sensitive columns and rows remain controlled
- Products can serve broader audiences safely
- Policy changes do not require full data copies

## Negative consequences

- Policy complexity can affect troubleshooting
- Incorrect tagging can block or expose data

## Risks

Misclassification or policy misconfiguration may expose sensitive data.

## Mitigations

- Automated classification
- Schema validation
- Policy tests
- Access reviews
- Security approval

## Implementation implications

Create enterprise taxonomies, mapping rules, test personas, and automated policy deployment.

## Cost implications

Policy management adds governance overhead but reduces storage duplication and copy management.

## Security implications

This is a primary control decision; controls must be validated with positive and negative access tests.

## Operational implications

Security and domain teams jointly own access incidents and recertification.

## Review trigger

Annual review or regulatory/control-model change.
