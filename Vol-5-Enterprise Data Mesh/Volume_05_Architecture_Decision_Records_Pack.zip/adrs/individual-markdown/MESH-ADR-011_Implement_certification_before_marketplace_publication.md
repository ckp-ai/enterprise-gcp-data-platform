# MESH-ADR-011: Implement certification before marketplace publication

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

A marketplace without trust signals creates risk.

## Context

Publishing unverified assets encourages reuse of incomplete, undocumented, or insecure datasets.

## Decision drivers

- Consumer trust
- Security
- Quality
- Discoverability
- Lifecycle control

## Constraints and assumptions

- Pilot domains may need staged maturity
- Certification evidence must be automatable
- High-risk products need human approval

## Alternatives considered

- Open publication
- Manual review only
- Automated certification gate with risk-based approval

## Evaluation criteria

- Trust
- Speed
- Auditability
- Scalability
- Risk control

## Decision

Products must pass defined certification gates before enterprise marketplace publication.

## Rationale

Certification establishes minimum metadata, quality, security, ownership, SLO, and lifecycle standards.

## Benefits

- Trusted marketplace
- Reduced consumer risk
- Consistent publication
- Auditable evidence

## Tradeoffs

Can slow early adoption if gates are too rigid.

## Positive consequences

- Consumers can rely on certification status
- Low-quality assets remain visible only in controlled development contexts

## Negative consequences

- Certification operations require staffing and automation
- Exceptions must be governed

## Risks

Manual certification may become a bottleneck.

## Mitigations

- Automated evidence collection
- Risk tiers
- Pilot maturity exceptions
- SLA for approvals

## Implementation implications

Define certification classes, automated checks, approval workflow, badges, and renewal criteria.

## Cost implications

Certification adds governance cost but reduces downstream quality and security incidents.

## Security implications

Restricted and external products require enhanced security and legal approval.

## Operational implications

Certification expires or is suspended when quality, SLO, ownership, or security evidence fails.

## Review trigger

Annual certification-framework review.
