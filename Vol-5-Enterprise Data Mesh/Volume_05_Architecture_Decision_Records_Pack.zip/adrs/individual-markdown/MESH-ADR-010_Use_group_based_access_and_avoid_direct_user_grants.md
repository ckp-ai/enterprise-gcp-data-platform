# MESH-ADR-010: Use group-based access and avoid direct user grants

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

Auditability and lifecycle management require group-based control.

## Context

Direct user grants are difficult to review, revoke, and associate with enterprise roles or consumer teams.

## Decision drivers

- Least privilege
- Joiner-mover-leaver control
- Auditability
- Scalability
- Delegated administration

## Constraints and assumptions

- Group ownership must be assigned
- Nested groups require governance
- Emergency access needs a separate process

## Alternatives considered

- Direct user grants
- Group-based grants
- Dynamic entitlement service

## Evaluation criteria

- Auditability
- Revocation
- Scalability
- Integration with identity lifecycle
- Operational effort

## Decision

Use enterprise groups and product-specific IAM bindings by default; prohibit direct user grants except approved break-glass cases.

## Rationale

Groups align access with roles and teams and enable periodic recertification.

## Benefits

- Simpler reviews
- Faster revocation
- Consistent entitlements
- Reduced IAM sprawl

## Tradeoffs

Group lifecycle must be actively managed.

## Positive consequences

- Consumer access is traceable to a managed group
- User turnover is handled through identity processes

## Negative consequences

- Group nesting and ownership can become complex
- Access may be delayed if workflow is inefficient

## Risks

Stale groups can retain excessive privileges.

## Mitigations

- Access expiry
- Owner recertification
- Automated membership review
- Break-glass monitoring

## Implementation implications

Create naming standards, access request workflows, product consumer groups, and recertification automation.

## Cost implications

Identity administration cost increases modestly but audit and remediation effort decreases.

## Security implications

No direct grants in production except logged emergency access with automatic expiry.

## Operational implications

Identity team owns group lifecycle; domain owners approve product entitlements.

## Review trigger

Quarterly access-control review.
