# MESH-ADR-009: Adopt domain project factory patterns

- **Status:** Proposed for enterprise adoption
- **Decision date:** 2026-07-11
- **Architecture domain:** Enterprise Data Mesh
- **Source:** Volume 05 - Enterprise Data Mesh

## Problem

Domain autonomy needs repeatable infrastructure.

## Context

Manual project provisioning and shared monolithic projects create inconsistent controls and slow onboarding.

## Decision drivers

- Repeatability
- Isolation
- Speed
- Compliance
- Scalability

## Constraints and assumptions

- Organization policies are inherited
- Shared networking remains centralized
- Projects must follow naming and labels

## Alternatives considered

- Manual projects
- Single central shared project
- Terraform-based domain project factory

## Evaluation criteria

- Provisioning speed
- Control consistency
- Isolation
- Auditability
- Maintenance

## Decision

Provision standardized domain projects, datasets, identities, budgets, and monitoring through Terraform.

## Rationale

A project factory turns the landing-zone and mesh guardrails into a repeatable self-service capability.

## Benefits

- Faster onboarding
- Consistent security
- Predictable cost controls
- Reduced drift

## Tradeoffs

Requires initial and ongoing module investment.

## Positive consequences

- Domains start from compliant defaults
- Changes are versioned
- Projects can be reproduced

## Negative consequences

- Exceptions need formal handling
- Module upgrades require coordination

## Risks

Teams may bypass the factory for urgent delivery.

## Mitigations

- Policy enforcement
- Fast onboarding SLA
- Exception workflow
- Drift detection

## Implementation implications

Create golden Terraform modules, request workflow, validation pipeline, and lifecycle management.

## Cost implications

Factory investment reduces repeated engineering and audit effort over time.

## Security implications

Factory modules enforce IAM, logging, KMS, perimeter, and network defaults.

## Operational implications

Platform team owns modules and upgrades; domains own resources created within their approved boundary.

## Review trigger

Semiannual module and architecture review.
