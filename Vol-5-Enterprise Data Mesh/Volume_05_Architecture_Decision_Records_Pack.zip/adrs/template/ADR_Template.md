# MESH-ADR-XXX: Decision title

- **Status:** Proposed | Accepted | Superseded | Deprecated
- **Decision date:** YYYY-MM-DD
- **Architecture domain:** Enterprise Data Mesh
- **Owner:** Role or governance body

## Problem

## Context

## Decision drivers

## Constraints and assumptions

## Alternatives considered

## Evaluation criteria

## Decision

## Rationale

## Benefits

## Tradeoffs

## Positive consequences

## Negative consequences

## Risks

## Mitigations

## Implementation implications

## Cost implications

## Security implications

## Operational implications

## Review trigger
