# Volume 05 Architecture Decision Records

This directory contains the 15 Architecture Decision Records referenced in **Volume 05 - Enterprise Data Mesh**.

## Contents

- `Volume_05_Architecture_Decision_Record_Register.docx` - editable consolidated register
- `Volume_05_Architecture_Decision_Record_Register.pdf` - polished consolidated register
- `ADR_Register.csv` - machine-readable summary
- `individual-markdown/` - one editable Markdown file per ADR
- `individual-docx/` - one editable DOCX file per ADR
- `individual-pdf/` - one PDF file per ADR
- `template/` - reusable ADR templates

## ADRs

- **MESH-ADR-001** - Adopt federated data mesh instead of centralized-only data delivery
- **MESH-ADR-002** - Use domain-owned data products as the primary delivery unit
- **MESH-ADR-003** - Use Knowledge Catalog as enterprise metadata and discovery plane
- **MESH-ADR-004** - Use Analytics Hub for managed product sharing
- **MESH-ADR-005** - Use BigQuery and BigLake as standard product interfaces
- **MESH-ADR-006** - Mandate data contracts for certified products
- **MESH-ADR-007** - Use policy tags, row policies, and masking for sensitive products
- **MESH-ADR-008** - Require product-level SLOs and observability
- **MESH-ADR-009** - Adopt domain project factory patterns
- **MESH-ADR-010** - Use group-based access and avoid direct user grants
- **MESH-ADR-011** - Implement certification before marketplace publication
- **MESH-ADR-012** - Treat AI-ready products as a stricter certification class
- **MESH-ADR-013** - Use chargeback and showback at product and domain level
- **MESH-ADR-014** - Use versioned deprecation instead of breaking product changes
- **MESH-ADR-015** - Use domain stewards as certification evidence owners
