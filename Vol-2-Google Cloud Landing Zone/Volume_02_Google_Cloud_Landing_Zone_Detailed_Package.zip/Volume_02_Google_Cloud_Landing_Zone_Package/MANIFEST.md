# Package Manifest

## Architecture document
- Volume 02 Google Cloud Landing Zone detailed DOCX
- Volume 02 Google Cloud Landing Zone polished PDF
- Markdown source used to assemble the volume

## Required coverage
- Organization, folder and project hierarchy
- Project factory and project types
- Environment model
- Shared VPC, host and service projects
- IPAM, subnet, routing, private access, PSC, NAT and DNS
- Firewall policies, Cloud Armor, VPN and Interconnect
- Hybrid and multi-cloud connectivity
- Identity federation, IAM, service accounts, PAM and break glass
- Organization policy, VPC Service Controls, SCC, secrets and keys
- Audit logging, monitoring, centralized logging and SecOps integration
- Naming, labels and tags
- Terraform implementation and deployment sequence
- Validation, production readiness, ADRs, RACI, risks and evidence catalogue

## Editable diagrams
Each of the seven diagrams is available in:
- `.drawio`
- `.mmd`
- `.puml`
- `.dot`
- `.svg`
- `.png`

## Reference code
- Bootstrap Terraform
- Project factory
- Shared VPC
- Organization policies
- Central logging
- KMS
- VPC Service Controls
- Environment composition
- Cloud Build, IAM, firewall and organization-policy YAML
