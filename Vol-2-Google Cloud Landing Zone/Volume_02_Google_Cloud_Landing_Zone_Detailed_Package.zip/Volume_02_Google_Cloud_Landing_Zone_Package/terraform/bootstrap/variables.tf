variable "bootstrap_project_id" { type = string }
variable "default_region" { type = string }
variable "state_bucket_name" { type = string }
variable "state_location" { type = string }
