variable "display_name" { type = string }
variable "project_id" { type = string }
variable "folder_id" { type = string }
variable "billing_account_id" { type = string }
variable "labels" { type = map(string) }
variable "services" { type = list(string) }
variable "shared_vpc_host_project_id" { type = string, default = null }
