resource "google_project" "project" {
  name            = var.display_name
  project_id      = var.project_id
  folder_id       = var.folder_id
  billing_account = var.billing_account_id
  labels          = var.labels
}

resource "google_project_service" "apis" {
  for_each           = toset(var.services)
  project            = google_project.project.project_id
  service            = each.value
  disable_on_destroy = false
}

resource "google_compute_shared_vpc_service_project" "attachment" {
  count           = var.shared_vpc_host_project_id == null ? 0 : 1
  host_project    = var.shared_vpc_host_project_id
  service_project = google_project.project.project_id
  depends_on      = [google_project_service.apis]
}
