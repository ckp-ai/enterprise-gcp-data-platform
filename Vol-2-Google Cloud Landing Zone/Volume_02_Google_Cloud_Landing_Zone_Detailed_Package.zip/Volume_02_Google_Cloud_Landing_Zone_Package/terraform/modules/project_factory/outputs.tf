output "project_id" {
  value       = google_project.project.project_id
  description = "Provisioned project ID."
}

output "project_number" {
  value       = google_project.project.number
  description = "Provisioned numeric project identifier."
}
