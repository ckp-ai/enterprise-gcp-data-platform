output "key_ring_id" {
  value       = google_kms_key_ring.regional.id
  description = "Key ring resource ID."
}

output "crypto_key_ids" {
  value       = { for name, key in google_kms_crypto_key.keys : name => key.id }
  description = "Map of key names to resource IDs."
}
