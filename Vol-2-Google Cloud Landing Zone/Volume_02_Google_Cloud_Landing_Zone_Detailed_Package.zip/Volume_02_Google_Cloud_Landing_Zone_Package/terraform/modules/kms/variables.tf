variable "kms_project_id" {
  description = "Dedicated project that owns the key ring and keys."
  type        = string
}

variable "key_ring_name" {
  description = "Regional key ring name."
  type        = string
}

variable "location" {
  description = "Google Cloud location for the key ring."
  type        = string
}

variable "keys" {
  description = "Map of encryption keys and rotation settings."
  type = map(object({
    rotation_period = string
  }))
}
