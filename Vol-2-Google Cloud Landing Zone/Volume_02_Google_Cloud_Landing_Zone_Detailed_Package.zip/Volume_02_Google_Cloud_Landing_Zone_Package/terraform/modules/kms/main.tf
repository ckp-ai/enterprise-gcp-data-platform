resource "google_kms_key_ring" "regional" {
  project  = var.kms_project_id
  name     = var.key_ring_name
  location = var.location
}

resource "google_kms_crypto_key" "keys" {
  for_each        = var.keys
  name            = each.key
  key_ring        = google_kms_key_ring.regional.id
  rotation_period = each.value.rotation_period
  purpose         = "ENCRYPT_DECRYPT"
  lifecycle { prevent_destroy = true }
}
