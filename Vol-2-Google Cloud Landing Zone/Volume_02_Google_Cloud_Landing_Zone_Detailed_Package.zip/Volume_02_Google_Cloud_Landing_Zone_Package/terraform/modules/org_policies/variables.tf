variable "organization_id" {
  description = "Numeric Google Cloud organization ID."
  type        = string
}

variable "boolean_constraints" {
  description = "Map of organization-policy constraint IDs to enforced state."
  type        = map(bool)
}
