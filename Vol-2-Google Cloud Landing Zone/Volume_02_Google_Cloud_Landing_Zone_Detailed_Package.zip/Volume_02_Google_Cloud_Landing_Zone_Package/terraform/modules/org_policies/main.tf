resource "google_org_policy_policy" "boolean" {
  for_each = var.boolean_constraints
  name     = "organizations/${var.organization_id}/policies/${each.key}"
  parent   = "organizations/${var.organization_id}"
  spec { rules { enforce = each.value } }
}
