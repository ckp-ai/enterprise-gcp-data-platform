output "policy_names" {
  description = "Organization policy resource names."
  value       = { for constraint, policy in google_org_policy_policy.boolean : constraint => policy.name }
}
