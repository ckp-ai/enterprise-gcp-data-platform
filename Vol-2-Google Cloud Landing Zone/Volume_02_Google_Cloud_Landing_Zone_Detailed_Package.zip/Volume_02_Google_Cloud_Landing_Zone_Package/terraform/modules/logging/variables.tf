variable "organization_id" {
  description = "Numeric organization ID used by the aggregated sink."
  type        = string
}

variable "logging_project_id" {
  description = "Central logging project ID."
  type        = string
}

variable "log_location" {
  description = "Log bucket location."
  type        = string
  default     = "global"
}

variable "log_bucket_id" {
  description = "Central log bucket ID."
  type        = string
}

variable "retention_days" {
  description = "Log retention period in days."
  type        = number
  default     = 365
}

variable "lock_bucket" {
  description = "Whether to lock retention. Enable only after legal and operational approval."
  type        = bool
  default     = false
}
