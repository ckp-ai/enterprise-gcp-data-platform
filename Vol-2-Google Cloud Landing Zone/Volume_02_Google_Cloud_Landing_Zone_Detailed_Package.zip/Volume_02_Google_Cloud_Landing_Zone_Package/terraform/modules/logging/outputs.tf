output "log_bucket_id" {
  value       = google_logging_project_bucket_config.central.id
  description = "Central log bucket resource ID."
}

output "sink_writer_identity" {
  value       = google_logging_organization_sink.audit.writer_identity
  description = "Unique writer identity that must write to the destination bucket."
}
