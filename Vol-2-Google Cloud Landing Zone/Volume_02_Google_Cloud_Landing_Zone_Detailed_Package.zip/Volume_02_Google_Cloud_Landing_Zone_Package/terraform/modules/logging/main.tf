resource "google_logging_project_bucket_config" "central" {
  project        = var.logging_project_id
  location       = var.log_location
  bucket_id      = var.log_bucket_id
  retention_days = var.retention_days
  locked         = var.lock_bucket
}

resource "google_logging_organization_sink" "audit" {
  name                   = "org-audit-central"
  org_id                 = var.organization_id
  destination            = "logging.googleapis.com/${google_logging_project_bucket_config.central.id}"
  include_children       = true
  unique_writer_identity = true
  filter                 = "logName:\"cloudaudit.googleapis.com\" OR logName:\"externalaudit.googleapis.com\""
}

resource "google_project_iam_member" "sink_writer" {
  project = var.logging_project_id
  role    = "roles/logging.bucketWriter"
  member  = google_logging_organization_sink.audit.writer_identity
}
