output "perimeter_resource_name" {
  value       = google_access_context_manager_service_perimeter.restricted.name
  description = "Service perimeter resource name."
}
