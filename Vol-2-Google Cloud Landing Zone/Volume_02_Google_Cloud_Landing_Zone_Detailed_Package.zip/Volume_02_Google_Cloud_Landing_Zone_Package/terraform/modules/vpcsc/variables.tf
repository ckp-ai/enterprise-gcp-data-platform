variable "access_policy_id" {
  description = "Access Context Manager access policy ID."
  type        = string
}

variable "perimeter_name" {
  description = "Short service perimeter identifier."
  type        = string
}

variable "perimeter_title" {
  description = "Human-readable service perimeter title."
  type        = string
}

variable "protected_project_numbers" {
  description = "Numeric project numbers protected by the perimeter."
  type        = set(string)
}

variable "restricted_services" {
  description = "Service APIs restricted by the perimeter."
  type        = set(string)
}
