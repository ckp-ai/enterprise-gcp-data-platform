resource "google_access_context_manager_service_perimeter" "restricted" {
  parent = "accessPolicies/${var.access_policy_id}"
  name   = "accessPolicies/${var.access_policy_id}/servicePerimeters/${var.perimeter_name}"
  title  = var.perimeter_title
  status {
    resources           = [for p in var.protected_project_numbers : "projects/${p}"]
    restricted_services = var.restricted_services
  }
}
