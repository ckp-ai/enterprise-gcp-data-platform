output "network_id" {
  description = "Fully qualified Shared VPC network ID."
  value       = google_compute_network.shared.id
}

output "subnet_self_links" {
  description = "Map of subnet self links."
  value       = { for name, subnet in google_compute_subnetwork.regional : name => subnet.self_link }
}
