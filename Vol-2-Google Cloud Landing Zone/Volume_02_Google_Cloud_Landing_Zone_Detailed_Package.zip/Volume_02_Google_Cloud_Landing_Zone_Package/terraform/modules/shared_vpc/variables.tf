variable "host_project_id" {
  description = "Project ID that owns the Shared VPC."
  type        = string
}

variable "network_name" {
  description = "Name of the custom-mode Shared VPC network."
  type        = string
}

variable "routing_mode" {
  description = "Dynamic routing mode. Use GLOBAL only after validating cross-region route requirements."
  type        = string
  default     = "REGIONAL"
  validation {
    condition     = contains(["REGIONAL", "GLOBAL"], var.routing_mode)
    error_message = "routing_mode must be REGIONAL or GLOBAL."
  }
}

variable "subnets" {
  description = "Map of subnet definitions keyed by subnet name."
  type = map(object({
    region           = string
    primary_cidr     = string
    secondary_ranges = map(string)
    flow_sampling    = optional(number, 0.5)
  }))
}
