resource "google_compute_network" "shared" {
  project                         = var.host_project_id
  name                            = var.network_name
  auto_create_subnetworks         = false
  routing_mode                    = var.routing_mode
  delete_default_routes_on_create = true
}

resource "google_compute_subnetwork" "regional" {
  for_each                 = var.subnets
  project                  = var.host_project_id
  name                     = each.key
  region                   = each.value.region
  network                  = google_compute_network.shared.id
  ip_cidr_range            = each.value.primary_cidr
  private_ip_google_access = true
  dynamic "secondary_ip_range" {
    for_each = each.value.secondary_ranges
    content {
      range_name    = secondary_ip_range.key
      ip_cidr_range = secondary_ip_range.value
    }
  }
  log_config {
    aggregation_interval = "INTERVAL_5_SEC"
    flow_sampling        = each.value.flow_sampling
    metadata             = "INCLUDE_ALL_METADATA"
  }
}
