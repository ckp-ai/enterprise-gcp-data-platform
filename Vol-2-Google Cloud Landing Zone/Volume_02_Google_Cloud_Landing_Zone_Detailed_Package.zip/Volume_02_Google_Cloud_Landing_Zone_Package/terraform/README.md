# Google Cloud Landing Zone Terraform Reference

This reference implementation illustrates a layered enterprise foundation. Replace example identifiers, CIDR blocks, billing accounts and organization IDs before deployment. Validate organization-policy constraints and service compatibility in a non-production organization or folder first.

## Layers
1. bootstrap - state, seed project and CI identity
2. organization - folders, policies, logging and security activation
3. networks - Shared VPC, subnets, DNS, PSC and hybrid connectivity
4. project-factory - service projects, APIs, IAM and budgets
5. security - KMS, VPC Service Controls, SCC and centralized logging
