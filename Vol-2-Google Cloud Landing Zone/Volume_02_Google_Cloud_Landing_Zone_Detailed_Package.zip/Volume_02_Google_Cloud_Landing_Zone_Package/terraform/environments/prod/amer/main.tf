module "customer_data_project" {
  source                     = "../../../modules/project_factory"
  display_name               = "Customer Data Production"
  project_id                 = "prj-data-customer-prd-us-001"
  folder_id                  = var.production_amer_folder_id
  billing_account_id         = var.billing_account_id
  shared_vpc_host_project_id = var.prod_amer_host_project_id
  services = [
    "bigquery.googleapis.com",
    "storage.googleapis.com",
    "logging.googleapis.com",
    "monitoring.googleapis.com"
  ]
  labels = {
    environment   = "prod"
    region_group  = "amer"
    domain        = "customer"
    cost_center   = "cc-4100"
    managed_by    = "terraform"
  }
}
