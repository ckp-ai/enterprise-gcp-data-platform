variable "production_amer_folder_id" { type = string }
variable "billing_account_id" { type = string }
variable "prod_amer_host_project_id" { type = string }
