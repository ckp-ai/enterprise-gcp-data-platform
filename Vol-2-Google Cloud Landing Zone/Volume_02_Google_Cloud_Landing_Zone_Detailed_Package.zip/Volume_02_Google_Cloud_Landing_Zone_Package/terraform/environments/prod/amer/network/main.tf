module "prod_amer_shared_vpc" {
  source          = "../../../../modules/shared_vpc"
  host_project_id = var.host_project_id
  network_name    = "vpc-prod-amer-shared"
  routing_mode    = "GLOBAL"

  subnets = {
    "sn-uscentral1-data-01" = {
      region       = "us-central1"
      primary_cidr = "10.16.0.0/22"
      secondary_ranges = {
        "pods"     = "10.17.0.0/16"
        "services" = "10.18.0.0/20"
      }
      flow_sampling = 0.5
    }
  }
}
