# Google Cloud Landing Zone Validation Checklist

Use this checklist before onboarding production workloads. Each item requires an accountable owner, test evidence, an exception decision where it fails, and a remediation date.

## Governance and hierarchy
- [ ] Authoritative Google Cloud organization established and recovery owners confirmed.
- [ ] Folder hierarchy maps to durable governance boundaries.
- [ ] Production, non-production, development and sandbox separated.
- [ ] Every project has owner, cost center, environment, criticality and lifecycle metadata.
- [ ] Exception process includes compensating controls and expiry.

## Network
- [ ] Shared VPC host projects centrally administered.
- [ ] IP ranges reconciled with enterprise IPAM and other clouds.
- [ ] Private Google Access enabled for private workloads.
- [ ] PSC, private APIs and DNS resolution tested.
- [ ] Hierarchical and network firewall policies pass positive and negative tests.
- [ ] Redundant Interconnect/VPN paths survive component failures.
- [ ] Cloud NAT capacity, logging and approved egress tested.
- [ ] Flow, DNS and firewall logs reach central destinations.

## Identity and access
- [ ] Workforce federation and phishing-resistant MFA validated.
- [ ] External workforce pools have narrow attribute conditions.
- [ ] Workload Identity Federation used for CI/CD and external workloads.
- [ ] Service-account key creation/upload prohibited by default.
- [ ] Privileged access is time-bound and approval-controlled.
- [ ] Break-glass identities and recovery process tested.
- [ ] Privileged groups have named owners and review cadence.

## Security
- [ ] Organization-policy baseline enforced and effective state recorded.
- [ ] SCC findings route to accountable owners and enterprise SIEM/SOAR.
- [ ] Restricted projects are in approved VPC Service Controls perimeters.
- [ ] Perimeter ingress/egress and denied paths tested.
- [ ] Secret Manager access is least privilege and audited.
- [ ] CMEK/HSM keys follow separation of duties, rotation and recovery controls.

## Logging, monitoring and operations
- [ ] Mandatory audit and security logs route centrally.
- [ ] Log retention, locked retention and delegated views validated.
- [ ] Foundation SLOs, dashboards and alerts are active.
- [ ] Critical alerts page accountable responders.
- [ ] Runbooks contain diagnosis, mitigation, rollback and escalation.
- [ ] Terraform drift detection is operational.

## Project factory
- [ ] Standard project provisions end-to-end through CI/CD.
- [ ] Billing, labels, APIs and IAM validate automatically.
- [ ] Shared VPC attachment and subnet IAM are correct.
- [ ] Logging, monitoring, SCC and perimeter registration are automatic.
- [ ] Project retirement uses hold, approval and recovery window.
- [ ] Sandbox expiry, budgets and quotas are enforced.
