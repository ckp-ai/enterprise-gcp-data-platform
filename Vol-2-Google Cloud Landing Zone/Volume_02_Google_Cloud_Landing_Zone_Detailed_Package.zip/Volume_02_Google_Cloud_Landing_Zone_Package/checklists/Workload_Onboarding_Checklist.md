# Workload Onboarding Checklist

- [ ] Business owner, technical owner, support team and cost center assigned.
- [ ] Environment, geography, data classification and criticality approved.
- [ ] Project type and folder placement selected.
- [ ] APIs, quotas and service agents identified.
- [ ] Shared VPC, subnet, route, DNS and egress requirements approved.
- [ ] IAM groups, runtime identities and deployment identities defined.
- [ ] VPC Service Controls compatibility and flows assessed.
- [ ] CMEK requirement and key location determined.
- [ ] Audit logging, monitoring, alerting and SLOs defined.
- [ ] Backup, recovery, RTO and RPO requirements approved.
- [ ] FinOps labels, budget and forecast recorded.
- [ ] Production readiness and security review completed.
