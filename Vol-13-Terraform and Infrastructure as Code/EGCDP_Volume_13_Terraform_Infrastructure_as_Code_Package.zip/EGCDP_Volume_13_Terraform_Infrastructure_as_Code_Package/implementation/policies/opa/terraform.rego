package egcdp.terraform
import rego.v1

deny contains msg if {
  some rc in input.resource_changes
  rc.type == "google_storage_bucket"
  after := rc.change.after
  not after.uniform_bucket_level_access
  msg := sprintf("Bucket %s must enable uniform bucket-level access",[rc.address])
}
deny contains msg if {
  some rc in input.resource_changes
  rc.type == "google_project"
  rc.change.after.auto_create_network
  msg := sprintf("Project %s must not create a default VPC",[rc.address])
}
