#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR=${1:?}; ADDRESS=${2:?}; RESOURCE_ID=${3:?}; BACKEND=${4:?}
terraform -chdir="$ROOT_DIR" init -input=false -backend-config="$BACKEND"
terraform -chdir="$ROOT_DIR" import "$ADDRESS" "$RESOURCE_ID"
terraform -chdir="$ROOT_DIR" plan -refresh-only -detailed-exitcode || rc=$?
if [[ ${rc:-0} -eq 1 ]]; then echo 'Import validation failed' >&2; exit 1; fi
