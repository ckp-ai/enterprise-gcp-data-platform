#!/usr/bin/env bash
set -euo pipefail
VERSION=${1:?semantic version}; MODULE_DIR=${2:?}
terraform -chdir="$MODULE_DIR" fmt -check -recursive
terraform -chdir="$MODULE_DIR" init -backend=false -input=false
terraform -chdir="$MODULE_DIR" validate
git diff --exit-code
git tag -s "$VERSION" -m "Module release $VERSION"
echo "Signed tag $VERSION created; publish through the approved release workflow."
