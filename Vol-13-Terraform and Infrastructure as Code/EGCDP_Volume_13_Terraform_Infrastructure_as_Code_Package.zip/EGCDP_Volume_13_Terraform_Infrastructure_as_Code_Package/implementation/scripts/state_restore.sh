#!/usr/bin/env bash
set -euo pipefail
BUCKET=${1:?}; OBJECT=${2:?}; GENERATION=${3:?}; RESTORE_FILE=${4:-terraform.tfstate.recovered}
gcloud storage cp "gs://${BUCKET}/${OBJECT}#${GENERATION}" "$RESTORE_FILE"
terraform show "$RESTORE_FILE" >/dev/null
printf 'Recovered state validated locally: %s
' "$RESTORE_FILE"
printf 'Use terraform state push only under the approved incident runbook and dual authorization.
'
