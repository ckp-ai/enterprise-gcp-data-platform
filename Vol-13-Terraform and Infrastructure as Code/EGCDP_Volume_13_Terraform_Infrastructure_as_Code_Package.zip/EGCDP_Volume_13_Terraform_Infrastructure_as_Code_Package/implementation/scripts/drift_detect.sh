#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR=${1:?root directory}; BACKEND=${2:?backend config}; TFVARS=${3:?tfvars}
terraform -chdir="$ROOT_DIR" init -input=false -backend-config="$BACKEND"
set +e
terraform -chdir="$ROOT_DIR" plan -refresh-only -detailed-exitcode -input=false -lock-timeout=10m -var-file="$TFVARS" -out=drift.tfplan
rc=$?
set -e
case "$rc" in 0) echo 'No drift';; 2) terraform -chdir="$ROOT_DIR" show -json drift.tfplan > drift.json; echo 'Drift detected'; exit 2;; *) echo 'Drift check failed'; exit "$rc";; esac
