#!/usr/bin/env bash
set -euo pipefail
PROJECT_ID=${1:?}; OUTPUT_DIR=${2:-tf-export}
mkdir -p "$OUTPUT_DIR"
gcloud beta resource-config bulk-export --project="$PROJECT_ID" --resource-format=terraform --path="$OUTPUT_DIR"
echo 'Generated configuration is discovery input. Refactor into approved modules before import.'
