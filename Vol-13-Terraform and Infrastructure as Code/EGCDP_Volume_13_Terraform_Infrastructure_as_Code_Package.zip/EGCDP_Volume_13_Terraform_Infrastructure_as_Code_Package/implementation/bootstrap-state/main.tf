provider "google" { project = var.bootstrap_project_id
 region = var.region }
resource "google_storage_bucket" "terraform_state" {
  name                        = var.state_bucket_name
  project                     = var.bootstrap_project_id
  location                    = var.location
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = false
  versioning { enabled = true }
  retention_policy { retention_period = var.retention_seconds }
  encryption { default_kms_key_name = var.kms_key_name }
  lifecycle { prevent_destroy = true }
}
resource "google_storage_bucket_iam_member" "state_admin" {
  for_each = toset(var.state_admin_members)
  bucket   = google_storage_bucket.terraform_state.name
  role     = "roles/storage.objectAdmin"
  member   = each.value
}
