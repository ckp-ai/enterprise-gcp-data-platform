variable "bootstrap_project_id" { type = string }
variable "state_bucket_name" { type = string }
variable "location" { type = string }
variable "region" { type = string }
variable "kms_key_name" { type = string }
variable "retention_seconds" { type = number
 default = 2592000 }
variable "state_admin_members" { type = list(string) }
