mock_provider "google" {}
run "valid_project" {
  command = plan
  variables { project_name="Sales Dev"
 project_id="egcdp-sales-dev-data"
 folder_id="folders/123"
 billing_account_id="000000-000000-000000"
 environment="dev"
 labels={domain="sales"}
 services=["bigquery.googleapis.com"]
 group_role_bindings={} }
  assert { condition=google_project.this.auto_create_network==false
 error_message="Default network must be disabled." }
}
