from pathlib import Path
import re
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
errors: list[str] = []

for path in root.rglob("*.tf"):
    text = path.read_text(encoding="utf-8")
    if (
        'resource "google_project"' in text
        and "auto_create_network = false" not in text
        and "auto_create_network=false" not in text
    ):
        errors.append(f"{path}: project must disable the default network")
    if re.search(r"-----BEGIN (RSA |EC )?PRIVATE KEY-----", text):
        errors.append(f"{path}: private key detected")

if errors:
    print("\n".join(errors))
    raise SystemExit(1)

print("repository policy checks passed")
