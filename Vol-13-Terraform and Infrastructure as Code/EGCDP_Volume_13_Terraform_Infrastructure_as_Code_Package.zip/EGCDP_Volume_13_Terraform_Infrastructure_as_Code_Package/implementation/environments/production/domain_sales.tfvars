project_name="Sales Production Data"
 project_id="egcdp-sales-prd-data"
 environment="prd"
 domain="sales"
 cost_center="cc4102"
 region="us-central1"
 location="US"
 dataset_id="sales_curated"
 topic_name="sales-events-v1"
 repository_id="data-pipelines"
services=["bigquery.googleapis.com","storage.googleapis.com","pubsub.googleapis.com","dataflow.googleapis.com","artifactregistry.googleapis.com"]
group_role_bindings={"roles/viewer"=["group:gcp-sales-data-operators@example.com"]}
