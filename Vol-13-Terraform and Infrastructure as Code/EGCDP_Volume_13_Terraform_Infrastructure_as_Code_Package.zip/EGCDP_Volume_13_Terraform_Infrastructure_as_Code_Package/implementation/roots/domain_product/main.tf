terraform { backend "gcs" {} }
provider "google" { project=var.project_id
 region=var.region }
module "project" { source="../../modules/project_factory"
 project_name=var.project_name
 project_id=var.project_id
 folder_id=var.folder_id
 billing_account_id=var.billing_account_id
 environment=var.environment
 labels=local.labels
 services=var.services
 group_role_bindings=var.group_role_bindings }
module "data_platform" { source="../../modules/data_platform"
 project_id=module.project.project_id
 location=var.location
 region=var.region
 kms_key_name=var.kms_key_name
 landing_bucket=var.landing_bucket
 dataset_id=var.dataset_id
 topic_name=var.topic_name
 repository_id=var.repository_id
 labels=local.labels }
locals { labels={environment=var.environment,domain=var.domain,cost_center=var.cost_center,managed_by="terraform"} }
