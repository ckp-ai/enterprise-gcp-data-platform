resource "google_project_iam_member" "bindings" {
  for_each = { for x in flatten([for role,members in var.bindings : [for member in members : {key="${role}|${member}",role=role,member=member}]]) : x.key=>x }
  project=var.project_id
 role=each.value.role
 member=each.value.member
  condition { title=var.condition.title
 description=var.condition.description
 expression=var.condition.expression }
}
