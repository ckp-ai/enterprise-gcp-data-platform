variable "project_id" { type=string }
variable "bindings" { type=map(set(string)) }
variable "condition" { type=object({title=string,description=string,expression=string})
 default={title="managed-access",description="Terraform-managed conditional access",expression="true"} }
