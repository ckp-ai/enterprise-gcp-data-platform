resource "google_monitoring_alert_policy" "policies" {
  for_each=var.alerts
 project=var.project_id
 display_name=each.value.display_name
 combiner="OR"
  conditions { display_name=each.value.display_name
 condition_threshold { filter=each.value.filter
 comparison=each.value.comparison
 threshold_value=each.value.threshold
 duration=each.value.duration } }
  notification_channels=var.notification_channels
 user_labels=merge(var.labels,{managed_by="terraform"})
}
