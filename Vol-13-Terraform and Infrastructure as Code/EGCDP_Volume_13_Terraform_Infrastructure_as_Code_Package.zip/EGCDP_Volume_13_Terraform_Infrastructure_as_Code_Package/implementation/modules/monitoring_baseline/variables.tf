variable "project_id" {type=string}
 variable "notification_channels" {type=list(string)}
 variable "labels" {type=map(string)
default={}}
variable "alerts" {type=map(object({display_name=string,filter=string,comparison=string,threshold=number,duration=string}))}
