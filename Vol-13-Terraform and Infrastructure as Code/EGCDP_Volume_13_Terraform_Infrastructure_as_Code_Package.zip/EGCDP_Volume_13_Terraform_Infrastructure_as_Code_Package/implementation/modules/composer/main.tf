resource "google_composer_environment" "this" { provider=google-beta
 project=var.project_id
 region=var.region
 name=var.name
 config { environment_size=var.environment_size
 node_config { service_account=var.service_account_email
 network=var.network
 subnetwork=var.subnetwork
 ip_allocation_policy { use_ip_aliases=true } } software_config { image_version=var.image_version
 env_variables=var.env_variables } encryption_config { kms_key_name=var.kms_key_name } } }
