terraform {
  required_providers { google = { source = "hashicorp/google" } }
}
resource "google_project" "this" {
  name                = var.project_name
  project_id          = var.project_id
  folder_id           = var.folder_id
  billing_account     = var.billing_account_id
  auto_create_network = false
  labels              = merge(var.labels,{managed_by="terraform",environment=var.environment})
}
resource "google_project_service" "apis" {
  for_each = toset(var.services)
  project  = google_project.this.project_id
  service  = each.value
  disable_on_destroy = false
}
resource "google_project_iam_member" "group_roles" {
  for_each = { for binding in flatten([for role,members in var.group_role_bindings : [for member in members : { key="${role}|${member}",role=role,member=member }]]) : binding.key => binding }
  project = google_project.this.project_id
  role    = each.value.role
  member  = each.value.member
}
