output "project_id" { value = google_project.this.project_id }
output "project_number" { value = google_project.this.number }
output "enabled_services" { value = sort([for s in google_project_service.apis : s.service]) }
