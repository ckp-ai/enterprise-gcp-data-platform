resource "google_logging_organization_sink" "central" { org_id=var.organization_id
 name=var.sink_name
 destination="storage.googleapis.com/${var.archive_bucket}"
 include_children=true
 filter=var.filter }
resource "google_storage_bucket_iam_member" "writer" { bucket=var.archive_bucket
 role="roles/storage.objectCreator"
 member=google_logging_organization_sink.central.writer_identity }
