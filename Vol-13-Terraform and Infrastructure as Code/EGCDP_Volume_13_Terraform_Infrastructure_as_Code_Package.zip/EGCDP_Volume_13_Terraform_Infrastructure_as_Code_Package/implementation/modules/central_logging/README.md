# Modules / Central Logging

## Purpose
Provides the Volume 13 implementation starter for modules/central_logging.

## Prerequisites
- Approved Google Cloud organization/project scope, billing, locations, APIs and quotas.
- Keyless CI identity or approved service-account impersonation.
- Secured remote state backend, module/provider version policy and change record.
- Architecture, security, network, SRE, DR and FinOps approvals appropriate to the root.

## Configuration
Replace illustrative project IDs, folders, billing accounts, groups, regions, locations, KMS keys and notification channels through reviewed environment configuration. Do not place credentials or secrets in HCL, tfvars, backend files, logs or state where avoidable. Revalidate current Terraform core/provider versions and Google Cloud resource schemas before use.

## Error handling and logging
Use non-interactive execution, bounded state-lock timeouts, detailed exit codes, structured Cloud Build logs and preserved plan/apply evidence. Stop on policy failure, changed approved plan, lock failure or unexpected destructive action.

## Security considerations
Use separate plan and apply identities, least privilege, Workload Identity Federation or impersonation, protected state, private access where required, VPC Service Controls where supported, CMEK by classification and independent production approval.

## Testing instructions
Run format, init without production mutation, validate, lint, security scan, policy tests, Terraform tests, integration tests in an ephemeral project, upgrade tests and a reviewed no-destructive-change plan.

## Deployment instructions
Promote a pinned module/provider version through the Volume 9 pipeline. Apply the exact reviewed plan using the scoped environment identity. Run post-apply asset, security, monitoring, connectivity and cost-label validation.

## Rollback instructions
Treat rollback as a new reviewed desired-state change. Prefer configuration revert or forward-fix and service-native recovery for data/stateful services. Use Terraform state commands only under the approved state-recovery runbook.

## Production limitations
These are production-oriented starters, not universal drop-in configurations. Validate current provider arguments, service lifecycle, quotas, regions, IAM, CMEK, VPC Service Controls, destructive behavior and organizational policies for the target enterprise.

## Included files
- `main.tf`
- `variables.tf`
