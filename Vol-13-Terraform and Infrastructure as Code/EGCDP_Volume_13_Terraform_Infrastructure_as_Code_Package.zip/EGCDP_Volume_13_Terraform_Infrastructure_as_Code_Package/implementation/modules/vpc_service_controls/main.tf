resource "google_access_context_manager_service_perimeter" "restricted" {
  parent="accessPolicies/${var.access_policy_id}"
 name="accessPolicies/${var.access_policy_id}/servicePerimeters/${var.perimeter_name}"
 title=var.perimeter_name
 perimeter_type="PERIMETER_TYPE_REGULAR"
  status { resources=[for p in var.project_numbers:"projects/${p}"]
 restricted_services=var.restricted_services
 access_levels=var.access_levels }
}
