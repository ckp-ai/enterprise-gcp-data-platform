variable "project_id" {type=string}
 variable "location" {type=string}
 variable "key_ring_name" {type=string}
variable "keys" { type=map(object({rotation_period=string,encrypters=set(string)})) }
