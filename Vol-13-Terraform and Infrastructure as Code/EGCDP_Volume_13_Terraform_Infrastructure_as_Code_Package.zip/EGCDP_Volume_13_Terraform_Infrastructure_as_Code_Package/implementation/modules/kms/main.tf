resource "google_kms_key_ring" "this" { project=var.project_id
 location=var.location
 name=var.key_ring_name }
resource "google_kms_crypto_key" "keys" {
  for_each=var.keys
 name=each.key
 key_ring=google_kms_key_ring.this.id
  rotation_period=each.value.rotation_period
 purpose="ENCRYPT_DECRYPT"
  lifecycle { prevent_destroy=true }
}
resource "google_kms_crypto_key_iam_member" "encrypters" {
  for_each={for x in flatten([for key,cfg in var.keys:[for member in cfg.encrypters:{id="${key}|${member}",key=key,member=member}]]) : x.id=>x}
  crypto_key_id=google_kms_crypto_key.keys[each.value.key].id
 role="roles/cloudkms.cryptoKeyEncrypterDecrypter"
 member=each.value.member
}
