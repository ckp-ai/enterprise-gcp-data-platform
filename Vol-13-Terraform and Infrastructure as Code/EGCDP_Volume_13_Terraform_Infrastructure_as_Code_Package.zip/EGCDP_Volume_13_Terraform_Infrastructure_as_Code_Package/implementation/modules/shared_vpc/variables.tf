variable "host_project_id" { type=string }
variable "network_name" { type=string }
variable "service_project_ids" { type=set(string) }
variable "subnets" { type=map(object({region=string,cidr=string,secondary_ranges=map(string)})) }
