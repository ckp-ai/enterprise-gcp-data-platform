resource "google_compute_network" "this" {
  project                 = var.host_project_id
  name                    = var.network_name
  auto_create_subnetworks = false
  routing_mode            = "GLOBAL"
  delete_default_routes_on_create = false
}
resource "google_compute_subnetwork" "regional" {
  for_each                 = var.subnets
  project                  = var.host_project_id
  region                   = each.value.region
  name                     = each.key
  ip_cidr_range            = each.value.cidr
  network                  = google_compute_network.this.id
  private_ip_google_access = true
  dynamic "secondary_ip_range" { for_each=each.value.secondary_ranges
 content { range_name=secondary_ip_range.key
 ip_cidr_range=secondary_ip_range.value } }
  log_config { aggregation_interval="INTERVAL_5_SEC"
 flow_sampling=0.5
 metadata="INCLUDE_ALL_METADATA" }
}
resource "google_compute_shared_vpc_host_project" "host" { project = var.host_project_id }
resource "google_compute_shared_vpc_service_project" "service" { for_each=toset(var.service_project_ids)
 host_project=var.host_project_id
 service_project=each.value }
