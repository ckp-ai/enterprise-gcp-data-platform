# ADR-1311 - Use semantic versioning and signed module releases

## ADR ID
ADR-1311

## Decision title
Use semantic versioning and signed module releases

## Status
Approved reference decision

## Date
12 July 2026

## Architecture domain
Terraform and Infrastructure as Code

## Problem
The enterprise requires repeatable, secure and auditable infrastructure delivery across organization, platform, data and domain scopes.

## Context
Fortune 100 scale, multiple regions and jurisdictions, regulated data, federated domain teams and shared platform controls create high change volume and blast-radius risk.

## Decision drivers
Repeatability; least privilege; state integrity; policy enforcement; recovery; modularity; developer productivity; cost attribution; auditability.

## Constraints
Existing resources, regional/provider support, service quotas, independent security duties, legacy repositories and staged migration.

## Assumptions
GitHub Enterprise and Cloud Build pipelines from Volume 9; Zero Trust controls from Volume 8; SLO and DR controls from Volumes 11-12.

## Alternatives considered
Manual console operations; custom scripts; monolithic Terraform; alternate IaC engine; managed deployment service only.

## Evaluation criteria
Security, blast radius, lifecycle fit, testability, recovery, portability, support, adoption effort and total economics.

## Decision
Consumers pin module versions; major changes require migration guidance and staged upgrade validation.

## Rationale
The decision creates a controlled paved road while preserving workload-specific lifecycles and independent authorization.

## Benefits
Consistent controls, faster onboarding, lower drift, reproducible recovery and auditable evidence.

## Tradeoffs
Module engineering, migration effort, provider lifecycle management and additional CI controls.

## Positive consequences
Teams consume supported patterns; state and ownership are explicit; policy is automated.

## Negative consequences
Some urgent or legacy changes require exception workflows and later reconciliation.

## Risks
Mis-scoped state, provider defects, overprivileged automation, breaking modules or incomplete imports.

## Mitigations
Small roots, pinned versions, tests, scoped identities, policy gates, recovery exercises and staged rollouts.

## Implementation implications
Update repositories, module catalog, CI pipelines, state backends, policies, runbooks and ownership records.

## Cost implications
Platform module and CI investment is offset by reduced repeated engineering, incidents and audit effort. Track build, state, logging and managed-service costs.

## Security implications
State is sensitive; use keyless identity, least privilege, audit, VPC Service Controls where applicable, CMEK by classification and no secrets in source.

## Operational implications
Named root/module owners, drift response, provider/module upgrade cadence, state recovery and support escalation are required.

## Review triggers
Material Terraform/provider/backend change, new Google Cloud service, major incident, repeated drift, compliance change or managed-service capability change.

## Review date
12 October 2026 or earlier trigger
