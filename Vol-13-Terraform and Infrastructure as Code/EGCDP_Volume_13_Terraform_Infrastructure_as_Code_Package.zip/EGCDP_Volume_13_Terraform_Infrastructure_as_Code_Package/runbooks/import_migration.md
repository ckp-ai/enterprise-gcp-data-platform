# Existing-resource adoption runbook

Inventory and assign an owner; bulk export only as discovery input; map the resource to an approved module; create import blocks or a controlled import command in a sandbox backend; validate a no-destroy/no-recreate plan; test dependencies and policy; approve the state lineage; migrate to the production root; record the original resource ID, state serial, module version and plan evidence; enable drift detection. Never import resources whose ownership, lifecycle or destructive behavior is unknown.
