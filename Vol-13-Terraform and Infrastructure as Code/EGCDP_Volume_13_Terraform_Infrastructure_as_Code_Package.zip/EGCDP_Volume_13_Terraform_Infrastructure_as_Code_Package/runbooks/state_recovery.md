# Terraform state recovery runbook

1. Declare an incident and freeze applies for the affected root.
2. Confirm root, backend bucket, prefix, last known good generation and change window.
3. Preserve audit logs and current object generation.
4. Restore the candidate version to an isolated file; run `terraform show` and security checks.
5. Reinitialize a clean runner with recovered source, provider lock file and backend configuration.
6. Compare candidate state to live resources using refresh-only plan.
7. Obtain dual authorization from the platform owner and security/incident authority.
8. Use `terraform state push` only when code reconciliation cannot safely repair the mapping.
9. Run a normal plan, apply only approved corrections, and validate controls, monitoring and cost labels.
10. Close with evidence, root cause, regression test and restoration of scheduled drift detection.
