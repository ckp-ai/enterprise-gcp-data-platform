# Terraform rollback and forward-fix runbook

Terraform rollback is a controlled new change, not an automatic reversal of state. Prefer reverting configuration and applying a reviewed plan. Use service-native restoration for data or stateful resources. Use state operations only to repair mapping under incident control. Never edit state manually. Preserve the failed plan and apply log, confirm deletion/recreation risk, and validate dependent resources after recovery.
