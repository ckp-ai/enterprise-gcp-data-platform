# Official documentation baseline

Validated 12 July 2026. Revalidate provider versions, resource arguments, preview/beta status, locations, quotas, IAM, VPC Service Controls, CMEK and service lifecycle during implementation.

- [Terraform on Google Cloud](https://docs.cloud.google.com/docs/terraform)
- [General style and structure best practices](https://docs.cloud.google.com/docs/terraform/best-practices/general-style-structure)
- [Reusable module best practices](https://docs.cloud.google.com/docs/terraform/best-practices/reusable-modules)
- [Terraform operations best practices](https://docs.cloud.google.com/docs/terraform/best-practices/operations)
- [Terraform maturity model](https://docs.cloud.google.com/docs/terraform/maturity)
- [Store Terraform state in Cloud Storage](https://docs.cloud.google.com/docs/terraform/resource-management/store-state)
- [Export Google Cloud resources to Terraform](https://docs.cloud.google.com/docs/terraform/resource-management/export)
- [Import Google Cloud resources into state](https://docs.cloud.google.com/docs/terraform/resource-management/import)
- [Policy validation](https://docs.cloud.google.com/docs/terraform/policy-validation)
- [Validate policies](https://docs.cloud.google.com/docs/terraform/policy-validation/validate-policies)
- [Cloud Build with Terraform](https://docs.cloud.google.com/build/docs/terraform)
- [Managing IaC with Terraform and Cloud Build](https://docs.cloud.google.com/docs/terraform/resource-management/managing-infrastructure-as-code)
- [Infrastructure Manager overview](https://docs.cloud.google.com/infrastructure-manager/docs/overview)
- [Terraform and Infrastructure Manager](https://docs.cloud.google.com/infrastructure-manager/docs/terraform)
- [Terraform GCS backend](https://developer.hashicorp.com/terraform/language/backend/gcs)
- [Terraform state locking](https://developer.hashicorp.com/terraform/language/state/locking)
- [Terraform state](https://developer.hashicorp.com/terraform/language/state)
