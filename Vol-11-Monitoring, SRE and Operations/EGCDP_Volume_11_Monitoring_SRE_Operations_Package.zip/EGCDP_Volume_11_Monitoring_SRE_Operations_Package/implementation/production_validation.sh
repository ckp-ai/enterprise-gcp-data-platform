#!/usr/bin/env bash
# Purpose: post-deployment observability smoke tests.
set -euo pipefail

: "${PROJECT_ID:?set PROJECT_ID}"
: "${SERVICE_ID:?set SERVICE_ID}"
: "${CANARY_METRIC:=custom.googleapis.com/observability/canary_age_seconds}"

echo "Validating active alert policies..."
gcloud monitoring policies list --project "${PROJECT_ID}" \
  --filter="userLabels.service=${SERVICE_ID}" --format="value(name)" | grep -q .

echo "Validating recent telemetry canary..."
gcloud monitoring time-series list \
  --project "${PROJECT_ID}" \
  --filter="metric.type=\"${CANARY_METRIC}\"" \
  --interval="start-time=$(date -u -d '10 minutes ago' +%FT%TZ),end-time=$(date -u +%FT%TZ)" \
  --format=json | python3 -c 'import json,sys; assert len(json.load(sys.stdin)) > 0'

echo "Validating runbook labels are present..."
gcloud monitoring policies list --project "${PROJECT_ID}" --format=json | \
python3 -c 'import json,sys; p=json.load(sys.stdin); assert all(x.get("userLabels",{}).get("runbook_id") for x in p if x.get("enabled", True))'

echo "Observability smoke tests passed."
