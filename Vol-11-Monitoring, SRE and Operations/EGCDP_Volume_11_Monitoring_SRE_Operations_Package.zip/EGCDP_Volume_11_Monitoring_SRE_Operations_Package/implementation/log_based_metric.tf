# Purpose: Detect failed security log routing/configuration operations.
resource "google_logging_metric" "security_sink_errors" {
  project = var.logging_project_id
  name    = "security_sink_configuration_errors"
  filter  = <<-EOT
    protoPayload.serviceName="logging.googleapis.com"
    protoPayload.status.code!=0
    (protoPayload.methodName:"CreateSink" OR protoPayload.methodName:"UpdateSink")
  EOT
  metric_descriptor {
    metric_kind = "DELTA"
    value_type  = "INT64"
    unit        = "1"
    display_name = "Security log sink configuration errors"
  }
}
