# Purpose: Regional operational log bucket and organization-level sink.
# Security: the sink writer receives only bucketWriter on the destination bucket.
resource "google_logging_project_bucket_config" "regional_ops" {
  project        = var.logging_project_id
  location       = var.region
  bucket_id      = "egcdp-ops-${var.region}"
  retention_days = var.retention_days
  description    = "Regional production operations and audit telemetry"
  locked         = var.lock_retention
}

resource "google_logging_organization_sink" "regional_ops" {
  name             = "egcdp-prod-${var.region}-ops"
  org_id           = var.organization_id
  destination      = "logging.googleapis.com/projects/${var.logging_project_id}/locations/${var.region}/buckets/${google_logging_project_bucket_config.regional_ops.bucket_id}"
  include_children = true
  filter = <<-EOT
    resource.labels.location="${var.region}"
    AND severity>=DEFAULT
    AND NOT jsonPayload.telemetry_class="debug_nonprod"
  EOT
}

resource "google_project_iam_member" "sink_writer" {
  project = var.logging_project_id
  role    = "roles/logging.bucketWriter"
  member  = google_logging_organization_sink.regional_ops.writer_identity
}
