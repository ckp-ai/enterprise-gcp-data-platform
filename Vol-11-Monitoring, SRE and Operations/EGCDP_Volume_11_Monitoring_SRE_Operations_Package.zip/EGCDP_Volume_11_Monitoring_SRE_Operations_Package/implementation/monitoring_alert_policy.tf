# Purpose: SLO-aligned Pub/Sub backlog alert example.
# Prerequisites: notification channel and project APIs are provisioned.
resource "google_monitoring_alert_policy" "pubsub_backlog" {
  project      = var.observability_project_id
  display_name = "prod-streaming-pubsub-oldest-unacked-age"
  combiner     = "AND"

  documentation {
    content   = "Runbook: ${var.runbook_base_url}/STR-002"
    mime_type = "text/markdown"
  }

  conditions {
    display_name = "Oldest unacked message age exceeds product threshold"
    condition_threshold {
      filter          = "resource.type=\"pubsub_subscription\" AND metric.type=\"pubsub.googleapis.com/subscription/oldest_unacked_message_age\" AND resource.label.subscription_id=monitoring.regex.full_match(\"prod-.*\")"
      comparison      = "COMPARISON_GT"
      threshold_value = var.oldest_unacked_seconds
      duration        = "300s"

      aggregations {
        alignment_period     = "60s"
        per_series_aligner   = "ALIGN_MAX"
        cross_series_reducer = "REDUCE_MAX"
        group_by_fields      = ["resource.label.subscription_id"]
      }

      trigger { count = 1 }
    }
  }

  notification_channels = [var.primary_oncall_channel]
  user_labels = {
    severity   = "high"
    service    = "streaming-platform"
    runbook_id = "str-002"
    owner      = "data-platform-sre"
  }

  alert_strategy {
    auto_close = "1800s"
    notification_rate_limit { period = "300s" }
  }

  lifecycle { prevent_destroy = true }
}
