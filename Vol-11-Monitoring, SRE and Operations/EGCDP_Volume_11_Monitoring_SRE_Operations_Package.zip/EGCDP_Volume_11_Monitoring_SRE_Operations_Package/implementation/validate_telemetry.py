"""Validate OpenTelemetry resource attributes and cardinality guardrails.

Purpose:
  Fail CI or pre-production validation when mandatory resource attributes are
  absent or when prohibited high-cardinality/sensitive attributes are present.
Security:
  This validator never logs telemetry values; it reports attribute names only.
"""
from __future__ import annotations
import json, sys
from pathlib import Path

REQUIRED = {"service.name", "service.version", "deployment.environment", "cloud.region", "egcdp.owner"}
PROHIBITED = {"enduser.id", "user.email", "http.request.body", "gen_ai.prompt", "auth.token"}

def validate(path: Path) -> list[str]:
    doc = json.loads(path.read_text(encoding="utf-8"))
    attrs = set(doc.get("resource_attributes", {}).keys())
    errors = [f"missing required attribute: {name}" for name in sorted(REQUIRED - attrs)]
    errors += [f"prohibited attribute present: {name}" for name in sorted(PROHIBITED & attrs)]
    cardinality = doc.get("estimated_cardinality", {})
    for name, estimate in cardinality.items():
        if int(estimate) > 10000:
            errors.append(f"attribute exceeds label budget: {name}")
    return errors

def main() -> int:
    if len(sys.argv) != 2:
        print("usage: validate_telemetry.py telemetry-contract.json", file=sys.stderr)
        return 2
    errors = validate(Path(sys.argv[1]))
    if errors:
        for item in errors:
            print(item, file=sys.stderr)
        return 1
    print("telemetry contract validation passed")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
