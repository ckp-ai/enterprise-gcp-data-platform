# STR-002 - Pub/Sub Backlog and Streaming Lag

## Trigger
Oldest unacked message age and backlog growth indicate the product latency SLO is burning.

## Guardrails
Do not purge, seek, detach or recreate subscriptions without incident-command approval and a documented replay point.

## First five minutes
1. Validate alert and telemetry canary.
2. Check Pub/Sub subscription metrics and Dataflow system lag together.
3. Confirm source publish rate, quota errors and recent deployments.
4. Identify affected data products and freshness impact.
5. Declare SEV1 if Tier 0 product freshness is at risk.

## Diagnosis
- Inspect oldest unacked age, num undelivered messages and delivery attempts.
- Inspect Dataflow job state, system lag, worker utilization and error logs.
- Check dead-letter topic and schema/contract failures.
- Check regional dependencies and service health.

## Mitigation
- Roll back the most recent pipeline change when correlated.
- Scale or restart only through approved deployment automation.
- Isolate poison messages to quarantine/DLQ.
- Use controlled replay after idempotency and deduplication checks.

## Validation
Backlog slope becomes negative, p99 event latency returns within SLO, no duplicate business keys, reconciliation passes and consumers confirm recovery.
