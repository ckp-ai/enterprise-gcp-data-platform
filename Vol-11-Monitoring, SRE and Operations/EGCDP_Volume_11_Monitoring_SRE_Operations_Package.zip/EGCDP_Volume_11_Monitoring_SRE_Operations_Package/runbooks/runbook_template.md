# Runbook Template

## Metadata
- Runbook ID:
- Service / data product:
- Owner:
- On-call:
- Severity eligibility:
- Last exercised:
- Related SLO / alert policy:
- Dependencies:
- Data classification:

## Trigger and user impact
Describe the signal, business/user impact, affected region and expected false-positive modes.

## Safety guardrails
List actions that require approval, actions that are reversible, blast-radius limits, and actions that are forbidden.

## First five minutes
1. Acknowledge the alert and open/attach the incident.
2. Confirm telemetry health and validate the signal from a second source.
3. Determine business impact, service tier and regional scope.
4. Check recent changes, dependencies and active maintenance.
5. Escalate according to severity.

## Diagnosis
Provide deterministic queries, dashboards and logs. Never rely on undocumented personal knowledge.

## Mitigation
List reversible mitigations in preferred order, including preconditions and stop conditions.

## Recovery validation
Define data reconciliation, freshness, quality, latency, backlog, security and consumer checks.

## Communication
Stakeholders, cadence, approved channels and regulatory/privacy escalation.

## Rollback and failback
Describe rollback, restoration of normal routing and cleanup.

## Evidence and closure
Incident record, timeline, commands, screenshots, query results, approvals and follow-up actions.

## Production limitations
State service-specific constraints, quotas and actions that require current product validation.
