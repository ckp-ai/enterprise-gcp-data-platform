# ADR-1102: Use business-service SLOs and error budgets as the primary reliability control

## ADR ID
ADR-1102

## Decision title
Use business-service SLOs and error budgets as the primary reliability control

## Status
Accepted - architecture baseline

## Date
12 July 2026

## Architecture domain
SRE governance

## Problem
Infrastructure uptime does not adequately represent data freshness, quality, analytics availability or AI service outcomes.

## Context
The platform spans global regions, regulated data, thousands of pipelines, domain-owned data products, analytics and AI services. The decision must align reliability, security, cost and federated ownership.

## Decision drivers
Consumer impact, regulatory boundaries, measurable reliability, automation, operational scalability, auditability and cost transparency.

## Constraints
Service capabilities, quotas, regional availability, existing enterprise tooling, support contracts and the unfinished Volume 9 CI/CD implementation.

## Assumptions
AMER, EMEA and APAC data planes; group-based IAM; private-by-default design; Terraform authority; Tier 0-2 recovery targets.

## Alternatives considered
Infrastructure-only thresholds; Contractual SLAs only; Business-service SLOs with error budgets

## Evaluation criteria
User impact accuracy, resilience, security, operability, portability, cost and implementation complexity.

## Decision
Define SLOs at business-service and data-product boundaries, backed by component indicators; use error budgets to govern change and reliability work.

## Rationale
The selected approach best balances managed Google Cloud capabilities with enterprise control, federated ownership and measurable outcomes.

## Benefits
Clear accountability, faster diagnosis, reduced alert noise, reproducibility, stronger audit evidence and consistent operations.

## Tradeoffs
Requires ownership and instrumentation maturity; prevents teams from optimizing components while consumers are failing.

## Positive consequences
Service health and change decisions become evidence-based and comparable across products and regions.

## Negative consequences
Teams must invest in instrumentation, ownership metadata, on-call skills and continuous maintenance.

## Risks
Inconsistent adoption, stale configuration, excessive telemetry cost, false confidence and gaps caused by product or region differences.

## Mitigations
Golden templates, readiness gates, quarterly review, telemetry canaries, training, cost dashboards and documented exceptions.

## Implementation implications
Publish modules and schemas; migrate Tier 0/1 services first; integrate with incident, change, CMDB/service catalog and security tooling.

## Cost implications
Additional telemetry and operational capacity are required; control through retention tiers, cardinality budgets, sampling and FinOps review.

## Security implications
Least-privilege access, regional data handling, redaction, audit logging and controlled automation are mandatory.

## Operational implications
Owners maintain SLOs, alerts and runbooks; SRE governs standards, incident command and reliability review.

## Review triggers
Material product change, new regulation, major incident, repeated SLO miss, cost anomaly, region expansion or support-model change.

## Review date
12 January 2027 or earlier on trigger.
