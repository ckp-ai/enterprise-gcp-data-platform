"""Purpose: create a permission-aware RAG corpus and import approved documents.

Prerequisites: Python 3.11+, google-cloud-agent-platform and google-genai packages,
ADC through Workload Identity Federation, enabled APIs, approved region and storage source.
Production note: validate current SDK names and RAG backend support before deployment.
"""
import logging
import os
from google.cloud import agentplatform
from google.genai import types

logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
LOG = logging.getLogger("rag_ingestion")

PROJECT_ID = os.environ["GOOGLE_CLOUD_PROJECT"]
LOCATION = os.getenv("GOOGLE_CLOUD_LOCATION", "us-central1")
SOURCE_URI = os.environ["RAG_SOURCE_URI"]
DISPLAY_NAME = os.getenv("RAG_CORPUS_NAME", "enterprise-policy-corpus")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-005")


def main() -> None:
    client = agentplatform.Client(project=PROJECT_ID, location=LOCATION)
    try:
        corpus = client.rag.create_corpus(
            display_name=DISPLAY_NAME,
            description="Approved enterprise policy content with source ACL metadata.",
            backend_config=types.RagManagedDbConfig(),
            embedding_model_config=types.RagEmbeddingModelConfig(
                vertex_prediction_endpoint=types.VertexPredictionEndpoint(
                    publisher_model=f"publishers/google/models/{EMBEDDING_MODEL}"
                )
            ),
        )
        LOG.info("Created corpus %s", corpus.name)
        operation = client.rag.import_files(
            corpus_name=corpus.name,
            paths=[SOURCE_URI],
            transformation_config=types.RagTransformationConfig(
                chunking_config=types.RagChunkingConfig(
                    chunk_size=768,
                    chunk_overlap=128,
                )
            ),
            max_embedding_requests_per_min=600,
        )
        result = operation.result(timeout=3600)
        LOG.info("Import completed: %s", result)
    except Exception:
        LOG.exception("RAG corpus ingestion failed")
        raise


if __name__ == "__main__":
    main()
