# RAG ingestion example
Purpose: create a managed RAG corpus and import approved documents with deterministic chunking.
Prerequisites: approved project/location, APIs, bucket and corpus IAM, service account via Workload Identity Federation, source classification and ACL design.
Configuration: environment variables select project, location, source URI, corpus and embedding model. Pin package versions in the deployment lock file.
Error handling: exceptions are logged and cause a non-zero pipeline result; orchestrators retry only idempotent import stages.
Logging: structured execution logs must be routed to central Cloud Logging with document identifiers redacted.
Security: never ingest unclassified content; preserve source ACLs in metadata; use VPC Service Controls/CMEK where supported; scan for sensitive data before indexing.
Testing: use a synthetic corpus, verify chunk boundaries, metadata, ACL filtering, retrieval quality and deletion propagation.
Deployment: package as an immutable container and invoke from an approved pipeline or Cloud Run job.
Rollback: stop import, delete failed corpus/index resources and restore the previous corpus alias after verification.
Production limitations: SDK, backend, location, quotas, VPC SC and CMEK support are product/version dependent and require current official validation.
