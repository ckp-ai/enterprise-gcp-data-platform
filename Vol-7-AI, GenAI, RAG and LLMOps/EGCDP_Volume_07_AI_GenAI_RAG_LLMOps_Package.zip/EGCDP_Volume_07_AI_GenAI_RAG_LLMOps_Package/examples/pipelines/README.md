# Vertex AI Pipeline example
Purpose: illustrate a compiled KFP v2 workflow with managed training, evaluation gate and model registration.
Prerequisites: Artifact Registry image, pipeline root, service account, BigQuery/Cloud Storage access and pinned KFP/Google Cloud Pipeline Components versions.
Configuration: replace placeholders; separate runtime service accounts by environment; pass secrets through Secret Manager rather than parameters.
Error handling: failed components stop downstream promotion; retriable infrastructure failures use bounded retries; data or quality failures require investigation.
Logging: pipeline, custom job and component logs are retained centrally and correlated with release/model versions.
Security: use private networking where required, least privilege, CMEK where supported, protected pipeline root and no user credentials in components.
Testing: unit test components, compile pipeline, run synthetic integration data, validate lineage and negative release-gate behavior.
Deployment: compile in CI, store immutable template, submit through controlled promotion and approval.
Rollback: redeploy the previous approved model alias/endpoint configuration; do not overwrite model versions.
Production limitations: sample output wiring is illustrative and must be adapted to the chosen training container and evaluation artifact contract.
