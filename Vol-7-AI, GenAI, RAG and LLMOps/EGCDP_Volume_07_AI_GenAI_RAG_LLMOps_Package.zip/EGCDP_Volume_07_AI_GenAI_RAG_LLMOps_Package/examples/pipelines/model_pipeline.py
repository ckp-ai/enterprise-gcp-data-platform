"""Purpose: production-oriented Vertex AI Pipeline skeleton for train, evaluate and register."""
from kfp import dsl
from google_cloud_pipeline_components.v1.custom_job import CustomTrainingJobOp
from google_cloud_pipeline_components.v1.model import ModelUploadOp

@dsl.component(base_image="python:3.11-slim")
def release_gate(metrics_uri: str, minimum_auc: float = 0.85) -> str:
    import json
    from google.cloud import storage
    bucket, blob = metrics_uri.removeprefix("gs://").split("/", 1)
    payload = json.loads(storage.Client().bucket(bucket).blob(blob).download_as_text())
    auc = float(payload["auc"])
    if auc < minimum_auc:
        raise RuntimeError(f"Model AUC {auc:.4f} is below threshold {minimum_auc:.4f}")
    return f"approved:auc={auc:.4f}"

@dsl.pipeline(name="egcdp-churn-training", pipeline_root="gs://REPLACE/pipeline-root")
def churn_pipeline(project: str, location: str, training_image: str, model_artifact_uri: str):
    train = CustomTrainingJobOp(
        project=project,
        location=location,
        display_name="churn-train",
        worker_pool_specs=[{
            "machine_spec": {"machine_type": "n1-standard-8"},
            "replica_count": 1,
            "container_spec": {"image_uri": training_image, "args": ["--output", model_artifact_uri]},
        }],
    )
    gate = release_gate(metrics_uri=train.outputs["gcp_resources"], minimum_auc=0.85)
    upload = ModelUploadOp(
        project=project,
        location=location,
        display_name="customer-churn",
        artifact_uri=model_artifact_uri,
        serving_container_image_uri=training_image,
    ).after(gate)
