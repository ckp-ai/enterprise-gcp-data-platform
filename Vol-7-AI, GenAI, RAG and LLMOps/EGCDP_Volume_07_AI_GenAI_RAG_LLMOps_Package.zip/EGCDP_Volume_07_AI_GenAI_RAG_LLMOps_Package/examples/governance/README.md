# Model card example
Purpose: document intended use, evidence, limits, oversight, monitoring and rollback for a governed model version.
Prerequisites: registered use case, approved model version, lineage, evaluation results and accountable owners.
Configuration: extend fields by risk tier and applicable regulation.
Security: classify the card; never include secrets or unnecessary personal data.
Testing: schema validation and cross-check against Model Registry, pipeline metadata and approval records.
Deployment: publish with the release evidence package and catalog entry.
Rollback: model card remains immutable; create a new card/version for changed behavior.
Production limitations: model cards are evidence, not a substitute for independent validation or legal assessment.
