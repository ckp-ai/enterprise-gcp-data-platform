"""Purpose: deterministic local release-gate aggregator for exported evaluation results."""
import json, logging, pathlib, sys
logging.basicConfig(level=logging.INFO)
THRESHOLDS={"groundedness":0.90,"citation_precision":0.95,"safety_pass_rate":0.995,"task_success":0.85}

def main(path: str) -> None:
    metrics=json.loads(pathlib.Path(path).read_text())
    failures=[]
    for name,minimum in THRESHOLDS.items():
        value=float(metrics.get(name,0.0))
        logging.info("metric=%s value=%s minimum=%s",name,value,minimum)
        if value < minimum: failures.append(f"{name}={value}<{minimum}")
    if failures: raise SystemExit("Release blocked: "+", ".join(failures))
    print("Release gate passed")
if __name__ == "__main__": main(sys.argv[1])
