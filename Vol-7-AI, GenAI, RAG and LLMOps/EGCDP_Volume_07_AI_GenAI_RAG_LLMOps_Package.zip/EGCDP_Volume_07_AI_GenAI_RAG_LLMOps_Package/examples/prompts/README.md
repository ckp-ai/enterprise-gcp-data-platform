# Prompt and evaluation examples
Purpose: show a versioned prompt contract, adversarial evaluation dataset and deterministic release gate.
Prerequisites: approved model alias, RAG evidence contract, evaluation service/export and governed test dataset.
Configuration: thresholds are risk-tier specific and must be approved by business, responsible-AI and security owners.
Error handling: any missing metric is treated as zero and blocks release.
Logging: retain aggregate metrics, dataset version, judge configuration and release decision; redact prompt content where required.
Security: evaluation data must not contain uncontrolled production secrets or personal data; include prompt-injection and exfiltration cases.
Testing: test both passing and failing metric files; independently review judge calibration and sampled outputs.
Deployment: execute in CI after model/prompt/retrieval changes and before environment promotion.
Rollback: restore prior immutable prompt/model/index configuration and rerun evaluation.
Production limitations: aggregate thresholds do not replace use-case-specific human review or online monitoring.
