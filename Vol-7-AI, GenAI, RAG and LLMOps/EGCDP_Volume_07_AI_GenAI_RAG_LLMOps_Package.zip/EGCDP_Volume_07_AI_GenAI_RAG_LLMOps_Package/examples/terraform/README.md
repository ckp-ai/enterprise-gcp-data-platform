# Terraform AI foundation example
Purpose: provision APIs, a runtime identity and a protected pipeline root.
Prerequisites: landing-zone project factory, organization policies, approved region/KMS key and CI deployment identity.
Configuration: use golden modules; example intentionally omits broad model/runtime resources whose provider schemas change frequently.
Error handling: CI stops on validation/plan/policy failure; apply failures are investigated before retry.
Logging: Terraform and Cloud Audit Logs are retained in central projects; state access is audited.
Security: Workload Identity Federation, protected remote state, no primitive roles, public access prevention and CMEK.
Testing: fmt, validate, provider lock, static/security scans, policy tests, plan review and nonproduction apply.
Deployment: immutable module versions promoted through environments.
Rollback: revert configuration and apply a reviewed plan; retain buckets/state when data preservation is required.
Production limitations: validate current provider resources and service-specific controls before extending this starter.
