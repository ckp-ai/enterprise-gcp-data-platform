terraform {
  required_version = ">= 1.6.0"
  required_providers { google = { source = "hashicorp/google" version = "~> 6.0" } }
}
provider "google" { project = var.project_id region = var.region }

resource "google_project_service" "apis" {
  for_each = toset(["aiplatform.googleapis.com","storage.googleapis.com","logging.googleapis.com","monitoring.googleapis.com"])
  project = var.project_id
  service = each.value
  disable_on_destroy = false
}
resource "google_service_account" "ai_runtime" {
  account_id   = "sa-ai-runtime-prod"
  display_name = "AI runtime service identity"
}
resource "google_storage_bucket" "pipeline_root" {
  name                        = "${var.project_id}-ai-pipeline-root"
  location                    = var.region
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  versioning { enabled = true }
  encryption { default_kms_key_name = var.kms_key_name }
  lifecycle_rule { condition { age = 365 } action { type = "SetStorageClass" storage_class = "ARCHIVE" } }
}
resource "google_project_iam_member" "runtime_log_writer" {
  project = var.project_id
  role    = "roles/logging.logWriter"
  member  = "serviceAccount:${google_service_account.ai_runtime.email}"
}
