# ADK agent example
Purpose: demonstrate an agent with a narrow read-only tool, input validation and explicit grounding policy.
Prerequisites: current Agent Development Kit, approved Gemini model, application default credentials and a production policy gateway.
Configuration: replace the stub with a private authenticated service; keep tool schemas narrow and versioned.
Error handling: tool errors return typed, non-sensitive responses; orchestration applies timeouts, retries and circuit breakers.
Logging: capture trace IDs, selected tools, latency, outcome and policy decisions while redacting sensitive arguments.
Security: no shell/browser/general HTTP tools; use workload identity, least privilege, egress controls, tenant context and human approval for actions.
Testing: unit test validation, trajectory/tool selection, injection resistance, cross-tenant negative cases and final-response quality.
Deployment: package and deploy through the approved Agent Runtime or application pattern with canary release.
Rollback: route traffic to the prior immutable agent version and disable risky tools centrally.
Production limitations: model identifiers, Runtime support and SDK APIs evolve and must be validated before deployment.
