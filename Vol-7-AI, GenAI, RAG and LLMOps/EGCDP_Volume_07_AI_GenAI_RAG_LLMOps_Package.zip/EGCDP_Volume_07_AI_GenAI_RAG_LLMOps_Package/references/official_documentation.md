# Official documentation validation

Appendix D in the detailed guide lists the primary Google Cloud documentation set. Validation is mandatory during implementation and quarterly architecture review. Do not use this blueprint as a substitute for current service documentation, legal advice, workload discovery, capacity testing or product licensing review.
