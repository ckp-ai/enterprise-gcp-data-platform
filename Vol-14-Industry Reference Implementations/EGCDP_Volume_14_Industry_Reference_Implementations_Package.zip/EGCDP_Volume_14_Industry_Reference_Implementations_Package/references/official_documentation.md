# Official documentation baseline

Validated for the 12 July 2026 architecture baseline. Revalidate during implementation.

- [Cloud Healthcare API](https://docs.cloud.google.com/healthcare-api/docs)
- [HIPAA compliance on Google Cloud](https://cloud.google.com/security/compliance/hipaa)
- [HHS HIPAA Security Rule](https://www.hhs.gov/hipaa/for-professionals/security/index.html)
- [Anti Money Laundering AI](https://docs.cloud.google.com/financial-services/anti-money-laundering/docs)
- [DORA Regulation](https://eur-lex.europa.eu/eli/reg/2022/2554/oj/eng)
- [FFIEC Business Continuity Management](https://ithandbook.ffiec.gov/it-booklets/business-continuity-management.aspx)
- [PCI DSS](https://www.pcisecuritystandards.org/standards/pci-dss/)
- [AI Commerce Search](https://docs.cloud.google.com/retail/docs)
- [Google Cloud retail solutions](https://cloud.google.com/solutions/retail)
- [Google Cloud telecommunications solutions](https://cloud.google.com/solutions/telecommunications)
- [Telecom Network Automation](https://docs.cloud.google.com/telecom-network-automation/docs/overview)
- [FCC CPNI privacy](https://www.fcc.gov/enforcement/areas/privacy)
- [NIS2 Directive](https://digital-strategy.ec.europa.eu/en/policies/nis2-directive)
- [GDPR](https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng)
