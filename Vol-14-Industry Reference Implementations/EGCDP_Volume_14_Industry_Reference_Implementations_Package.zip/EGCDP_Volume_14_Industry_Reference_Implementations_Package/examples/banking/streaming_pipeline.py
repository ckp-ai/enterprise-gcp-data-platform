"""Industry streaming pipeline starter: Banking.
Purpose: validate events, preserve event time, route invalid payloads and write governed BigQuery rows.
"""
import argparse, json, logging
from datetime import datetime, timezone
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions

REQUIRED={'event_id','event_time','party_id','account_id','amount','currency'}
class Parse(beam.DoFn):
    def process(self, payload, ts=beam.DoFn.TimestampParam):
        try:
            row=json.loads(payload.decode("utf-8")); missing=REQUIRED-set(row)
            if missing: raise ValueError(f"missing fields: {sorted(missing)}")
            event_time=datetime.fromisoformat(str(row["event_time"]).replace("Z","+00:00"))
            row["processed_at"]=datetime.now(timezone.utc).isoformat()
            yield beam.window.TimestampedValue(row,event_time.timestamp())
        except Exception as exc:
            logging.exception("validation_failed")
            yield beam.pvalue.TaggedOutput("invalid",{"payload":payload.decode("utf-8","replace"),"error":str(exc)[:1024],"failed_at":datetime.now(timezone.utc).isoformat()})

def run(argv=None):
    p=argparse.ArgumentParser(); p.add_argument("--subscription",required=True); p.add_argument("--output",required=True); p.add_argument("--dlq",required=True)
    known,args=p.parse_known_args(argv); opts=PipelineOptions(args,streaming=True,save_main_session=True); opts.view_as(StandardOptions).streaming=True
    with beam.Pipeline(options=opts) as pl:
        parsed=(pl|beam.io.ReadFromPubSub(subscription=known.subscription)|beam.ParDo(Parse()).with_outputs("invalid",main="valid"))
        parsed.valid|beam.io.WriteToBigQuery(known.output,method=beam.io.WriteToBigQuery.Method.STORAGE_WRITE_API,create_disposition="CREATE_NEVER",write_disposition="WRITE_APPEND",with_auto_sharding=True)
        parsed.invalid|beam.io.WriteToBigQuery(known.dlq,method=beam.io.WriteToBigQuery.Method.STORAGE_WRITE_API,create_disposition="CREATE_NEVER",write_disposition="WRITE_APPEND",with_auto_sharding=True)
if __name__=="__main__": logging.basicConfig(level=logging.INFO); run()
