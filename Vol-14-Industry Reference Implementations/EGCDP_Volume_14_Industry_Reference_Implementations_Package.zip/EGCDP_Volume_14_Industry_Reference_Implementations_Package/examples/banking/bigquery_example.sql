CREATE OR REPLACE TABLE `banking_features.aml_party_daily` PARTITION BY business_date CLUSTER BY party_id AS
SELECT business_date, party_id, COUNT(*) transaction_count, SUM(ABS(amount_base)) turnover,
       COUNT(DISTINCT counterparty_country) country_count, MAX(event_time) latest_event
FROM `banking_curated.transaction` GROUP BY business_date, party_id;
