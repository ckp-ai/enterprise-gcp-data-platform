CREATE OR REPLACE VIEW `healthcare_semantic.patient_360` AS
SELECT patient_token, ARRAY_AGG(STRUCT(encounter_id, encounter_type, start_ts, end_ts) ORDER BY start_ts DESC LIMIT 100) encounters,
       MAX(updated_at) AS data_freshness_ts
FROM `healthcare_curated.encounter`
WHERE permitted_for_analytics = TRUE
GROUP BY patient_token;
