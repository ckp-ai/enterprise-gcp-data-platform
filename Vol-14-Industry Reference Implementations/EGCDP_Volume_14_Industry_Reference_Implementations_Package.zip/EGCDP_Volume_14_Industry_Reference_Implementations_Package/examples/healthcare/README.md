# Healthcare implementation examples
Purpose: demonstrate an industry-specific streaming contract, curated BigQuery interface, governed AI prompt and environment configuration.

Prerequisites: approved source contract, synthetic test data, dedicated workload identity, regional BigQuery datasets, quarantine table, Dataflow APIs and security controls.

Error handling and logging: invalid records are routed to a restricted DLQ table; payload logging must be disabled or redacted for sensitive records.

Security: use private workers, VPC Service Controls where required, CMEK, least privilege and no service-account keys.

Testing: unit-test parsing, contract compatibility, event-time behavior, duplicate delivery, DLQ, performance, schema changes, negative access and replay.

Deployment: build an immutable Flex Template, promote through CI/CD, canary/shadow against synthetic or approved data and attach evidence.

Rollback: redeploy the prior template/prompt and reconcile replayed outputs.

Limitations: identifiers and schemas are illustrative. Validate current SDK versions, quotas, regions, service behavior and all industry/legal requirements.
