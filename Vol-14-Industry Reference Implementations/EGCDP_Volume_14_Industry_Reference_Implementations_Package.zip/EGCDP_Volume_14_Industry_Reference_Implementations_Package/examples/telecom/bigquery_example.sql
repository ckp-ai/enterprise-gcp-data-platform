CREATE OR REPLACE VIEW `telecom_semantic.service_impact` AS
SELECT service_id, window_start, MAX(severity) severity, COUNT(DISTINCT network_element_id) affected_elements,
       APPROX_COUNT_DISTINCT(subscriber_token) affected_subscribers
FROM `telecom_curated.service_events` GROUP BY service_id, window_start;
