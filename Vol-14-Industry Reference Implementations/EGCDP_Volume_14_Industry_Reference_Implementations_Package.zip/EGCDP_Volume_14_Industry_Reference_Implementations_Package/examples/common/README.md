# Common industry Terraform starter
Purpose: create a regional encrypted landing bucket and curated BigQuery dataset using inherited naming, labels and CMEK controls.

Prerequisites: approved project, region, KMS key, provider lock file and CI identity using Workload Identity Federation.

Testing: terraform fmt, validate, tflint, policy tests, plan review, non-production apply and negative IAM/perimeter tests.

Deployment: promote an immutable module version through the Volume 9/13 delivery path.

Rollback: revert module version only after state and data compatibility review; do not destroy data resources to roll back application behavior.

Production limitations: validate current provider arguments, regional availability, service-agent access, organization policies, VPC Service Controls and CMEK support.
