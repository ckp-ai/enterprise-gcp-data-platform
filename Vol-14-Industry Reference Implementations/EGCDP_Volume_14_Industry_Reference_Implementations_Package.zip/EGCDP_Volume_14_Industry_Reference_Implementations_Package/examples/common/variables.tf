variable "project_id" { type=string }
variable "region" { type=string }
variable "region_code" { type=string }
variable "bq_location" { type=string }
variable "environment" { type=string }
variable "org_code" { type=string }
variable "industry" { type=string }
variable "kms_key_name" { type=string }
variable "labels" { type=map(string); default={} }
