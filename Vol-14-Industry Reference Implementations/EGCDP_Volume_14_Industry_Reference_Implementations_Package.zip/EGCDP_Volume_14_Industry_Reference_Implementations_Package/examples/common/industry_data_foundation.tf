terraform { required_version = ">= 1.8"
  required_providers { google = { source = "hashicorp/google" version = "~> 7.0" } } }
provider "google" { project = var.project_id; region = var.region }
resource "google_storage_bucket" "landing" {
  name = "${var.org_code}-${var.industry}-${var.region_code}-landing-${var.environment}"
  location = var.region; uniform_bucket_level_access = true; public_access_prevention = "enforced"
  versioning { enabled = true }
  encryption { default_kms_key_name = var.kms_key_name }
  labels = merge(var.labels,{industry=var.industry,environment=var.environment})
}
resource "google_bigquery_dataset" "curated" {
  dataset_id = "${var.industry}_curated"; location = var.bq_location; delete_contents_on_destroy = false
  default_encryption_configuration { kms_key_name = var.kms_key_name }
  labels = merge(var.labels,{industry=var.industry,layer="curated"})
}
