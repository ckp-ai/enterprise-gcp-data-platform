CREATE OR REPLACE VIEW `retail_semantic.inventory_availability` AS
SELECT product_id, location_id, on_hand_qty-reserved_qty AS available_qty, promised_ts, source_freshness_ts
FROM `retail_curated.inventory_position`
WHERE quality_status='CERTIFIED';
