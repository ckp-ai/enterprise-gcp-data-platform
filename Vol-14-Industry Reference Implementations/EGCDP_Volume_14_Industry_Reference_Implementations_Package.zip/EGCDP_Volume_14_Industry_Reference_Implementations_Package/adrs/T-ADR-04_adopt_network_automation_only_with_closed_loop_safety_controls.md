# T-ADR-04: Adopt network automation only with closed-loop safety controls

Status: Approved reference decision
Date: 12 July 2026
Architecture domain: Industry reference implementation

Problem: Industry implementations must translate the shared data-platform blueprint into regulated, outcome-oriented architectures without fragmenting core controls.

Context: The enterprise operates globally across healthcare, banking, retail and telecommunications, with petabyte-scale data, regional obligations, critical services and AI adoption.

Decision drivers: business value, regulatory evidence, data trust, security, interoperability, resilience, operability, cost transparency and implementation velocity.

Constraints: source-system diversity, jurisdiction, product/region support, legacy integration, human-workflow dependency and incomplete Volume 9/13 implementation.

Assumptions: Volumes 01-08 and 10-12 provide the architecture baseline; Volume 9 and 13 remain implementation dependencies where not yet completed.

Alternatives considered: independent industry platforms; a single generic data model; unrestricted use-case customization; third-party-only industry suites.

Evaluation criteria: outcome fit, compliance, data semantics, security, SLO/RTO/RPO, portability, operations, cost and exit path.

Decision: Adopt network automation only with closed-loop safety controls.

Rationale: The decision preserves enterprise consistency while allowing the required industry semantics, controls and specialized services.

Benefits: reusable engineering, consistent audit evidence, faster onboarding and clearer accountability.

Tradeoffs: governance effort, regional duplication, specialized skills and continuous product/regulatory validation.

Positive consequences: industry teams can deliver through approved patterns and common platform interfaces.

Negative consequences: exceptions require formal review and some legacy designs must be refactored.

Risks: control gaps, service lifecycle changes, over-centralization, model misuse or cost growth.

Mitigations: policy-as-code, contracts, independent validation, resilience exercises, FinOps reviews, canaries and rollback.

Implementation implications: create industry modules, schemas, contracts, SLOs, runbooks and evidence templates.

Cost implications: regional duplication and industry services are measured through unit economics and showback.

Security implications: least privilege, VPC Service Controls, CMEK, Sensitive Data Protection and audit controls apply according to classification.

Operational implications: named on-call, service health, vendor escalation, DR and periodic review are mandatory.

Review triggers: regulation change, product lifecycle change, critical incident, new jurisdiction, AI risk increase or sustained SLO/cost breach.

Review date: 12 January 2027 or earlier trigger.
