# Purpose: Service perimeter for restricted data products.
# Prerequisites: Access Context Manager policy; org/folder/project IDs; supported APIs validated.
# Security: configure dry-run first, test ingress/egress, then enforce.
resource "google_access_context_manager_service_perimeter" "restricted_data" {
  parent = "accessPolicies/${var.access_policy_id}"
  name   = "accessPolicies/${var.access_policy_id}/servicePerimeters/sp_restricted_data_prod"
  title  = "sp_restricted_data_prod"
  status {
    resources = [for p in var.restricted_project_numbers : "projects/${p}"]
    restricted_services = [
      "bigquery.googleapis.com",
      "storage.googleapis.com",
      "aiplatform.googleapis.com",
      "dataplex.googleapis.com",
      "dataflow.googleapis.com"
    ]
    access_levels = [google_access_context_manager_access_level.corporate_trusted.name]
    ingress_policies {
      ingress_from { identities = var.approved_principals }
      ingress_to { operations { service_name = "bigquery.googleapis.com" method_selectors { method = "*" } } }
    }
    egress_policies {
      egress_from { identities = var.approved_service_accounts }
      egress_to { resources = var.approved_destination_projects }
    }
  }
  lifecycle { prevent_destroy = true }
}
