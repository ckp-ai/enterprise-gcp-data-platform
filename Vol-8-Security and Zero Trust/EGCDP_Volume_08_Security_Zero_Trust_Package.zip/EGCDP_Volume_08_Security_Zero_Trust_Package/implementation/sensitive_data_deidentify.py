"""Purpose: De-identify restricted values before non-production analytics use.
Prerequisites: google-cloud-dlp, Cloud KMS wrapped key, least-privilege service account.
Error handling: fails closed; no plaintext written to logs.
Testing: run with synthetic data and compare deterministic tokenization for joins.
Rollback: restore previous transform config from Git; never rehydrate tokens without approval.
Production limitations: validate infoTypes and tokenization alphabet for each domain.
"""
import os
from google.cloud import dlp_v2

def deidentify_text(project_id: str, text: str, wrapped_key: str, key_name: str) -> str:
    client = dlp_v2.DlpServiceClient()
    parent = f"projects/{project_id}/locations/global"
    item = {"value": text}
    crypto_key = {"kms_wrapped": {"wrapped_key": wrapped_key, "crypto_key_name": key_name}}
    transform = {"primitive_transformation": {"crypto_replace_ffx_fpe_config": {"crypto_key": crypto_key, "common_alphabet": "ALPHA_NUMERIC"}}}
    config = {
        "info_type_transformations": {
            "transformations": [
                {"info_types": [{"name": "EMAIL_ADDRESS"}, {"name": "PHONE_NUMBER"}, {"name": "CREDIT_CARD_NUMBER"}], "primitive_transformation": transform["primitive_transformation"]}
            ]
        }
    }
    response = client.deidentify_content(request={"parent": parent, "deidentify_config": config, "item": item})
    return response.item.value
