-- Purpose: Daily evidence view for unauthorized policy denials and privileged access.
CREATE OR REPLACE VIEW `egcdp_security_ops.security_evidence.vw_policy_denials` AS
SELECT
  timestamp,
  resource.type AS resource_type,
  protoPayload.authenticationInfo.principalEmail AS principal,
  protoPayload.serviceName AS service_name,
  protoPayload.methodName AS method_name,
  protoPayload.status.message AS denial_reason,
  JSON_VALUE(protoPayload.metadataJson, '$.resourceNames[0]') AS resource_name
FROM `egcdp-logging-prod.cloudaudit_googleapis_com_policy_denied_*`
WHERE _TABLE_SUFFIX >= FORMAT_DATE('%Y%m%d', DATE_SUB(CURRENT_DATE(), INTERVAL 30 DAY));
