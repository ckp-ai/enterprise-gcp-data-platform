# Purpose: Edge WAF and DDoS policy for data and analytics applications.
# Prerequisites: external Application Load Balancer, approved IP lists, test mode validation.
resource "google_compute_security_policy" "egcdp_edge_waf" {
  name = "ca-egcdp-edge-waf-prod"
  rule {
    priority = 1000
    action   = "deny(403)"
    match { expr { expression = "evaluatePreconfiguredWaf('sqli-stable')" } }
    description = "Block SQL injection patterns"
  }
  rule {
    priority = 1010
    action   = "deny(403)"
    match { expr { expression = "evaluatePreconfiguredWaf('xss-stable')" } }
    description = "Block XSS patterns"
  }
  rule {
    priority = 2147483647
    action   = "allow"
    match { versioned_expr = "SRC_IPS_V1" config { src_ip_ranges = ["*"] } }
    description = "Default allow after explicit security controls"
  }
}
