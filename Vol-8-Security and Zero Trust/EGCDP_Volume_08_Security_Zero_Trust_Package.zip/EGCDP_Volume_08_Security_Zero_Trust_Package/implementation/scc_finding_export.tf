# Purpose: Export Security Command Center findings to BigQuery and Pub/Sub for SIEM/SOAR.
# Prerequisites: SCC activated at organization level; destination datasets protected.
resource "google_scc_v2_organization_notification_config" "critical_findings" {
  organization     = var.org_id
  config_id        = "egcdp-critical-findings"
  location         = "global"
  pubsub_topic     = google_pubsub_topic.scc_findings.id
  streaming_config { filter = "severity="CRITICAL" OR severity="HIGH"" }
}
resource "google_logging_organization_sink" "security_logs" {
  name        = "egcdp-security-audit-sink"
  org_id      = var.org_id
  destination = "bigquery.googleapis.com/projects/${var.log_project}/datasets/security_audit"
  filter      = "protoPayload.@type="type.googleapis.com/google.cloud.audit.AuditLog""
  include_children = true
}
