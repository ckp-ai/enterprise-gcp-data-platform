# Purpose: Key rings and CMEK keys for restricted and regulated workloads.
# Prerequisites: selected region, key custodians, service agents, rotation policy approved.
resource "google_kms_key_ring" "restricted" {
  name     = "kr-egcdp-restricted-us-prod"
  location = var.primary_region
}
resource "google_kms_crypto_key" "bigquery" {
  name            = "ck-bigquery-restricted-prod"
  key_ring        = google_kms_key_ring.restricted.id
  rotation_period = "7776000s" # 90 days; validate workload/regulatory need
  lifecycle { prevent_destroy = true }
}
resource "google_kms_crypto_key_iam_binding" "bq_service_agent" {
  crypto_key_id = google_kms_crypto_key.bigquery.id
  role          = "roles/cloudkms.cryptoKeyEncrypterDecrypter"
  members       = var.bigquery_service_agents
}
