# ADR-0809: Enforce supply-chain controls with Artifact Analysis and Binary Authorization

Status: Approved baseline
Date: 12 July 2026
Architecture domain: Security and Zero Trust

Problem: The enterprise data platform needs repeatable controls that protect petabyte-scale data, AI workloads and analytics consumers across many regions and business domains.

Context: Volumes 1-7 establish a federated data-product platform with shared landing-zone, BigQuery, Cloud Storage, Pub/Sub, Dataflow, Knowledge Catalog, Looker and Vertex AI. Security controls must preserve agility while preventing unauthorized access, data exfiltration and compliance drift.

Decision drivers: regulatory compliance, least privilege, operational velocity, auditability, resilience, cost transparency and consistent platform engineering.

Constraints: product support varies by service and region; VPC Service Controls and CMEK compatibility must be validated per workload; exceptions require Security Architecture Review Board approval.

Alternatives considered: project-only isolation; network-only segmentation; third-party-only CASB/CSPM; manual access reviews; unmanaged service account keys.

Decision: Prevent untrusted artifacts from reaching production workloads.

Rationale: This decision aligns with the enterprise security baseline, reduces standing privilege, increases auditable evidence and applies defense-in-depth around identity, network, data and workload planes.

Benefits: clearer control ownership, stronger least privilege, better audit evidence, lower exfiltration risk and safer self-service.

Tradeoffs: additional design and test effort, possible onboarding friction, product compatibility validation, and requirement for operational runbooks.

Positive consequences: standardized controls, reusable Terraform modules, measurable evidence and easier compliance review.

Negative consequences: delivery teams must plan security integration earlier and cannot rely on late-stage exception handling.

Risks: misconfiguration, overly broad exceptions, incomplete monitoring, or service incompatibility.

Mitigations: dry-run mode, staged rollout, policy-as-code, peer review, automated tests, exception register and quarterly control validation.

Implementation implications: create golden modules, test in non-production, deploy centrally where possible, and attach acceptance tests to every production change.

Cost implications: may introduce additional product tier, logging, scanning, key management and operational costs; FinOps review required for scale.

Security implications: materially strengthens identity proof, data perimeter controls, key control and auditability.

Operational implications: requires on-call runbooks, emergency access workflow, security monitoring and evidence retention.

Review triggers: material product update, new region, new regulated workload, major incident, audit finding, M&A integration or annual architecture review.

Review date: 12 January 2027
