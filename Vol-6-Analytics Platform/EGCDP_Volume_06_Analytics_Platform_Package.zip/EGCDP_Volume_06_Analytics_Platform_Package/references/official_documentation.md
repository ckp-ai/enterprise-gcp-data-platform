# Official validation references

See Appendix C of the detailed guide. Validate all product behavior at implementation time using current Google Cloud documentation and the Terraform Google provider registry.
