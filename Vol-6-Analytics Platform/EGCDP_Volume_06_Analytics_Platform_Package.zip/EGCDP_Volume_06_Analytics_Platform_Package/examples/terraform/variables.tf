variable "project_id" {
  type = string
}

variable "region" {
  type = string
}

variable "bigquery_location" {
  type = string
}

variable "analytics_project_number" {
  type = string
}

variable "data_project_id" {
  type = string
}

variable "baseline_slots" {
  type = number
  validation {
    condition     = var.baseline_slots >= 0
    error_message = "baseline_slots must be non-negative"
  }
}

variable "max_slots" {
  type = number
  validation {
    condition     = var.max_slots >= var.baseline_slots
    error_message = "max_slots must be greater than or equal to baseline_slots"
  }
}

variable "target_concurrency" {
  type    = number
  default = 0
}

variable "bi_engine_bytes" {
  type = number
}
