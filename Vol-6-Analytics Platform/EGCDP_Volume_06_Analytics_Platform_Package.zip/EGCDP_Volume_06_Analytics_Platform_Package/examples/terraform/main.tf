terraform {
  required_version = ">= 1.6.0"

  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 6.0"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

resource "google_bigquery_reservation" "bi" {
  name              = "bqrs-analytics-prod-amer"
  location          = var.bigquery_location
  edition           = "ENTERPRISE"
  baseline_slots    = var.baseline_slots
  ignore_idle_slots = false
  concurrency       = var.target_concurrency

  autoscale {
    max_slots = var.max_slots
  }
}

resource "google_bigquery_reservation_assignment" "analytics_project" {
  assignee    = "projects/${var.analytics_project_number}"
  job_type    = "QUERY"
  reservation = google_bigquery_reservation.bi.id
}

resource "google_bigquery_bi_reservation" "accelerator" {
  location = var.bigquery_location
  size     = var.bi_engine_bytes

  preferred_tables {
    project_id = var.data_project_id
    dataset_id = "sales_semantic"
    table_id   = "order_performance_daily"
  }
}
