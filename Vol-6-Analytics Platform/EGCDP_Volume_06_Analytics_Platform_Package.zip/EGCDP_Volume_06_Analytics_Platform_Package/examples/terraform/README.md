# Terraform analytics capacity example
Purpose: provision a BigQuery reservation, assignment and BI Engine reservation using infrastructure as code.
Prerequisites: billing and edition approval, project numbers, service APIs, deployment identity and capacity model.
Security: use Workload Identity Federation, protected state and least-privilege deployment roles.
Testing: terraform fmt, validate, provider lock, static analysis, policy checks, plan review and nonproduction apply.
Deployment: promote immutable module versions through CI/CD.
Rollback: remove or reassign capacity only after workload impact review; restore the prior state/configuration.
Production limitations: resource arguments, edition support, quotas and locations must be validated against the current provider and Google Cloud documentation.
