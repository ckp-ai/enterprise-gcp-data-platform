-- Purpose: publish an analytics-ready semantic view with stable names.
CREATE OR REPLACE VIEW `acme-data-sales-prod-amer-01.sales_semantic.v_order_performance` AS
SELECT
  DATE(order_ts) AS order_date,
  region_code,
  channel_code,
  COUNT(DISTINCT order_id) AS order_count,
  SUM(net_revenue_amount) AS net_revenue_amount,
  SUM(margin_amount) AS margin_amount
FROM `acme-data-sales-prod-amer-01.sales_curated.order_fact`
WHERE is_current = TRUE
GROUP BY 1,2,3;

-- Acceptance test: no duplicate business grain.
ASSERT (SELECT COUNT(*) FROM (
  SELECT order_date, region_code, channel_code, COUNT(*) c
  FROM `acme-data-sales-prod-amer-01.sales_semantic.v_order_performance`
  GROUP BY 1,2,3 HAVING c > 1)) = 0
AS 'Semantic view contains duplicate business grain';
