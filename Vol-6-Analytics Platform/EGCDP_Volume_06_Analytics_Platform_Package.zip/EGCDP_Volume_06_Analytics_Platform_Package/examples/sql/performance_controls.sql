-- Purpose: representative performance and cost controls.
-- Replace region, project and thresholds with approved enterprise values.
SELECT
  user_email,
  COUNT(*) AS job_count,
  SUM(total_bytes_billed) AS total_bytes_billed,
  SUM(total_slot_ms) AS total_slot_ms
FROM `region-us`.INFORMATION_SCHEMA.JOBS_BY_PROJECT
WHERE creation_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
  AND job_type = 'QUERY'
GROUP BY user_email
ORDER BY total_bytes_billed DESC;

-- Use maximum_bytes_billed in client/job configuration for exploratory workloads.
-- Use partition filters, selective columns, materialized views and workload assignments.
