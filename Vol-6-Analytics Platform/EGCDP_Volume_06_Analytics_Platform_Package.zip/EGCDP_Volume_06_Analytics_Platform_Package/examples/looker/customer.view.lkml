view: customer {
  sql_table_name: `acme-data-cust-prod-amer-01.customer_semantic.customer_dim` ;;
  dimension: customer_id { primary_key: yes hidden: yes sql: ${TABLE}.customer_id ;; }
  dimension: customer_segment { sql: ${TABLE}.customer_segment ;; }
  dimension: country_code { sql: ${TABLE}.country_code ;; }
  dimension: customer_email { hidden: yes sql: ${TABLE}.customer_email ;; }
}
