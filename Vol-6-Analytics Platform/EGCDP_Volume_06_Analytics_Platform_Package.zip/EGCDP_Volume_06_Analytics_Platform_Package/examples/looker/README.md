# LookML example
Purpose: demonstrate a governed, product-aligned semantic model.

Prerequisites: approved BigQuery connection, group-to-role mapping, certified datasets, Git integration.
Security: BigQuery RLS, policy tags and masking remain authoritative. LookML hidden fields are a usability control, not a security boundary.
Testing: run LookML validator, SQL validator, data tests and content validator; reconcile certified measures to control totals.
Deployment: merge by pull request, promote through test, then production.
Rollback: revert the release commit or restore the previous production branch.
Limitations: connection names, field availability and supported syntax must be verified in the target Looker release.
