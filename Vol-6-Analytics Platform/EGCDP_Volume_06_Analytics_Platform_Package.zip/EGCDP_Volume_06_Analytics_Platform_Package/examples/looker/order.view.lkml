view: order {
  sql_table_name: `acme-data-sales-prod-amer-01.sales_semantic.order_fact` ;;
  dimension: order_id { primary_key: yes type: string sql: ${TABLE}.order_id ;; }
  dimension_group: order { type: time timeframes: [date, week, month, quarter, year] sql: ${TABLE}.order_ts ;; }
  dimension: customer_id { hidden: yes type: string sql: ${TABLE}.customer_id ;; }
  dimension: region_code { type: string sql: ${TABLE}.region_code ;; }
  measure: order_count { type: count_distinct sql: ${order_id} ;; value_format_name: decimal_0 }
  measure: gross_revenue { type: sum sql: ${TABLE}.gross_revenue_amount ;; value_format_name: usd }
  measure: net_revenue {
    type: sum sql: ${TABLE}.net_revenue_amount ;; value_format_name: usd
    description: "Certified net revenue after approved deductions."
    tags: ["certified-kpi", "owner:finance-performance"]
  }
  measure: restricted_margin {
    type: sum sql: ${TABLE}.margin_amount ;; value_format_name: usd
    required_access_grants: [finance_restricted]
  }
  set: detail { fields: [order_id, order_date, region_code, net_revenue] }
}
