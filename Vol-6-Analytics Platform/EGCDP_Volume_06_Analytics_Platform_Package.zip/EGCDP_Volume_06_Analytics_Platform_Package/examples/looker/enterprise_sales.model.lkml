connection: "bigquery_prod_amer"
include: "/views/*.view.lkml"

explore: order {
  label: "Certified Sales Analytics"
  description: "Certified order and revenue analysis."
  join: customer { sql_on: ${order.customer_id} = ${customer.customer_id} ;; relationship: many_to_one }
  always_filter: { filters: [order.order_date: "90 days"] }
}

access_grant: finance_restricted {
  user_attribute: data_entitlement
  allowed_values: ["finance_restricted"]
}
