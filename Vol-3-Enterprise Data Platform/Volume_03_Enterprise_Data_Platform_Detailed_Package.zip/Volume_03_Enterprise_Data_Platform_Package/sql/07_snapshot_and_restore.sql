-- Purpose: Snapshot before a high-risk transformation change.
CREATE SNAPSHOT TABLE `acme-customer-prd.customer_backup.customer_360_20260711`
CLONE `acme-customer-prd.customer_curated.customer_360`
OPTIONS (expiration_timestamp = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 30 DAY));

-- Example restore pattern: validate the snapshot, then replace through an approved change.
CREATE OR REPLACE TABLE `acme-customer-prd.customer_curated.customer_360_restored`
CLONE `acme-customer-prd.customer_backup.customer_360_20260711`;
