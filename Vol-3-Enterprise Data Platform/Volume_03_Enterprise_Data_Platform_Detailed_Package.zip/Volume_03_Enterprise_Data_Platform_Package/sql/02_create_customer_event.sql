-- Purpose: Standardized customer event table.
CREATE TABLE IF NOT EXISTS `acme-customer-prd.customer_silver.customer_event` (
  event_id STRING NOT NULL OPTIONS(description='Stable event identifier'),
  customer_id STRING NOT NULL OPTIONS(description='Enterprise customer identifier'),
  event_ts TIMESTAMP NOT NULL,
  event_date DATE NOT NULL,
  event_type STRING NOT NULL,
  region_code STRING,
  payload JSON,
  source_system STRING NOT NULL,
  schema_version STRING NOT NULL,
  ingestion_ts TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
PARTITION BY event_date
CLUSTER BY customer_id, event_type, region_code
OPTIONS (
  description = 'One row per standardized customer event',
  require_partition_filter = TRUE,
  labels = [('domain','customer'),('layer','silver'),('data_product','customer_events')]
);
