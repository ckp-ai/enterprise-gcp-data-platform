-- Purpose: Restrict EMEA consumers to EMEA customer records.
CREATE OR REPLACE ROW ACCESS POLICY region_entitlement_emea
ON `acme-customer-prd.customer_curated.customer_360`
GRANT TO ('group:customer-emea-readers@example.com')
FILTER USING (region_code = 'EMEA');
