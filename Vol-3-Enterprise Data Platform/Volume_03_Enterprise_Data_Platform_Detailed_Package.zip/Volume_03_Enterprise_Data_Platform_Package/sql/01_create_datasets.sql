-- Purpose: Create domain-aligned datasets for the reference customer domain.
-- Replace project IDs and location to match residency and environment standards.
CREATE SCHEMA IF NOT EXISTS `acme-customer-prd.customer_bronze`
OPTIONS (
  location = 'us-central1',
  description = 'Source-aligned customer records',
  labels = [('domain','customer'),('environment','prd'),('layer','bronze')]
);

CREATE SCHEMA IF NOT EXISTS `acme-customer-prd.customer_silver`
OPTIONS (
  location = 'us-central1',
  description = 'Standardized customer domain entities',
  labels = [('domain','customer'),('environment','prd'),('layer','silver')]
);

CREATE SCHEMA IF NOT EXISTS `acme-customer-prd.customer_curated`
OPTIONS (
  location = 'us-central1',
  description = 'Certified customer data products',
  labels = [('domain','customer'),('environment','prd'),('layer','curated')]
);
