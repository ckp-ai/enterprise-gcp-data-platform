-- Purpose: Build a curated Customer 360 product using deterministic sources.
CREATE OR REPLACE TABLE `acme-customer-prd.customer_curated.customer_360`
PARTITION BY DATE(last_activity_ts)
CLUSTER BY region_code, customer_segment AS
SELECT
  c.customer_id,
  ANY_VALUE(c.customer_name HAVING MAX c.effective_ts) AS customer_name,
  ANY_VALUE(c.region_code HAVING MAX c.effective_ts) AS region_code,
  ANY_VALUE(c.customer_segment HAVING MAX c.effective_ts) AS customer_segment,
  MAX(e.event_ts) AS last_activity_ts,
  COUNTIF(e.event_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 90 DAY)) AS events_90d,
  CURRENT_TIMESTAMP() AS product_refresh_ts
FROM `acme-customer-prd.customer_silver.customer` c
LEFT JOIN `acme-customer-prd.customer_silver.customer_event` e
  USING (customer_id)
GROUP BY c.customer_id;
