-- Purpose: Representative quality checks used by the product gate.
SELECT 'customer_id_not_null' AS rule_name,
       COUNTIF(customer_id IS NULL) AS failed_rows
FROM `acme-customer-prd.customer_curated.customer_360`
UNION ALL
SELECT 'region_code_valid',
       COUNTIF(region_code NOT IN ('AMER','EMEA','APAC'))
FROM `acme-customer-prd.customer_curated.customer_360`
UNION ALL
SELECT 'customer_id_unique',
       COUNT(*) - COUNT(DISTINCT customer_id)
FROM `acme-customer-prd.customer_curated.customer_360`;
