-- Purpose: Stable consumer interface without base-table access.
CREATE OR REPLACE VIEW `acme-customer-prd.customer_access.customer_summary_v1` AS
SELECT
  customer_id,
  region_code,
  customer_segment,
  events_90d,
  last_activity_ts
FROM `acme-customer-prd.customer_curated.customer_360`;
