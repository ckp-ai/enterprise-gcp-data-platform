# VOLUME 03
# Enterprise Data Platform

## Enterprise Google Cloud Data Platform Blueprint Series

**Fortune 100 Reference Architecture and Implementation Baseline**

**Architecture Baseline:** 1.0  
**Publication date:** 11 July 2026  
**Classification:** Enterprise Reference Architecture  
**Audience:** Chief Data Officer, CIO, CTO, Enterprise Architecture Review Board, Data Governance Council, Security Architecture Review Board, Cloud Center of Excellence, platform engineering and domain data teams


[PAGEBREAK]


# Document Control

This volume defines the enterprise data platform that runs on the Google Cloud landing zone established by Volume 02. It is a reference architecture, not a substitute for workload discovery, regulatory assessment or service-specific validation. The design assumes a global Fortune 100 enterprise and establishes mandatory platform patterns, adaptable patterns, architecture decisions, implementation standards and acceptance evidence.

| Field | Value |
| --- | --- |
| Document | Volume 03 - Enterprise Data Platform |
| Status | Architecture baseline for adaptation and implementation |
| Version | 1.0 |
| Date | 11 July 2026 |
| Owner | Enterprise Data Platform Architecture |
| Approvers | CDO, Enterprise Architecture, Security, Privacy, Platform Engineering, FinOps |
| Review cycle | Quarterly and on material Google Cloud product change |
| Related volumes | Volume 01 Executive Architecture Guide; Volume 02 Google Cloud Landing Zone; Volume 04 Data Engineering; Volume 05 Data Mesh; Volume 07 Security Blueprint; Volume 10 Operations SRE |
| Primary standards | Google Cloud Architecture Framework, Zero Trust, data mesh, lakehouse, SRE, FinOps, privacy by design |

## Current Product Terminology

Google Cloud product naming evolves. This volume uses the current product names available at publication and preserves former names in parentheses where they remain common in enterprise programs. **Knowledge Catalog** is the current name for the governance capability formerly called Dataplex Universal Catalog. **BigQuery sharing** is the current name for the capability formerly called Analytics Hub. **Apache Iceberg managed tables** is the current name for the BigQuery-managed Iceberg table capability formerly described as BigLake tables for Apache Iceberg in BigQuery. Teams must validate preview status, regional availability, quotas and feature compatibility during implementation.

## How to Use This Volume

The volume is organized from capability and source architecture through ingestion, storage, governance, sharing, security, operations and production deployment. Each design statement is classified as one of four types:

| Classification | Meaning |
| --- | --- |
| Mandatory baseline | Required for all production domains unless an approved exception exists. |
| Recommended pattern | The default for most workloads; another pattern requires documented engineering justification. |
| Conditional pattern | Use only when workload characteristics meet the stated selection criteria. |
| Future capability | Included in the target architecture but not required for the first platform release. |

## Table of Contents

1. Data-platform context, objectives and success measures
2. Enterprise capability model
3. Source-system architecture and data-source classification
4. Ingestion and transfer architecture
5. Data-storage and layer architecture
6. Core data services and service selection
7. Open formats, schemas and physical design standards
8. Data lifecycle, retention, legal hold and privacy deletion
9. Metadata, governance, lineage and quality
10. Data contracts, ownership and product certification
11. Data products, marketplace and enterprise access
12. Fine-grained security and encryption
13. Platform SLOs, monitoring and cost model
14. Production deployment model
15. Architecture Decision Records
16. Appendices: mappings, standards, sample definitions and validation checklists


[PAGEBREAK]


# Executive Summary

The enterprise data platform provides a governed path from hundreds of operational, SaaS, event, file, mainframe and cross-cloud sources to trusted data products used by analytics, operational applications and AI. The reference design supports 10-50 petabytes of historical data, 50-250 terabytes of new data per day, billions of events per day and globally distributed consumers without creating a single monolithic project or a central delivery bottleneck.

The target architecture combines Cloud Storage for immutable and open-format data, BigQuery for governed analytical products, BigLake and Apache Iceberg where open-engine interoperability is a real requirement, Pub/Sub and Dataflow for event processing, Datastream for supported database change data capture, Knowledge Catalog for enterprise metadata and governance, and BigQuery sharing for controlled publication. Bigtable, Spanner and AlloyDB are not alternate warehouses; they are conditional operational data stores selected for specific low-latency, globally consistent or PostgreSQL-compatible application patterns.

The operating model is federated. A central platform team owns reusable ingestion frameworks, shared governance, security controls, observability, cost attribution and paved-road automation. Domain teams own data products, contracts, quality, semantic meaning and consumer commitments. The architecture separates control planes from data planes and separates business ownership from infrastructure administration.

The design deliberately avoids treating every workload as streaming, every object as an Iceberg table or every dataset as a universal enterprise product. Latency, update pattern, interoperability, privacy, recovery and unit economics drive the decision. Batch is the default when it satisfies business latency. Streaming is reserved for time-sensitive decisions or event-driven integration. BigQuery native tables are the default analytical serving format. Apache Iceberg is selected when multiple engines must read and write a common table or customer-controlled object storage is a requirement.

## Reference Enterprise Assumptions

| Area | Reference assumption | Architecture implication |
| --- | --- | --- |
| Scale | 25 PB current estate; 120 TB daily ingestion; 5 billion events per day | Storage lifecycle and compute isolation are mandatory. |
| Sources | 250 enterprise sources and more than 2,000 feeds | Source onboarding must be metadata-driven and automated. |
| Consumers | 4,000 analysts, 600 data engineers/scientists and 300 application integrations | Access and workload isolation cannot rely on manual grants. |
| Geography | AMER, EMEA and APAC data-residency boundaries | Regional data planes with global governance metadata. |
| Availability | Tiered RTO/RPO and 99.9%-99.99% service objectives | Replay, backup, regional recovery and IaC reconstruction are required. |
| Security | Public, Internal, Confidential, Restricted and Regulated data | Project, perimeter, table, row and column controls are layered. |
| Operating model | Central platform plus federated domain product teams | Ownership and support are explicit for every product. |
| Delivery | Terraform and CI/CD are mandatory for platform and schema changes | Console-only configuration is noncompliant for production. |

## Executive Decisions

| Decision | Recommended position | Executive owner |
| --- | --- | --- |
| Primary analytical platform | BigQuery native tables for the majority of curated analytical data | CDO and CTO |
| Open lakehouse | Use Iceberg selectively for multi-engine interoperability, not as a universal default | Chief Data Architect |
| Ownership | Domain-owned data products on a centrally operated platform | CDO and business data owners |
| Regional model | Regional data planes aligned to residency, with centrally governed metadata and standards | CIO, Privacy and Security |
| Real-time scope | Streaming only where decision latency justifies complexity and cost | Business capability owners |
| Access model | Group and attribute-based access through product interfaces, not direct ad hoc table grants | Security and Governance |
| Cost model | Showback from day one and chargeback for production domains after stabilization | CFO and FinOps |


[PAGEBREAK]


# 1. Data-Platform Objectives

The platform is an enterprise product that enables business domains to create and operate trustworthy data products. It is not a collection of independent Google Cloud services and it is not a centralized team that builds every pipeline. The objectives below are measurable architectural outcomes.

| ID | Objective | Architecture intent | Success measure |
| --- | --- | --- | --- |
| OBJ-01 | Trusted data products | Publish certified products with named owners, contracts, lineage, quality and SLOs. | 90% of priority analytical consumption uses certified products within 24 months. |
| OBJ-02 | Elastic scale | Support petabyte storage and burst processing without fixed cluster planning for every workload. | Ingestion and analytical workloads pass 2x projected peak tests. |
| OBJ-03 | Latency choice | Provide batch, micro-batch, CDC and streaming patterns selected by business latency. | Every feed has an approved latency class and cost justification. |
| OBJ-04 | Security by design | Protect data according to sensitivity, residency and purpose. | 100% of production assets classified; no unresolved critical access findings. |
| OBJ-05 | Interoperability | Use open files and Iceberg where engine portability is required. | Approved multi-engine workloads avoid duplicate authoritative copies. |
| OBJ-06 | Data quality | Detect quality issues before consumers receive incorrect data. | Tier 0 and 1 products meet defined quality thresholds and block publication on critical failure. |
| OBJ-07 | Discoverability | Make products, definitions and owners searchable. | Priority assets are discoverable in Knowledge Catalog with complete mandatory metadata. |
| OBJ-08 | Operational reliability | Operate pipelines and products using SLOs, runbooks and error budgets. | Tier 0/1 services publish SLOs and pass operational readiness review. |
| OBJ-09 | Cost accountability | Allocate platform cost to domains and products. | At least 95% of data-platform spend is attributable by domain, product and environment. |
| OBJ-10 | AI readiness | Expose governed, high-quality and semantically rich data to approved AI platforms. | AI use cases consume certified product interfaces and record lineage and purpose. |

## 1.1 Design Outcomes

A successful implementation creates a stable set of paved roads. A source team can onboard a feed through a standard intake process; a domain team can build a product using reusable infrastructure and pipeline templates; a consumer can discover and request access without learning internal project topology; and operations can determine freshness, correctness, lineage, cost and owner from one control surface. Custom engineering remains possible, but it is an exception with explicit ownership and support consequences.

The platform must also reduce the number of authoritative copies. Raw source evidence is retained once per legal and operational requirement. Transformations create managed layers only when they add contract, quality, performance or access value. Export copies are time-bound and monitored. Multi-engine access uses BigLake and Iceberg when it avoids duplication without sacrificing governance.

## 1.2 Scope Boundaries

| In scope | Out of scope or separate volume |
| --- | --- |
| Enterprise source onboarding, ingestion, storage, governance, access, sharing and operational standards | Detailed Beam, Spark, Airflow and Dataform coding standards - Volume 04 |
| Logical and physical data layers | Enterprise semantic modeling and dashboard engineering - analytics volume |
| Data-product lifecycle and certification | Detailed domain decomposition and mesh operating model - Volume 05 |
| Fine-grained data access and data encryption | Complete landing-zone and network implementation - Volume 02 |
| Platform SLOs and monitoring controls | Full SRE, incident and capacity processes - Volume 10 |
| Sample dataset, table and access definitions | End-to-end industry implementations - Volume 12 |


[PAGEBREAK]


# 2. Enterprise Data-Platform Capabilities

Capabilities are stable business and technology outcomes. Services are replaceable implementation choices. This distinction prevents the architecture from becoming a product inventory and provides a traceable basis for service selection.

| ID | Capability | Definition | Primary implementation |
| --- | --- | --- | --- |
| CAP-01 | Source onboarding | Discover owner, contract, sensitivity, latency, volume and recovery requirements before connection. | Intake workflow, source registry, approvals |
| CAP-02 | Managed transfer | Move large files and historical data with integrity and restartability. | Storage Transfer Service, transfer appliances where justified |
| CAP-03 | Batch ingestion | Load scheduled extracts with manifests, reconciliation and deterministic reruns. | Cloud Storage, Dataflow, BigQuery load jobs |
| CAP-04 | Event ingestion | Decouple producers and consumers with versioned events and replay. | Pub/Sub, schemas, archive subscription |
| CAP-05 | CDC | Capture committed database changes while preserving order and recoverability. | Datastream and merge framework |
| CAP-06 | API integration | Ingest from rate-limited and authenticated services. | Cloud Run, Workflows, Apigee, Secret Manager |
| CAP-07 | Open lake storage | Persist immutable and interoperable files. | Cloud Storage, Parquet, Avro, Iceberg |
| CAP-08 | Analytical warehouse | Provide governed SQL analytics at enterprise scale. | BigQuery |
| CAP-09 | Operational serving | Serve low-latency key-value, global relational and PostgreSQL-compatible use cases. | Bigtable, Spanner, AlloyDB |
| CAP-10 | Metadata and discovery | Inventory assets and connect technical context to business meaning. | Knowledge Catalog |
| CAP-11 | Lineage and impact | Trace origin, transformation, destination and consumer impact. | Knowledge Catalog lineage plus custom events |
| CAP-12 | Data quality | Profile, validate, score, quarantine and remediate. | Knowledge Catalog automatic data quality and pipeline gates |
| CAP-13 | Contract management | Version schema, semantics, SLO and compatibility expectations. | Contract repository, schema registry, CI validation |
| CAP-14 | Fine-grained access | Restrict datasets, rows, columns and visible values. | IAM, authorized views, row policies, policy tags, masking |
| CAP-15 | Data sharing | Publish governed datasets and streams across organizational boundaries. | BigQuery sharing and controlled APIs |
| CAP-16 | Lifecycle management | Retain, archive, hold, delete and evidence disposition. | Cloud Storage retention/holds, BigQuery lifecycle, workflow |
| CAP-17 | Observability | Measure freshness, quality, lineage completeness, pipeline health and cost. | Cloud Monitoring, Logging, product telemetry |
| CAP-18 | FinOps | Allocate, forecast and optimize by domain and product. | Billing export, labels, reservations and unit metrics |

## 2.1 Capability Maturity Model

| Level | Description | Evidence |
| --- | --- | --- |
| 1 - Ad hoc | Teams build independent pipelines and grant direct access. | Manual scripts, undocumented datasets and reactive support. |
| 2 - Standardized | Common templates and layer definitions exist. | Reusable modules, naming standards and basic monitoring. |
| 3 - Governed | Ownership, contracts, catalog, access workflow and quality gates are enforced. | Certified products, automated policies and audit evidence. |
| 4 - Productized | Domains operate data products against SLO, cost and consumer commitments. | Product scorecards, showback and versioned interfaces. |
| 5 - Optimizing | Telemetry drives automated tuning, deprecation and policy improvement. | Predictive capacity, anomaly detection and continuous control validation. |

## 2.2 Central Platform and Domain Responsibilities

| Capability | Central platform | Domain team |
| --- | --- | --- |
| Ingestion frameworks | Build and operate reusable templates, connectors, DLQ and monitoring patterns. | Configure source-specific contract and own source reconciliation. |
| Storage | Provide modules, lifecycle defaults and security controls. | Select layer and retention within policy; own product datasets. |
| Governance | Operate catalog, glossary standards, classification and certification workflow. | Supply business definitions, owner, steward and product metadata. |
| Quality | Provide rule framework, execution platform and scorecards. | Define thresholds, remediate failures and accept exceptions. |
| Access | Provide group, policy-tag, row-policy and request workflow patterns. | Approve purpose-based consumer access. |
| Operations | Provide telemetry, platform SLOs and escalation paths. | Own product SLO, runbook and business impact. |
| FinOps | Provide allocation model, budgets and recommendations. | Own product budget and act on optimization findings. |

![End-to-end enterprise data-platform reference architecture](/mnt/data/Volume_03_Enterprise_Data_Platform_Package/diagrams/01_end_to_end_platform.png){width=95%}

*Figure: End-to-end enterprise data-platform reference architecture*


[PAGEBREAK]


# 3. Source-System Architecture and Data-Source Classification

Source onboarding begins with architecture and risk discovery, not connectivity. The source registry records the authoritative owner, interface, legal basis, sensitivity, expected volume, change pattern, latency, retention, replay method, maintenance windows and recovery requirements. A source is not production-ready until its control and reconciliation model is approved.

## 3.1 Source-System Architecture

Sources are grouped by control characteristics rather than vendor alone. Systems of record require reconciliation and clear extraction boundaries. Event producers require schema ownership and replay. SaaS sources require awareness of provider limits, API changes and historical extract behavior. Mainframes require record-format and encoding expertise. Cross-cloud sources add egress, identity and residency concerns. Partner sources add contractual and nonrepudiation controls.

The platform never assumes that a successful API call or transferred file proves completeness. Each interface has a control total, sequence, watermark, source snapshot identifier or event offset that supports independent reconciliation. Where the source cannot provide such evidence, the data owner accepts a documented residual risk and defines compensating checks.

| Source class | Examples | Default integration | Primary risks |
| --- | --- | --- | --- |
| Operational relational | Oracle, SQL Server, PostgreSQL, MySQL, DB2 | CDC plus periodic reconciliation | Transaction order, schema changes, source load |
| Mainframe | DB2 z/OS, VSAM, IMS, flat files | Batch unload or approved log-based capture | EBCDIC, packed decimal, copybooks, batch windows |
| ERP and enterprise apps | SAP, Salesforce, Workday, ServiceNow | Managed extract, API or supported connector | Vendor limits, semantic complexity, delta behavior |
| Event platforms | Kafka, application events, IoT brokers | Pub/Sub or Dataflow connector | Ordering, duplicate delivery, schema compatibility |
| Files and objects | SFTP, NFS, object stores, managed file transfer | Manifest-based object ingestion | Partial files, duplicate delivery, malware |
| APIs | REST, SOAP, GraphQL | Cloud Run/Workflows with managed secrets | Rate limits, pagination, replay and provider changes |
| Cross-cloud | Amazon S3, Azure Data Lake, cloud warehouses | Managed transfer, direct query or replication | Egress, identity, regionality and consistency |
| Partners | B2B exchange, regulators, suppliers | Managed file/API, signed manifests and isolated landing | Contract, provenance, nonrepudiation and data minimization |
| Unstructured | Documents, images, audio, logs | Object storage and metadata extraction | Sensitive content, file types, AI processing rights |

## 3.2 Data-Source Classification Model

| Dimension | Values | Design use |
| --- | --- | --- |
| Authority | System of record / derived / external / reference | Determines reconciliation and conflict resolution. |
| Change pattern | Append / update / delete / snapshot / event | Determines CDC, merge and history design. |
| Latency | Real time / near real time / hourly / daily / periodic | Selects streaming, micro-batch or batch. |
| Volume | Small / medium / large / extreme | Drives transfer, partition and quota design. |
| Sensitivity | Public / Internal / Confidential / Restricted / Regulated | Drives projects, perimeters, masking and approval. |
| Residency | Global / AMER / EMEA / APAC / country-restricted | Determines region, key and sharing boundaries. |
| Schema stability | Stable / additive / frequent breaking changes | Determines contract strictness and compatibility mode. |
| Replayability | Source replay / event archive / snapshot only / none | Determines recovery and evidence requirements. |
| Availability | Tier 0 / 1 / 2 / 3 | Determines SLO and operational response. |
| Ownership | Named business and technical owners | Determines approvals, stewardship and support. |

## 3.3 Source Intake Gate

1. Identify business owner, technical owner, steward and consumer use case.
2. Classify sensitivity, residency, retention, legal basis and data-subject obligations.
3. Record source data model, interface, supported extraction windows and provider limits.
4. Measure current and peak volume, row size, event rate and change rate.
5. Select latency class and justify why slower processing is insufficient.
6. Define schema contract, compatibility rules and deprecation notice.
7. Define source and target control totals, watermarks and reconciliation tolerance.
8. Define replay, backfill, deletion and historical reload behavior.
9. Complete threat assessment, secrets, network path and service-perimeter review.
10. Approve SLO, runbook, cost owner and production support model.


[PAGEBREAK]


# 4. Ingestion and Data-Transfer Architecture

The ingestion plane isolates source-specific variability from domain transformations. It validates transport integrity, contract compatibility, security classification and replay evidence before data enters governed layers. Ingestion is not the place to embed complex business logic. Source-aligned normalization is allowed; cross-domain business rules belong in the standardization and product layers.

## 4.1 Batch-Ingestion Architecture

Use batch when the business decision can wait for a scheduled boundary and the source can provide a complete extract or stable incremental watermark. Batch is the default because it is simpler to reconcile, replay and operate than continuous processing. A scheduler starts an extract or waits for a manifest. Objects arrive in a write-only landing prefix. Validation verifies naming, checksum, encryption, source window, schema and control totals. Accepted objects are copied or promoted to immutable raw storage. Processing writes source-aligned bronze data and records reconciliation metrics before publication.

| Design aspect | Enterprise standard |
| --- | --- |
| Primary services | Storage Transfer Service, Cloud Storage, BigQuery load jobs, Dataflow batch, Workflows or Cloud Composer, Cloud Monitoring |
| Idempotency and replay | Use source batch ID plus object checksum. Reprocessing a batch writes to a staging target and atomically replaces or merges the intended partition. |
| Failure handling | Invalid files move to quarantine with error metadata; partial batches remain unpublished; retries preserve batch ID; operational alerts include source window and failing object. |
| Security | Dedicated transfer identity, bucket-level uniform access, private connectivity where required, malware inspection for external files, CMEK for restricted classes. |
| Cost optimization | Prefer load jobs and compressed columnar formats; avoid many small files; schedule heavy transformations outside contention windows. |
| Common pitfalls | Using arrival time as business time; publishing before reconciliation; overwriting raw evidence; accepting silent schema drift. |

### Implementation sequence

1. Register the source and approve owner, classification, latency and recovery requirements.
2. Provision connectivity, service identity, secret, landing target, schema contract and monitoring through reusable infrastructure modules.
3. Execute a representative volume and failure test, including duplicate, late, malformed and replay scenarios.
4. Reconcile source and target independently and retain evidence with the ingestion ledger.
5. Promote the feed only after security, quality, operational and cost acceptance criteria pass.

### Acceptance evidence

| Evidence | Minimum acceptance |
| --- | --- |
| Contract | Versioned schema, semantics, owner and compatibility rule approved. |
| Integrity | Checksum, sequence, watermark or control total proves transfer completeness. |
| Recovery | Demonstrated replay or backfill without duplicate business records. |
| Observability | Freshness, failure, backlog and volume telemetry visible to owner. |
| Security | Identity, network, encryption and data-classification controls tested. |
| Cost | Baseline unit cost and expected monthly range recorded. |

![Batch-ingestion reference architecture](/mnt/data/Volume_03_Enterprise_Data_Platform_Package/diagrams/02_batch_ingestion.png){width=95%}

*Figure: Batch-ingestion reference architecture*

## 4.2 Streaming-Ingestion Architecture

Use streaming when a business action, operational alert or customer experience requires event availability in seconds or a few minutes. Streaming is not justified only because the source emits events. Producers publish versioned events to Pub/Sub or an approved connector. A Dataflow pipeline validates schema, event time and identity, deduplicates where required, enriches from bounded reference state and writes to BigQuery through the Storage Write API or to Bigtable for low-latency serving. A separate archive path preserves replay evidence.

| Design aspect | Enterprise standard |
| --- | --- |
| Primary services | Pub/Sub, Pub/Sub schemas, Dataflow, BigQuery Storage Write API, Bigtable, Cloud Storage replay archive |
| Idempotency and replay | Use a stable event ID and producer sequence. Exactly-once write semantics can be used with application-created BigQuery streams and offsets; business idempotency remains necessary across retries and downstream effects. |
| Failure handling | Malformed events go to a dead-letter topic; backlog and watermark alerts protect freshness; poison messages have bounded retry; replay uses retained messages or archive objects. |
| Security | Per-producer service identities, topic-level publish permissions, schema validation, service perimeter assessment, encryption and restricted subscriber identities. |
| Cost optimization | Control message size and retention; use at-least-once when duplicates can be cheaply resolved; autoscale Dataflow within tested worker limits. |
| Common pitfalls | Assuming ordering across all events; no replay store; embedding consumer-specific logic in shared topics; unbounded state. |

### Implementation sequence

1. Register the source and approve owner, classification, latency and recovery requirements.
2. Provision connectivity, service identity, secret, landing target, schema contract and monitoring through reusable infrastructure modules.
3. Execute a representative volume and failure test, including duplicate, late, malformed and replay scenarios.
4. Reconcile source and target independently and retain evidence with the ingestion ledger.
5. Promote the feed only after security, quality, operational and cost acceptance criteria pass.

### Acceptance evidence

| Evidence | Minimum acceptance |
| --- | --- |
| Contract | Versioned schema, semantics, owner and compatibility rule approved. |
| Integrity | Checksum, sequence, watermark or control total proves transfer completeness. |
| Recovery | Demonstrated replay or backfill without duplicate business records. |
| Observability | Freshness, failure, backlog and volume telemetry visible to owner. |
| Security | Identity, network, encryption and data-classification controls tested. |
| Cost | Baseline unit cost and expected monthly range recorded. |

![Streaming-ingestion reference architecture](/mnt/data/Volume_03_Enterprise_Data_Platform_Package/diagrams/04_streaming_ingestion.png){width=95%}

*Figure: Streaming-ingestion reference architecture*

## 4.3 CDC Architecture

Use change data capture for supported operational databases when downstream consumers need committed changes more frequently than scheduled extracts and the source can support log-based capture. Datastream reads database transaction logs and writes changes to a supported destination. A landing or staging representation preserves operation type, source timestamp and sequence. A merge pipeline applies inserts, updates and deletes into bronze and silver tables while maintaining history and reconciliation.

| Design aspect | Enterprise standard |
| --- | --- |
| Primary services | Datastream, Cloud Storage or BigQuery destination, Dataflow or BigQuery SQL merge, Secret Manager, Cloud Monitoring |
| Idempotency and replay | Persist source log position and primary key. Merge based on operation sequence and source commit time. Replays must not create duplicate current records or corrupt history. |
| Failure handling | Monitor stream state and source lag. Schema changes are evaluated against contract compatibility. Gaps trigger controlled backfill from a consistent source snapshot. |
| Security | Private connectivity where supported, minimal database account, secret rotation, source allowlist, per-stream service account and CMEK where required. |
| Cost optimization | Filter unused schemas and tables; avoid capturing columns with no consumer; tune merge cadence to balance freshness and query cost. |
| Common pitfalls | No initial snapshot reconciliation; missing primary keys; relying on arrival order; applying destructive schema changes automatically. |

### Implementation sequence

1. Register the source and approve owner, classification, latency and recovery requirements.
2. Provision connectivity, service identity, secret, landing target, schema contract and monitoring through reusable infrastructure modules.
3. Execute a representative volume and failure test, including duplicate, late, malformed and replay scenarios.
4. Reconcile source and target independently and retain evidence with the ingestion ledger.
5. Promote the feed only after security, quality, operational and cost acceptance criteria pass.

### Acceptance evidence

| Evidence | Minimum acceptance |
| --- | --- |
| Contract | Versioned schema, semantics, owner and compatibility rule approved. |
| Integrity | Checksum, sequence, watermark or control total proves transfer completeness. |
| Recovery | Demonstrated replay or backfill without duplicate business records. |
| Observability | Freshness, failure, backlog and volume telemetry visible to owner. |
| Security | Identity, network, encryption and data-classification controls tested. |
| Cost | Baseline unit cost and expected monthly range recorded. |

![Change-data-capture reference architecture](/mnt/data/Volume_03_Enterprise_Data_Platform_Package/diagrams/03_cdc_ingestion.png){width=95%}

*Figure: Change-data-capture reference architecture*

## 4.4 API-Ingestion Architecture

Use API ingestion where the provider exposes business objects or events only through REST, SOAP or GraphQL and no managed connector meets control requirements. A Cloud Run service or Workflows definition retrieves credentials from Secret Manager, calls the API using bounded concurrency, handles pagination and rate limits, persists raw responses and control metadata, and publishes a completion event. Parsing and business normalization occur downstream.

| Design aspect | Enterprise standard |
| --- | --- |
| Primary services | Cloud Run, Workflows, Apigee where enterprise API policy is needed, Secret Manager, Cloud Scheduler, Pub/Sub, Cloud Storage |
| Idempotency and replay | Use provider object ID, update timestamp and request window. Store continuation tokens and response hashes. Reruns use the same extraction window and merge semantics. |
| Failure handling | Apply exponential backoff with jitter, provider-specific retryable codes, circuit breaking and a persisted checkpoint. Do not retry non-idempotent calls without a provider idempotency key. |
| Security | Outbound egress control, short-lived identity, managed secrets, certificate validation, payload minimization and redaction of secrets from logs. |
| Cost optimization | Prefer incremental endpoints, compression and bulk APIs. Bound parallelism to prevent rate-limit retries from multiplying cost. |
| Common pitfalls | Logging credentials or full sensitive payloads; losing pagination tokens; assuming API response order; no provider-version monitoring. |

### Implementation sequence

1. Register the source and approve owner, classification, latency and recovery requirements.
2. Provision connectivity, service identity, secret, landing target, schema contract and monitoring through reusable infrastructure modules.
3. Execute a representative volume and failure test, including duplicate, late, malformed and replay scenarios.
4. Reconcile source and target independently and retain evidence with the ingestion ledger.
5. Promote the feed only after security, quality, operational and cost acceptance criteria pass.

### Acceptance evidence

| Evidence | Minimum acceptance |
| --- | --- |
| Contract | Versioned schema, semantics, owner and compatibility rule approved. |
| Integrity | Checksum, sequence, watermark or control total proves transfer completeness. |
| Recovery | Demonstrated replay or backfill without duplicate business records. |
| Observability | Freshness, failure, backlog and volume telemetry visible to owner. |
| Security | Identity, network, encryption and data-classification controls tested. |
| Cost | Baseline unit cost and expected monthly range recorded. |

## 4.5 SaaS-Ingestion Architecture

Use provider-supported transfer services or vetted connectors when they preserve source semantics, incremental extraction and operational evidence. Custom code is the fallback, not the first choice. A connector or BigQuery Data Transfer Service schedule lands provider data in a restricted dataset. A source adapter validates expected tables, extract timestamps and row counts, then copies or transforms into enterprise bronze with the source contract attached.

| Design aspect | Enterprise standard |
| --- | --- |
| Primary services | BigQuery Data Transfer Service, supported third-party connector, Cloud Run custom adapter, Secret Manager, BigQuery |
| Idempotency and replay | Provider extract ID and target partition are the replay keys. Maintain an extraction ledger so late and corrected provider records can be reapplied. |
| Failure handling | Alert on schedule failure, row-count anomaly, provider schema change and missing objects. Retain provider extracts long enough to support correction. |
| Security | OAuth or service credentials in Secret Manager, least-privilege provider role, regional review and vendor risk assessment. |
| Cost optimization | Avoid full reloads for high-volume SaaS systems; remove unused objects; schedule outside provider peak and BigQuery contention windows. |
| Common pitfalls | Treating provider-managed fields as stable; unclear source ownership; no deletion handling; no contract around formula fields. |

### Implementation sequence

1. Register the source and approve owner, classification, latency and recovery requirements.
2. Provision connectivity, service identity, secret, landing target, schema contract and monitoring through reusable infrastructure modules.
3. Execute a representative volume and failure test, including duplicate, late, malformed and replay scenarios.
4. Reconcile source and target independently and retain evidence with the ingestion ledger.
5. Promote the feed only after security, quality, operational and cost acceptance criteria pass.

### Acceptance evidence

| Evidence | Minimum acceptance |
| --- | --- |
| Contract | Versioned schema, semantics, owner and compatibility rule approved. |
| Integrity | Checksum, sequence, watermark or control total proves transfer completeness. |
| Recovery | Demonstrated replay or backfill without duplicate business records. |
| Observability | Freshness, failure, backlog and volume telemetry visible to owner. |
| Security | Identity, network, encryption and data-classification controls tested. |
| Cost | Baseline unit cost and expected monthly range recorded. |

## 4.6 File-Ingestion Architecture

Use file ingestion for bounded objects delivered through managed transfer, SFTP gateways, partner exchanges or application exports. The file protocol must include a completion signal. A file is written under a temporary name or prefix, followed by an atomic rename or manifest. Event notification triggers validation only after completion. The validator checks extension, MIME type, size, checksum, compression, encryption, schema and record count before moving data to raw or quarantine.

| Design aspect | Enterprise standard |
| --- | --- |
| Primary services | Cloud Storage, Storage Transfer Service, Eventarc or Pub/Sub notification, Cloud Run validation, Dataflow or BigQuery load |
| Idempotency and replay | Object generation, checksum and source batch ID form the identity. Duplicate objects are recorded and ignored or versioned according to contract. |
| Failure handling | Never parse a partially uploaded file. Quarantine unsupported types, decompression bombs, schema mismatches and control-total failures. |
| Security | Uniform bucket-level access, managed upload identity, object scanning for untrusted senders, retention and signed URL controls where needed. |
| Cost optimization | Use Parquet or Avro for high-volume analytical files; compact small files; lifecycle landing copies promptly after acceptance. |
| Common pitfalls | Filename-only control; no manifest; uncontrolled ZIP archives; allowing partners to list or read other partners’ objects. |

### Implementation sequence

1. Register the source and approve owner, classification, latency and recovery requirements.
2. Provision connectivity, service identity, secret, landing target, schema contract and monitoring through reusable infrastructure modules.
3. Execute a representative volume and failure test, including duplicate, late, malformed and replay scenarios.
4. Reconcile source and target independently and retain evidence with the ingestion ledger.
5. Promote the feed only after security, quality, operational and cost acceptance criteria pass.

### Acceptance evidence

| Evidence | Minimum acceptance |
| --- | --- |
| Contract | Versioned schema, semantics, owner and compatibility rule approved. |
| Integrity | Checksum, sequence, watermark or control total proves transfer completeness. |
| Recovery | Demonstrated replay or backfill without duplicate business records. |
| Observability | Freshness, failure, backlog and volume telemetry visible to owner. |
| Security | Identity, network, encryption and data-classification controls tested. |
| Cost | Baseline unit cost and expected monthly range recorded. |

## 4.7 Mainframe-Ingestion Architecture

Use batch unload as the default for mainframe datasets unless a supported, economically justified log-based pattern is available. Protect source batch windows and preserve copybook semantics. Mainframe jobs create consistent extracts with copybook/version metadata and control totals. Managed file transfer moves encrypted data to a dedicated landing zone. Conversion handles EBCDIC, packed decimals, variable records and signed fields before raw preservation and bronze normalization.

| Design aspect | Enterprise standard |
| --- | --- |
| Primary services | Enterprise scheduler, managed file transfer, Cloud Storage, Dataflow custom transforms, BigQuery, Secret Manager |
| Idempotency and replay | Business date, dataset name, generation number and checksum identify the extract. Replacement requires an explicit supersession record. |
| Failure handling | Reject copybook mismatches, truncated records and control-total differences. Maintain sample records and conversion test cases for every format version. |
| Security | Dedicated transfer channel, encryption, restricted projects, tightly controlled copybook repository and no sensitive record logging. |
| Cost optimization | Compress large fixed-width extracts; parallelize conversion by deterministic record boundaries; avoid full daily unloads when stable incremental keys exist. |
| Common pitfalls | Incorrect numeric conversion; character-set assumptions; losing source generation identifiers; changing copybook without versioning. |

### Implementation sequence

1. Register the source and approve owner, classification, latency and recovery requirements.
2. Provision connectivity, service identity, secret, landing target, schema contract and monitoring through reusable infrastructure modules.
3. Execute a representative volume and failure test, including duplicate, late, malformed and replay scenarios.
4. Reconcile source and target independently and retain evidence with the ingestion ledger.
5. Promote the feed only after security, quality, operational and cost acceptance criteria pass.

### Acceptance evidence

| Evidence | Minimum acceptance |
| --- | --- |
| Contract | Versioned schema, semantics, owner and compatibility rule approved. |
| Integrity | Checksum, sequence, watermark or control total proves transfer completeness. |
| Recovery | Demonstrated replay or backfill without duplicate business records. |
| Observability | Freshness, failure, backlog and volume telemetry visible to owner. |
| Security | Identity, network, encryption and data-classification controls tested. |
| Cost | Baseline unit cost and expected monthly range recorded. |

## 4.8 IoT-Ingestion Architecture

Use an edge-to-cloud event pattern for telemetry where devices are intermittently connected, events can arrive late and device identity must be verified. An approved device or gateway platform authenticates devices, buffers when offline and forwards telemetry to Pub/Sub. Dataflow validates device identity, event time and units, handles late events with watermarks, and writes time-series analytical data to BigQuery and operational aggregates to Bigtable where needed.

| Design aspect | Enterprise standard |
| --- | --- |
| Primary services | Device gateway or partner IoT platform, Pub/Sub, Dataflow, BigQuery, Bigtable, Cloud Storage |
| Idempotency and replay | Device ID, event timestamp and sequence number define uniqueness. Out-of-order events update windowed aggregates only within an approved lateness boundary. |
| Failure handling | Dead-letter invalid devices and malformed payloads; isolate noisy devices; monitor per-device and per-site gaps rather than only global throughput. |
| Security | Mutual authentication at the device platform, device credential rotation, topic isolation, payload minimization and geographic routing. |
| Cost optimization | Aggregate at the edge when lossless raw telemetry is not required; use compact schemas; set retention based on use case rather than indefinite default. |
| Common pitfalls | No device inventory; unbounded cardinality in metrics; accepting client clock blindly; retaining high-frequency data without business value. |

### Implementation sequence

1. Register the source and approve owner, classification, latency and recovery requirements.
2. Provision connectivity, service identity, secret, landing target, schema contract and monitoring through reusable infrastructure modules.
3. Execute a representative volume and failure test, including duplicate, late, malformed and replay scenarios.
4. Reconcile source and target independently and retain evidence with the ingestion ledger.
5. Promote the feed only after security, quality, operational and cost acceptance criteria pass.

### Acceptance evidence

| Evidence | Minimum acceptance |
| --- | --- |
| Contract | Versioned schema, semantics, owner and compatibility rule approved. |
| Integrity | Checksum, sequence, watermark or control total proves transfer completeness. |
| Recovery | Demonstrated replay or backfill without duplicate business records. |
| Observability | Freshness, failure, backlog and volume telemetry visible to owner. |
| Security | Identity, network, encryption and data-classification controls tested. |
| Cost | Baseline unit cost and expected monthly range recorded. |

## 4.9 Cross-Cloud Ingestion Architecture

Use managed transfer or governed federation based on query frequency, data gravity, sovereignty, egress and recovery. A cross-cloud query is not automatically cheaper or simpler than replication. For repeat analytics, managed transfer copies versioned objects or extracts into the regional data plane. For limited discovery, approved federation may query external storage. Cross-cloud credentials use workload identity federation where supported. Control totals and object inventories prove completeness.

| Design aspect | Enterprise standard |
| --- | --- |
| Primary services | Storage Transfer Service, BigLake external tables, BigQuery Omni where appropriate and validated, Workload Identity Federation, Cloud Storage |
| Idempotency and replay | Object version, ETag or provider generation and transfer job ID identify copies. Deletions and replacements follow an explicit mirror policy. |
| Failure handling | Monitor provider throttling, egress errors and partial inventories. Recovery can restart by object generation rather than full recopy. |
| Security | No long-lived cloud keys, explicit egress allowlists, residency review, encryption, isolated projects and contractually approved external access. |
| Cost optimization | Model source egress, inter-region transfer, repeated query scans and duplicate retention. Move stable high-use data close to consumers. |
| Common pitfalls | Hidden egress cost; unsupported fine-grained controls; ambiguous authoritative copy; direct analyst credentials to external cloud. |

### Implementation sequence

1. Register the source and approve owner, classification, latency and recovery requirements.
2. Provision connectivity, service identity, secret, landing target, schema contract and monitoring through reusable infrastructure modules.
3. Execute a representative volume and failure test, including duplicate, late, malformed and replay scenarios.
4. Reconcile source and target independently and retain evidence with the ingestion ledger.
5. Promote the feed only after security, quality, operational and cost acceptance criteria pass.

### Acceptance evidence

| Evidence | Minimum acceptance |
| --- | --- |
| Contract | Versioned schema, semantics, owner and compatibility rule approved. |
| Integrity | Checksum, sequence, watermark or control total proves transfer completeness. |
| Recovery | Demonstrated replay or backfill without duplicate business records. |
| Observability | Freshness, failure, backlog and volume telemetry visible to owner. |
| Security | Identity, network, encryption and data-classification controls tested. |
| Cost | Baseline unit cost and expected monthly range recorded. |

## 4.10 Partner-Data Ingestion Architecture

Use isolated landing and explicit contractual controls for data supplied by customers, suppliers, regulators and data vendors. Each partner receives a dedicated identity and prefix, endpoint or API product. Signed manifests, checksums and delivery windows are verified. The platform applies malware, schema, license and quality checks before data can enter raw storage.

| Design aspect | Enterprise standard |
| --- | --- |
| Primary services | Cloud Storage, Apigee or Cloud Run, Private Service Connect where applicable, Cloud KMS, Pub/Sub, validation service |
| Idempotency and replay | Partner delivery ID and content hash identify the submission. Corrections are new versions that reference the superseded delivery. |
| Failure handling | Quarantine invalid or late deliveries; notify the partner through the agreed channel; retain nonrepudiation evidence and processing outcome. |
| Security | Partner isolation, least privilege, key rotation, allowlists or private connectivity, payload classification and contractual use restrictions. |
| Cost optimization | Use shared validation services but separate storage and billing attribution. Define who pays for reprocessing caused by partner defects. |
| Common pitfalls | Shared partner folder; no contract for corrections; using data outside licensed purpose; no offboarding and credential revocation. |

### Implementation sequence

1. Register the source and approve owner, classification, latency and recovery requirements.
2. Provision connectivity, service identity, secret, landing target, schema contract and monitoring through reusable infrastructure modules.
3. Execute a representative volume and failure test, including duplicate, late, malformed and replay scenarios.
4. Reconcile source and target independently and retain evidence with the ingestion ledger.
5. Promote the feed only after security, quality, operational and cost acceptance criteria pass.

### Acceptance evidence

| Evidence | Minimum acceptance |
| --- | --- |
| Contract | Versioned schema, semantics, owner and compatibility rule approved. |
| Integrity | Checksum, sequence, watermark or control total proves transfer completeness. |
| Recovery | Demonstrated replay or backfill without duplicate business records. |
| Observability | Freshness, failure, backlog and volume telemetry visible to owner. |
| Security | Identity, network, encryption and data-classification controls tested. |
| Cost | Baseline unit cost and expected monthly range recorded. |

## 4.11 Historical Data Transfer Architecture

Use a staged migration pattern for terabyte- and petabyte-scale historical data. The objective is verifiable transfer with minimal source disruption, not the fastest possible copy at any cost. Inventory objects and tables, classify data, select online transfer or appliance, seed bulk history, run incremental deltas, reconcile independently, freeze the source window, apply final delta and certify the target.

| Design aspect | Enterprise standard |
| --- | --- |
| Primary services | Storage Transfer Service, Transfer Appliance when justified, Database Migration Service for appropriate databases, Cloud Storage, BigQuery load |
| Idempotency and replay | Inventory manifests, source checksums, object generations and target reconciliation records are retained for every wave. |
| Failure handling | Retry at object or partition granularity; do not restart entire waves; maintain rollback until consumers accept the target. |
| Security | Chain of custody, encryption, appliance handling procedures, transfer identities, data residency and temporary staging deletion. |
| Cost optimization | Compare network, appliance, egress, source load, compression and parallelism. Archive data may move directly to lower-cost storage classes. |
| Common pitfalls | No inventory baseline; combining transformation with initial transfer; deleting source before consumer acceptance; underestimating small-file overhead. |

### Implementation sequence

1. Register the source and approve owner, classification, latency and recovery requirements.
2. Provision connectivity, service identity, secret, landing target, schema contract and monitoring through reusable infrastructure modules.
3. Execute a representative volume and failure test, including duplicate, late, malformed and replay scenarios.
4. Reconcile source and target independently and retain evidence with the ingestion ledger.
5. Promote the feed only after security, quality, operational and cost acceptance criteria pass.

### Acceptance evidence

| Evidence | Minimum acceptance |
| --- | --- |
| Contract | Versioned schema, semantics, owner and compatibility rule approved. |
| Integrity | Checksum, sequence, watermark or control total proves transfer completeness. |
| Recovery | Demonstrated replay or backfill without duplicate business records. |
| Observability | Freshness, failure, backlog and volume telemetry visible to owner. |
| Security | Identity, network, encryption and data-classification controls tested. |
| Cost | Baseline unit cost and expected monthly range recorded. |

## 4.12 Ingestion Pattern Selection Matrix

| Requirement | Batch | CDC | Streaming events | API/SaaS | Managed transfer |
| --- | --- | --- | --- | --- | --- |
| Latency | Minutes to days | Seconds to minutes | Sub-second to minutes | Minutes to hours | Hours to days |
| Source impact | Scheduled extract load | Transaction-log load | Producer integration | Provider rate limits | Object inventory and copy |
| Replay | Batch ID and raw files | Log position plus snapshots | Message retention/archive | Window and checkpoint | Object generation |
| Schema change | At batch boundary | Continuous and potentially disruptive | Contract compatibility | Provider controlled | File contract |
| Best fit | Reporting and periodic products | Operational change propagation | Time-sensitive event processing | External applications | Historical or cross-cloud movement |
| Avoid when | Immediate action is required | No stable key/log support | Latency has no business value | Bulk export exists | Data must remain remote and low-use |


[PAGEBREAK]


# 5. Data-Storage and Layer Architecture

The storage model separates evidence, engineering state and consumer interfaces. Layer names are defined by contract and control, not by color alone. A dataset does not become silver or gold because of its location; it earns the designation through transformation, quality, ownership and access criteria.

![Enterprise data-layer model](/mnt/data/Volume_03_Enterprise_Data_Platform_Package/diagrams/05_data_layers.png){width=95%}

*Figure: Enterprise data-layer model*

## 5.1 Landing Zone

**Purpose.** Transient receipt area for incomplete or not-yet-validated deliveries. The reference technology is **Cloud Storage**. Typical retention is **Hours to 7 days**. Access is limited to Ingestion identity only; no consumer access.

| Control area | Standard |
| --- | --- |
| Entry criteria | Object completion, checksum, malware and manifest checks. |
| Exit criteria | A downstream layer accepts the data only after contract, quality and reconciliation checks appropriate to that layer. |
| Metadata | Owner, source, classification, retention, schema version and lineage are mandatory. |
| Security | Access follows least privilege and the layer’s sensitivity; raw and quarantine are more restricted than curated interfaces. |
| Operations | Freshness, volume, failure and storage growth are monitored. |
| Anti-pattern | Do not use landing as a permanent raw lake. |

## 5.2 Quarantine Zone

**Purpose.** Isolation for malformed, suspicious, contract-breaking or quality-failing records. The reference technology is **Cloud Storage and restricted BigQuery error tables**. Typical retention is **30-90 days or case-specific**. Access is limited to Operations, source owner and steward.

| Control area | Standard |
| --- | --- |
| Entry criteria | Failure reason, original identity, correlation ID and remediation status. |
| Exit criteria | A downstream layer accepts the data only after contract, quality and reconciliation checks appropriate to that layer. |
| Metadata | Owner, source, classification, retention, schema version and lineage are mandatory. |
| Security | Access follows least privilege and the layer’s sensitivity; raw and quarantine are more restricted than curated interfaces. |
| Operations | Freshness, volume, failure and storage growth are monitored. |
| Anti-pattern | Never silently drop invalid data. |

## 5.3 Raw Zone

**Purpose.** Immutable source evidence in original or lossless canonical form. The reference technology is **Cloud Storage; BigQuery only where source is inherently tabular and immutable**. Typical retention is **Legal and replay requirement**. Access is limited to Restricted engineering and audit access.

| Control area | Standard |
| --- | --- |
| Entry criteria | Source metadata, checksum, encryption and retention. |
| Exit criteria | A downstream layer accepts the data only after contract, quality and reconciliation checks appropriate to that layer. |
| Metadata | Owner, source, classification, retention, schema version and lineage are mandatory. |
| Security | Access follows least privilege and the layer’s sensitivity; raw and quarantine are more restricted than curated interfaces. |
| Operations | Freshness, volume, failure and storage growth are monitored. |
| Anti-pattern | No destructive updates; corrections create new versions. |

## 5.4 Bronze Layer

**Purpose.** Queryable source-aligned data with technical normalization and ingestion metadata. The reference technology is **BigQuery native or Iceberg table**. Typical retention is **Operational history requirement**. Access is limited to Domain engineers and controlled troubleshooting.

| Control area | Standard |
| --- | --- |
| Entry criteria | Type conversion, deduplication, operation metadata and basic validity. |
| Exit criteria | A downstream layer accepts the data only after contract, quality and reconciliation checks appropriate to that layer. |
| Metadata | Owner, source, classification, retention, schema version and lineage are mandatory. |
| Security | Access follows least privilege and the layer’s sensitivity; raw and quarantine are more restricted than curated interfaces. |
| Operations | Freshness, volume, failure and storage growth are monitored. |
| Anti-pattern | Do not embed cross-domain business definitions. |

## 5.5 Silver Layer

**Purpose.** Standardized, conformed and quality-controlled domain entities. The reference technology is **BigQuery; Iceberg when multi-engine writes are required**. Typical retention is **Domain policy**. Access is limited to Domain producers and approved consumers.

| Control area | Standard |
| --- | --- |
| Entry criteria | Canonical types, reference alignment, identity resolution and SCD policy. |
| Exit criteria | A downstream layer accepts the data only after contract, quality and reconciliation checks appropriate to that layer. |
| Metadata | Owner, source, classification, retention, schema version and lineage are mandatory. |
| Security | Access follows least privilege and the layer’s sensitivity; raw and quarantine are more restricted than curated interfaces. |
| Operations | Freshness, volume, failure and storage growth are monitored. |
| Anti-pattern | Breaking schema changes require product versioning. |

## 5.6 Gold Layer

**Purpose.** Domain-oriented aggregates and consumption models optimized for known use cases. The reference technology is **BigQuery**. Typical retention is **Business retention**. Access is limited to Named product consumers.

| Control area | Standard |
| --- | --- |
| Entry criteria | Business calculations, performance design and product quality gates. |
| Exit criteria | A downstream layer accepts the data only after contract, quality and reconciliation checks appropriate to that layer. |
| Metadata | Owner, source, classification, retention, schema version and lineage are mandatory. |
| Security | Access follows least privilege and the layer’s sensitivity; raw and quarantine are more restricted than curated interfaces. |
| Operations | Freshness, volume, failure and storage growth are monitored. |
| Anti-pattern | Avoid duplicating enterprise definitions across domains. |

## 5.7 Curated Layer

**Purpose.** Enterprise-certified, cross-domain products and regulatory datasets. The reference technology is **BigQuery and governed views**. Typical retention is **Enterprise or regulatory policy**. Access is limited to Broad approved enterprise consumers.

| Control area | Standard |
| --- | --- |
| Entry criteria | Governance certification, semantic review, lineage and stricter SLOs. |
| Exit criteria | A downstream layer accepts the data only after contract, quality and reconciliation checks appropriate to that layer. |
| Metadata | Owner, source, classification, retention, schema version and lineage are mandatory. |
| Security | Access follows least privilege and the layer’s sensitivity; raw and quarantine are more restricted than curated interfaces. |
| Operations | Freshness, volume, failure and storage growth are monitored. |
| Anti-pattern | Certification is an operating commitment, not a label. |

## 5.8 Semantic Layer

**Purpose.** Reusable measures, dimensions, KPI definitions and access-safe analytical interfaces. The reference technology is **Looker semantic model, BigQuery views and metrics artifacts**. Typical retention is **Version-controlled**. Access is limited to BI tools, analysts and approved applications.

| Control area | Standard |
| --- | --- |
| Entry criteria | Metric ownership, test cases and backward compatibility. |
| Exit criteria | A downstream layer accepts the data only after contract, quality and reconciliation checks appropriate to that layer. |
| Metadata | Owner, source, classification, retention, schema version and lineage are mandatory. |
| Security | Access follows least privilege and the layer’s sensitivity; raw and quarantine are more restricted than curated interfaces. |
| Operations | Freshness, volume, failure and storage growth are monitored. |
| Anti-pattern | Do not allow dashboards to redefine certified KPIs independently. |

## 5.9 Sandbox Layer

**Purpose.** Time-bound exploration using approved copies or masked data. The reference technology is **BigQuery sandbox datasets and controlled Cloud Storage**. Typical retention is **7-90 days**. Access is limited to Named project groups; no production dependencies.

| Control area | Standard |
| --- | --- |
| Entry criteria | Budget, expiry, restricted data rules and no inbound production contract. |
| Exit criteria | A downstream layer accepts the data only after contract, quality and reconciliation checks appropriate to that layer. |
| Metadata | Owner, source, classification, retention, schema version and lineage are mandatory. |
| Security | Access follows least privilege and the layer’s sensitivity; raw and quarantine are more restricted than curated interfaces. |
| Operations | Freshness, volume, failure and storage growth are monitored. |
| Anti-pattern | Sandbox outputs must be productized before operational use. |

## 5.10 Archive Layer

**Purpose.** Long-term, low-access records retained for compliance, recovery or historical analysis. The reference technology is **Cloud Storage Nearline/Coldline/Archive based on access pattern**. Typical retention is **Record schedule**. Access is limited to Privileged restore process.

| Control area | Standard |
| --- | --- |
| Entry criteria | Retention lock where approved, inventory and restore tests. |
| Exit criteria | A downstream layer accepts the data only after contract, quality and reconciliation checks appropriate to that layer. |
| Metadata | Owner, source, classification, retention, schema version and lineage are mandatory. |
| Security | Access follows least privilege and the layer’s sensitivity; raw and quarantine are more restricted than curated interfaces. |
| Operations | Freshness, volume, failure and storage growth are monitored. |
| Anti-pattern | Archive is not a substitute for a documented restore process. |

## 5.11 Data-Layer Standards

| Layer | Authoritative purpose | Mutation policy | Consumer contract | Typical optimization |
| --- | --- | --- | --- | --- |
| Landing | Transfer handoff | Mutable only during upload; short-lived | None | Object size and transfer throughput |
| Quarantine | Failure evidence | Append status and remediation metadata | Operational only | Search by batch, error and owner |
| Raw | Source evidence | Append/version only | Source contract | Compression and lifecycle |
| Bronze | Queryable source alignment | Controlled merge for CDC | Technical schema | Partition by source event or ingestion date |
| Silver | Domain standard | Versioned merge and history | Domain entity contract | Partition and cluster for domain access |
| Gold | Use-case optimized | Managed rebuild or incremental update | Product interface | Materialization and clustering |
| Curated | Enterprise certified | Strict change governance | Enterprise product contract | Workload isolation and stable views |
| Semantic | Metric and meaning | Git-versioned model | KPI and semantic contract | Caching and aggregate awareness |
| Sandbox | Exploration | User-managed within expiry | No production contract | Budgets and expiry |
| Archive | Retention and recovery | Immutable under policy | Restore contract | Storage class and inventory |


[PAGEBREAK]


# 6. Core Data Services and Service-Selection Guidance

The platform uses a small number of strategic services, each with a defined role. The selection model prevents BigQuery from becoming an operational database, prevents Bigtable from being used for relational reporting and prevents Iceberg from being introduced without a real multi-engine requirement.

## 6.1 Cloud Storage Architecture

Cloud Storage is the durable object foundation for landing, quarantine, raw, replay and archive data. Buckets are regional or dual-region according to residency and recovery, use uniform bucket-level access, public access prevention and lifecycle rules. Restricted buckets use CMEK when required. Object names include domain, source, contract version, business date and batch or event identity.

| Area | Guidance |
| --- | --- |
| Benefits and limitations | Benefits include massive scale, open-format support and independent lifecycle. Limitations include object semantics rather than database transactions, small-object overhead and the need for external metadata. |
| Security | Use dedicated service identities, least privilege, regional data placement, audit logging and CMEK/service perimeters where required. |
| Monitoring and cost | Monitor object count, bytes, request errors, lifecycle effectiveness, unexpected egress and retention-policy changes. Optimize with compression, file compaction, suitable storage classes and regional locality. |
| Alternatives | Select an alternative only when the workload requires different consistency, latency, openness, compatibility or operational characteristics. |
| Common pitfalls | Do not use bucket ACLs, mutable raw objects, globally shared catch-all buckets or irreversible retention locks without legal approval. |
| Production gate | Validate regional support, quotas, encryption, service-perimeter compatibility, failure behavior and recovery before approval. |

## 6.2 BigLake Architecture

BigLake provides governed access to data in Cloud Storage and across supported external stores. Use BigLake external tables for controlled query access to open files and Apache Iceberg managed or external tables when more than one engine must operate on the same table.

| Area | Guidance |
| --- | --- |
| Benefits and limitations | Benefits include lake and warehouse convergence, customer-owned storage and open-engine interoperability. Limitations and feature compatibility vary by table type, engine and region; teams must validate DML, governance, performance and preview status. |
| Security | Use dedicated service identities, least privilege, regional data placement, audit logging and CMEK/service perimeters where required. |
| Monitoring and cost | Monitor query scan, metadata refresh, file layout, authorization failures and cross-region access. Optimize Parquet size, partition layout and metadata maintenance. |
| Alternatives | Select an alternative only when the workload requires different consistency, latency, openness, compatibility or operational characteristics. |
| Common pitfalls | Do not introduce Iceberg only for fashion, mix unmanaged writers without concurrency testing or assume every BigQuery feature behaves identically across all external table types. |
| Production gate | Validate regional support, quotas, encryption, service-perimeter compatibility, failure behavior and recovery before approval. |

## 6.3 BigQuery Architecture

BigQuery is the primary analytical warehouse and data-product serving layer. Domain projects own datasets; environment and region are explicit; reservations isolate production BI, engineering and data science where workload predictability justifies capacity.

| Area | Guidance |
| --- | --- |
| Benefits and limitations | Benefits include serverless scale, GoogleSQL, fine-grained security, ML and sharing integration. Limitations include cost sensitivity to scan patterns, quotas, regional boundaries and differences from operational databases. |
| Security | Use dedicated service identities, least privilege, regional data placement, audit logging and CMEK/service perimeters where required. |
| Monitoring and cost | Monitor slot utilization, queued time, bytes processed, table growth, failed jobs, long-running queries, storage age and per-product cost. Optimize partition pruning, clustering, materialized results, workload assignment and query review. |
| Alternatives | Select an alternative only when the workload requires different consistency, latency, openness, compatibility or operational characteristics. |
| Common pitfalls | Do not use SELECT *, ingestion-time partitions without need, unbounded cross joins, direct production owner grants or datasets that mix unrelated security classes. |
| Production gate | Validate regional support, quotas, encryption, service-perimeter compatibility, failure behavior and recovery before approval. |

## 6.4 Bigtable Use Cases

Use Bigtable for very high-throughput, low-latency key-value and wide-column workloads such as device state, time-series serving, personalization features and operational aggregates. Schema design begins with access patterns and row-key distribution.

| Area | Guidance |
| --- | --- |
| Benefits and limitations | Benefits include horizontal scale and predictable low-latency access. It is not a general relational database; joins and arbitrary relational queries are not the design center. |
| Security | Use dedicated service identities, least privilege, regional data placement, audit logging and CMEK/service perimeters where required. |
| Monitoring and cost | Monitor per-app-profile latency, CPU, storage, hotspot indicators and replication. Optimize row keys, garbage collection, app profiles and cluster sizing. |
| Alternatives | Select an alternative only when the workload requires different consistency, latency, openness, compatibility or operational characteristics. |
| Common pitfalls | Do not use sequential hot row keys, large single rows, relational normalization or analytical full scans on serving clusters without workload isolation. |
| Production gate | Validate regional support, quotas, encryption, service-perimeter compatibility, failure behavior and recovery before approval. |

## 6.5 Spanner Use Cases

Use Spanner for mission-critical relational applications that require transactional consistency with regional or global scale, strong availability and horizontal growth. It may also support graph, search or vector-enabled operational patterns where validated.

| Area | Guidance |
| --- | --- |
| Benefits and limitations | Benefits include relational semantics, synchronous replication and scale. Limitations include a different cost and schema design model from conventional single-instance databases and the need to choose instance configuration carefully. |
| Security | Use dedicated service identities, least privilege, regional data placement, audit logging and CMEK/service perimeters where required. |
| Monitoring and cost | Monitor CPU, storage, transaction latency, lock contention, query plans and replication health. Optimize keys, interleaving where appropriate, indexes and transaction scope. |
| Alternatives | Select an alternative only when the workload requires different consistency, latency, openness, compatibility or operational characteristics. |
| Common pitfalls | Do not select Spanner only for large storage, use monotonically increasing hot keys or run unbounded analytical scans against critical transactional capacity. |
| Production gate | Validate regional support, quotas, encryption, service-perimeter compatibility, failure behavior and recovery before approval. |

## 6.6 AlloyDB Use Cases

Use AlloyDB for demanding PostgreSQL-compatible transactional applications, operational marts and modernization scenarios where application compatibility and regional high availability matter more than global horizontal write scale.

| Area | Guidance |
| --- | --- |
| Benefits and limitations | Benefits include PostgreSQL compatibility and managed enterprise operation. Limitations include regional placement, connection architecture and the responsibility to design backups, read pools and failover. |
| Security | Use dedicated service identities, least privilege, regional data placement, audit logging and CMEK/service perimeters where required. |
| Monitoring and cost | Monitor database, instance and read-pool metrics, connections, query latency, storage and backup status. Optimize indexes, connection pooling, read pools and query plans. |
| Alternatives | Select an alternative only when the workload requires different consistency, latency, openness, compatibility or operational characteristics. |
| Common pitfalls | Do not use AlloyDB as the enterprise warehouse, expose it directly to uncontrolled analyst queries or assume every PostgreSQL extension is supported without validation. |
| Production gate | Validate regional support, quotas, encryption, service-perimeter compatibility, failure behavior and recovery before approval. |

## 6.7 Pub/Sub

Pub/Sub is the cloud-native event backbone for decoupled producers and consumers. Topics represent stable business event contracts; subscriptions represent consumer processing needs.

| Area | Guidance |
| --- | --- |
| Benefits and limitations | Benefits include managed scale, independent subscriptions and replay through retention or snapshots. Delivery is at least once by default, so consumers must handle duplicates. |
| Security | Use dedicated service identities, least privilege, regional data placement, audit logging and CMEK/service perimeters where required. |
| Monitoring and cost | Monitor oldest unacked message, backlog bytes, publish errors, subscriber throughput and dead-letter volume. Optimize retention, message size and subscriber concurrency. |
| Alternatives | Select an alternative only when the workload requires different consistency, latency, openness, compatibility or operational characteristics. |
| Common pitfalls | Do not share one topic for unrelated event types, embed sensitive secrets, assume global ordering or allow unmanaged subscriber proliferation. |
| Production gate | Validate regional support, quotas, encryption, service-perimeter compatibility, failure behavior and recovery before approval. |

## 6.8 Dataflow

Dataflow executes Apache Beam pipelines for batch and streaming transformations that need parallel processing, state, windows, event time or reusable connectors.

| Area | Guidance |
| --- | --- |
| Benefits and limitations | Benefits include managed autoscaling and a common programming model. Limitations include pipeline engineering complexity, worker networking and cost if jobs are poorly bounded. |
| Security | Use dedicated service identities, least privilege, regional data placement, audit logging and CMEK/service perimeters where required. |
| Monitoring and cost | Monitor system lag, watermark, throughput, worker CPU/memory, failed bundles and autoscaling. Optimize fusion, batching, state size, worker type and Streaming Engine where appropriate. |
| Alternatives | Select an alternative only when the workload requires different consistency, latency, openness, compatibility or operational characteristics. |
| Common pitfalls | Do not place simple SQL transformations in Beam, use unbounded side inputs or omit load tests with realistic skew. |
| Production gate | Validate regional support, quotas, encryption, service-perimeter compatibility, failure behavior and recovery before approval. |

## 6.9 Datastream

Datastream provides serverless CDC and replication for supported databases and destinations. It captures source changes but does not eliminate the need for target merge, history, schema and reconciliation design.

| Area | Guidance |
| --- | --- |
| Benefits and limitations | Benefits include reduced connector operations and low-latency capture. Limitations depend on supported sources, objects, connectivity, schema behavior and regions. |
| Security | Use dedicated service identities, least privilege, regional data placement, audit logging and CMEK/service perimeters where required. |
| Monitoring and cost | Monitor stream status, source lag, errors, throughput and rejected events. Optimize included objects and merge cadence. |
| Alternatives | Select an alternative only when the workload requires different consistency, latency, openness, compatibility or operational characteristics. |
| Common pitfalls | Do not capture the entire database by default, ignore source log retention or treat CDC order as business history without keys and sequence. |
| Production gate | Validate regional support, quotas, encryption, service-perimeter compatibility, failure behavior and recovery before approval. |

## 6.10 Storage Transfer Service

Storage Transfer Service manages object movement from supported sources to Cloud Storage and between buckets. It is the default for recurring or large-scale object transfer where restartability and inventory matter.

| Area | Guidance |
| --- | --- |
| Benefits and limitations | Benefits include managed scheduling and object-level retry. Limitations include source-specific features, network and egress dependencies. |
| Security | Use dedicated service identities, least privilege, regional data placement, audit logging and CMEK/service perimeters where required. |
| Monitoring and cost | Monitor job status, bytes, object counts, failures and skipped items. Optimize parallelism, change detection and source layout. |
| Alternatives | Select an alternative only when the workload requires different consistency, latency, openness, compatibility or operational characteristics. |
| Common pitfalls | Do not use custom copy scripts for petabyte migrations without a compelling capability gap. |
| Production gate | Validate regional support, quotas, encryption, service-perimeter compatibility, failure behavior and recovery before approval. |

## 6.11 Knowledge Catalog and Dataplex Capabilities

Knowledge Catalog is the enterprise metadata, discovery and governance plane. It inventories assets, connects technical and business context, supports glossary, lineage, profiling and quality, and provides context for data and AI. Dataplex APIs and features continue to underpin several governance operations.

| Area | Guidance |
| --- | --- |
| Benefits and limitations | Benefits include native integration and centralized discoverability. Limitations include service-specific lineage coverage, metadata quality dependence and product evolution that must be monitored. |
| Security | Use dedicated service identities, least privilege, regional data placement, audit logging and CMEK/service perimeters where required. |
| Monitoring and cost | Monitor catalog coverage, missing mandatory metadata, scan failures, lineage gaps, quality rule outcomes and stale ownership. |
| Alternatives | Select an alternative only when the workload requires different consistency, latency, openness, compatibility or operational characteristics. |
| Common pitfalls | Do not treat automatic discovery as complete governance or allow unowned assets to become certified. |
| Production gate | Validate regional support, quotas, encryption, service-perimeter compatibility, failure behavior and recovery before approval. |

## 6.12 BigQuery Sharing

BigQuery sharing, formerly Analytics Hub, publishes governed datasets and streams through exchanges and listings. Subscribers receive linked datasets rather than uncontrolled exports.

| Area | Guidance |
| --- | --- |
| Benefits and limitations | Benefits include controlled sharing across project and organizational boundaries. Limitations include location, feature and subscriber-governance considerations. |
| Security | Use dedicated service identities, least privilege, regional data placement, audit logging and CMEK/service perimeters where required. |
| Monitoring and cost | Monitor listings, subscribers, access changes, query usage and data-product SLOs. Optimize by sharing views or products rather than broad raw datasets. |
| Alternatives | Select an alternative only when the workload requires different consistency, latency, openness, compatibility or operational characteristics. |
| Common pitfalls | Do not publish unclassified tables, grant direct owner roles to subscribers or treat a listing as a substitute for a contract. |
| Production gate | Validate regional support, quotas, encryption, service-perimeter compatibility, failure behavior and recovery before approval. |

## 6.13 Technology Selection Matrix

| Need | Preferred service | Conditional alternative | Decision test |
| --- | --- | --- | --- |
| Enterprise analytical SQL | BigQuery | Iceberg plus Spark for multi-engine transformations | Is governed SQL analytics the primary workload? |
| Immutable/open object data | Cloud Storage | None | Does the data require object retention or multi-engine files? |
| Open table interoperability | Apache Iceberg managed/external tables | BigQuery native | Must multiple engines read/write one authoritative table? |
| High-rate event transport | Pub/Sub | Existing Kafka with controlled bridge | Are cloud-native producers/consumers and independent subscriptions required? |
| Stateful stream processing | Dataflow | Spark Structured Streaming | Are event-time, windows, state and autoscaling needed? |
| Database CDC | Datastream | Approved third-party CDC | Is the source and required behavior supported? |
| Low-latency wide-column serving | Bigtable | Spanner or AlloyDB | Is access key-based with very high throughput? |
| Global transactional relational | Spanner | Regional AlloyDB | Is strong transactional consistency across scale/regions required? |
| PostgreSQL-compatible transaction | AlloyDB | Cloud SQL or Spanner PostgreSQL dialect | Is PostgreSQL compatibility the main constraint? |
| Metadata and governance | Knowledge Catalog | Enterprise third-party catalog integration | Can native coverage satisfy governance and integration needs? |
| Controlled data publication | BigQuery sharing | API or governed export | Can consumers use linked datasets or stream listings? |


[PAGEBREAK]


# 7. Open Formats, Schema Evolution and Physical Design

Physical design is a product responsibility supported by platform standards. File and table choices are based on access path, update pattern, engine interoperability, schema evolution, retention and unit cost. No single format is optimal for every layer.

## 7.1 Open-Data Formats

| Format | Preferred use | Strengths | Constraints |
| --- | --- | --- | --- |
| Parquet | Large analytical files and Iceberg data files | Columnar compression, predicate pushdown and broad engine support | Not a transaction format by itself; requires compaction and metadata discipline. |
| Avro | Event payloads, row-oriented interchange and evolving schemas | Schema embedding, compact binary and strong streaming ecosystem | Less efficient for wide analytical scans than columnar formats. |
| JSON | Low-volume APIs, diagnostics and human-readable exchange | Flexible and ubiquitous | Verbose, weak types and expensive at scale. |
| CSV | Legacy exchange only | Simple compatibility | No native types, escaping ambiguity and poor compression. |
| Apache Iceberg | Open table format for multi-engine lakehouse | Snapshots, schema evolution, partition evolution and transactional metadata | Operational complexity and feature compatibility must be tested. |
| BigQuery native | Primary curated analytical storage | Managed performance, security and integrated governance | Not an open file format; external engines use supported interfaces rather than direct files. |

## 7.2 Apache Iceberg Considerations

Select Iceberg when the enterprise needs a common authoritative table across BigQuery and one or more open engines, when customer-owned object storage is a requirement, or when an existing Iceberg estate is being modernized. Prefer managed capabilities where they meet engine and governance needs. Define one catalog authority, supported writer engines, commit concurrency, compaction, snapshot expiration and orphan-file cleanup. Test access control and row/column policy behavior for every engine rather than assuming BigQuery-native semantics apply universally.

Do not create a parallel Iceberg copy of every BigQuery table. The additional metadata, file maintenance and engine compatibility surface must create measurable value. Curated BI products with BigQuery-only consumers generally remain native BigQuery tables. Raw and bronze open-format data can use Parquet without becoming Iceberg tables until transactional table semantics are required.

## 7.3 Parquet Standards

| Standard | Guidance |
| --- | --- |
| File size | Target approximately 256 MB to 1 GB for large analytical datasets; tune to engine and workload. |
| Compression | Use a broadly supported codec such as Snappy or Zstandard after validation. |
| Schema | Use stable field names, logical types and explicit nullability. |
| Partitioning | Use business predicates with bounded cardinality; avoid folder-per-unique-value. |
| Statistics | Ensure writers produce usable column statistics and row-group metadata. |
| Compaction | Compact small files through managed jobs with idempotent output. |
| Security | Do not embed secrets or uncontrolled sensitive metadata in paths. |

## 7.4 Avro Standards

| Standard | Guidance |
| --- | --- |
| Schema identity | Register schema ID and compatibility mode with every event or batch contract. |
| Compatibility | Backward compatible by default for shared event streams; breaking changes require a new major version/topic. |
| Defaults | Provide safe defaults for new optional fields. |
| Logical types | Use date, timestamp and decimal logical types consistently. |
| Union use | Avoid complex unions that create inconsistent mappings in downstream engines. |
| Sensitive fields | Classify in the contract and apply producer-side minimization. |

## 7.5 Schema Evolution

Schema evolution is a governed product change. Additive nullable fields are generally backward compatible. Renames are implemented as add-populate-deprecate rather than destructive rename. Type widening requires consumer testing. Type narrowing, semantic reinterpretation and key changes are breaking. The contract repository records compatibility mode, effective date, producer notice period and migration path. CI validates source schemas, table definitions, policy tags and dependent views before promotion.

| Change | Default classification | Required action |
| --- | --- | --- |
| Add nullable field | Backward compatible | Update contract and tests; no major version. |
| Add required field without default | Breaking | New major version or staged default population. |
| Rename field | Breaking | Introduce new field, dual-publish, migrate and deprecate old field. |
| Widen numeric type | Conditionally compatible | Test consumers and update contract. |
| Narrow or reinterpret type | Breaking | New version and migration. |
| Change key or grain | Breaking semantic change | New product version and reconciliation. |
| Remove field | Breaking | Deprecation notice, usage evidence and major version. |

## 7.6 BigQuery Partitioning Standards

Partition large fact and event tables by the column that most reliably bounds consumer queries, normally business event date. Require partition filters on high-cost production tables where appropriate. Use ingestion-time partitioning only when source event time is unavailable or untrustworthy. Integer-range partitioning is reserved for stable numeric ranges. Partition counts and modification patterns must remain within service limits, which are validated during design.

| Decision | Standard |
| --- | --- |
| Partition column | Top-level DATE, TIMESTAMP or DATETIME aligned to dominant filter. |
| Granularity | Daily by default; hourly only for very high volume and operational need; monthly for low-volume long history. |
| Filter requirement | Enabled for expensive production tables and enforced in product query examples. |
| Late data | Write to the correct business partition; monitor late-arrival rate. |
| Expiration | Set only when approved by retention schedule and downstream recovery needs. |
| Backfill | Use partition-scoped replacement or MERGE with audit evidence. |

## 7.7 BigQuery Clustering Standards

Cluster tables when queries repeatedly filter, aggregate or join on selective columns and partitioning alone does not sufficiently prune data. Place the most frequently filtered high-value column first. Use up to four clustering columns only when each has demonstrated benefit. Review recommendations and query history quarterly; clustering is not a one-time design decision.

| Workload | Example clustering order |
| --- | --- |
| Customer events | customer_id, event_type, region_code |
| Orders | customer_id, order_status, sales_channel |
| Finance ledger | legal_entity_id, account_id, currency_code |
| Telemetry | device_id, site_id, event_type |
| Access audit | principal, resource_type, action |


[PAGEBREAK]


# 8. Data Lifecycle, Retention, Archival, Legal Hold and Privacy Deletion

Lifecycle controls implement records policy, privacy obligations, recovery and cost management. Retention is derived from business purpose and legal schedule, not from storage affordability. A record may have multiple obligations; the most restrictive valid control applies until legal, regulatory and business owners approve disposition.

![Data lifecycle, retention and privacy controls](/mnt/data/Volume_03_Enterprise_Data_Platform_Package/diagrams/10_data_lifecycle.png){width=95%}

*Figure: Data lifecycle, retention and privacy controls*

## 8.1 Lifecycle States

| State | Control objective | Evidence |
| --- | --- | --- |
| Created | Capture provenance, owner, purpose and classification. | Ingestion ledger and catalog entry. |
| Active | Meet product SLO and approved access purpose. | Usage, quality and access logs. |
| Inactive | Reduce compute and access while preserving required data. | Lifecycle state and consumer analysis. |
| Archived | Retain in lower-access storage with tested restoration. | Inventory, retention and restore test. |
| Held | Prevent deletion while legal or regulatory hold is active. | Case ID, approver and hold audit. |
| Eligible for deletion | All obligations expired and dependencies resolved. | Disposition approval and impact analysis. |
| Deleted or anonymized | Data and derived copies disposed according to policy. | Deletion certificate and exception list. |

## 8.2 Retention Architecture

Retention schedules are stored as governed metadata and translated into bucket lifecycle rules, object retention settings, table and partition expiration or workflow-driven deletion. Irreversible bucket retention lock is used only after legal approval, testing and confirmation that the period cannot require reduction. Product owners cannot override enterprise record schedules through ad hoc table settings.

The raw layer often has the longest replay-oriented retention, but this is not universal. Sensitive personal data may have a shorter lawful period than aggregated products. Derived tables inherit purpose and deletion obligations unless they are demonstrably anonymized. The catalog records the schedule ID and deletion method for every certified product.

## 8.3 Archival and Restore

| Control | Standard |
| --- | --- |
| Eligibility | No active SLO-dependent consumer and retention still applies. |
| Format | Open, documented and independently verifiable. |
| Index | Dataset, partition, date range, schema version, checksum and owner. |
| Restore objective | Defined by service tier and tested at least annually for critical archives. |
| Security | Same or stronger classification than source; privileged restore identity. |
| Cost | Storage class selected from measured restore frequency and retrieval economics. |

## 8.4 Legal Hold

A legal hold suspends normal deletion for identified records without granting broader access. The legal function supplies case identifier, scope, custodian, start date and release authority. Cloud Storage object holds and retention policies can support immutable records. BigQuery records may require protected snapshot/export or a dedicated held dataset depending on scope and legal evidence requirements. Hold application and release are audited and separated from ordinary data engineering roles.

## 8.5 Privacy Deletion

1. Receive a verified request and determine lawful scope, identity keys and jurisdictions.
2. Resolve the data subject across source-aligned and product identifiers.
3. Identify affected assets through lineage, product metadata and searchable indexes.
4. Apply source-system deletion or suppression according to authority.
5. Delete, anonymize or cryptographically render inaccessible eligible platform copies.
6. Propagate tombstones to downstream products and prevent replay from resurrecting deleted data.
7. Record exceptions for legal hold or statutory retention with owner and expiry.
8. Issue a deletion certificate containing scope, systems, timestamp, outcome and exceptions.


[PAGEBREAK]


# 9. Metadata, Knowledge Catalog and Governance Architecture

Metadata is part of the product interface. Technical discovery without ownership and meaning is insufficient; business definitions without executable lineage and quality are equally insufficient. The governance plane combines automatic harvesting with explicit domain accountability.

![Metadata, governance and quality architecture](/mnt/data/Volume_03_Enterprise_Data_Platform_Package/diagrams/06_metadata_governance.png){width=95%}

*Figure: Metadata, governance and quality architecture*

## 9.1 Metadata Architecture

| Metadata class | Examples | System of record |
| --- | --- | --- |
| Technical | Projects, datasets, tables, columns, schemas, formats and partitions | Cloud services and Knowledge Catalog inventory |
| Operational | Runs, freshness, volume, failures, lag and cost | Monitoring, logging and product telemetry |
| Business | Definitions, owner, steward, domain, purpose and KPI meaning | Knowledge Catalog glossary and product repository |
| Security | Classification, policy tags, masking policy, residency and legal basis | Security metadata and catalog |
| Quality | Rules, scores, exceptions, certification and remediation | Quality service and product scorecard |
| Lineage | Source, transformation, destination, field mapping and consumer dependency | Knowledge Catalog lineage plus custom lineage events |
| Contract | Schema, compatibility, SLO, interface, version and deprecation | Version-controlled contract repository |
| Lifecycle | Retention schedule, archive class, hold and deletion method | Records system and catalog |

## 9.2 Knowledge Catalog

Knowledge Catalog is the enterprise discovery and governance surface. Automatic inventory provides broad technical coverage, while domains add business context, ownership, classifications, glossary relationships and product status. Search permissions must not reveal sensitive metadata beyond policy. Catalog completeness is measured, not assumed.

Mandatory metadata for production products includes domain, product name, owner, steward, support channel, description, grain, refresh target, quality status, classification, residency, retention schedule, source lineage, contract location, version, lifecycle status and approved access path. Assets missing mandatory fields cannot be certified.

## 9.3 Dataplex Capabilities

Dataplex capabilities and APIs underpin inventory, profiling, quality and lineage functions that are now presented under Knowledge Catalog. The architecture uses automatic data quality for new implementations rather than legacy data-quality tasks. Data-quality rules and scans are managed as code where possible, and scan results feed product scorecards and publication gates.

## 9.4 Technical and Business Metadata

| Area | Mandatory fields | Owner |
| --- | --- | --- |
| Dataset | Domain, environment, location, classification, retention and support tier | Platform plus domain |
| Table | Description, grain, keys, partition, owner, source and lifecycle | Domain data owner |
| Column | Business meaning, type, sensitivity, null semantics and allowed values | Data steward |
| Pipeline | Source, destination, schedule, SLO, runbook and code version | Technical owner |
| Product | Consumer, contract, SLO, quality, access, version and deprecation | Product owner |
| Metric | Definition, formula, aggregation, dimensions and approval | Business metric owner |

## 9.5 Business Glossary

The glossary defines enterprise terms independently of individual tables. A term has a definition, domain, steward, synonyms, exclusions, examples and approved relationships. Terms can be linked to data products, columns and metrics. The governance council resolves cross-domain conflicts; domains retain authority for domain-specific terms. A glossary is not complete when it is merely imported from spreadsheets without stewardship and usage.

## 9.6 Data Lineage

Lineage supports impact analysis, audit, privacy deletion and incident response. Native lineage is used where supported. Custom pipelines emit lineage events that identify source and target assets, operation, code version, run ID and column mappings for critical products. Lineage completeness is an SLO for certified products. A broken lineage graph is treated as a production governance defect, not documentation debt.

## 9.7 Data Profiling

Profiling establishes distributions, null rates, uniqueness, common values, bounds and potential sensitive content before rule design. Profiles are sampled or full according to risk and cost. They are refreshed when source schema, population or product grain changes. Profile results must not expose sensitive sample values to unauthorized users.

## 9.8 Data-Quality Architecture

Quality rules execute at source receipt, layer transition and product publication. Transport integrity and schema validity are ingestion controls. Domain correctness, referential integrity and business reconciliation belong in silver and gold. Certified products add freshness, completeness, validity, consistency, uniqueness and accuracy objectives. Critical failures block publication; noncritical failures lower score and create a steward workflow.

| Dimension | Example rule | Tier 0 threshold | Failure action |
| --- | --- | --- | --- |
| Completeness | Required customer ID is populated | 100% | Block publication and alert owner. |
| Validity | Country code exists in approved reference | 99.99% | Quarantine invalid records and investigate. |
| Uniqueness | Order ID unique within source domain | 100% | Block merge and reconcile source. |
| Consistency | Order total equals line sum plus tax | 99.99% | Block certified product. |
| Timeliness | Latest source window available | 99.9% within SLO | Declare freshness incident. |
| Referential integrity | Account references existing customer | 99.99% | Quarantine or use approved unknown member. |
| Accuracy | Finance debit equals credit control | 100% | Block regulatory publication. |

## 9.9 Quality Score and Certification

| Score band | Status | Consumer behavior |
| --- | --- | --- |
| 99.5-100 | Certified | Approved for executive, regulatory or operational use within stated scope. |
| 98-99.49 | Governed | Usable with documented exceptions; not for highest-criticality decisions. |
| 95-97.99 | Conditional | Consumer warning and remediation plan required. |
| Below 95 | Uncertified | Not published as an enterprise product. |


[PAGEBREAK]


# 10. Data Contracts, Schema Registry, Ownership and Certification

A data contract is a versioned agreement between producer and consumers. It covers more than schema: ownership, semantics, keys, update behavior, quality, latency, security, retention, compatibility and deprecation. Contracts are stored in source control and validated in CI and at runtime.

## 10.1 Data Contract Contents

| Section | Required content |
| --- | --- |
| Identity | Domain, product/feed name, owner, steward, version and status. |
| Interface | Topic, table, view, API or file path and supported access method. |
| Schema | Fields, types, nullability, keys, grain, allowed values and classification. |
| Semantics | Business meaning, units, time zone, calculation and source authority. |
| Change | Compatibility mode, notice period, migration path and deprecation. |
| SLO | Freshness, availability, quality, support hours and recovery tier. |
| Security | Purpose, eligible groups, row/column policy, masking and residency. |
| Lifecycle | Retention, archive, deletion and legal-hold behavior. |
| Operations | Monitoring, runbook, escalation and consumer notification. |
| Cost | Cost owner, unit metric and consumer cost considerations. |

## 10.2 Schema Registry

Event schemas use an approved registry and compatibility mode. Pub/Sub schemas can validate supported event representations. Batch and table schemas are stored in the contract repository and compared during CI and ingestion. The registry must not become a duplicate business glossary; it controls machine compatibility, while Knowledge Catalog provides broader context and discovery.

## 10.3 Data Ownership and Stewardship

| Role | Accountability |
| --- | --- |
| Business data owner | Purpose, lawful use, product priority, access approval and risk acceptance. |
| Data-product owner | Roadmap, consumer contract, SLO, cost and lifecycle. |
| Data steward | Definitions, quality rules, reference data and issue remediation. |
| Technical owner | Pipeline, table, deployment, monitoring and recovery. |
| Platform owner | Shared services, templates, reliability and platform cost. |
| Security owner | Control design, threat assessment, exceptions and incident response. |
| Privacy/records owner | Legal basis, retention, hold and deletion policy. |
| Consumer owner | Approved purpose, downstream controls and usage compliance. |

## 10.4 Data Certification

1. Product canvas approved with owner, consumers and business value.
2. Contract versioned and schema compatibility tested.
3. Classification, residency, retention and legal basis recorded.
4. End-to-end lineage visible and critical column mappings verified.
5. Quality rules pass representative and peak-volume data.
6. Access interfaces, row/column controls and masking tested with positive and negative identities.
7. Freshness, availability, recovery, monitoring and runbooks pass production readiness review.
8. Cost baseline, owner and budget threshold approved.
9. Catalog entry marked certified and publication channel enabled.
10. Quarterly recertification and event-driven review scheduled.

![Data-product lifecycle and governance gates](/mnt/data/Volume_03_Enterprise_Data_Platform_Package/diagrams/07_data_product_lifecycle.png){width=95%}

*Figure: Data-product lifecycle and governance gates*


[PAGEBREAK]


# 11. Data Products, Marketplace and Enterprise Access

A data product is a supported interface with a consumer promise. Tables may be implementation details. A product can expose one or more authorized views, linked datasets, streams, APIs or semantic models. The interface is stable, versioned, documented and observable.

## 11.1 Data Product Types

| Type | Example | Primary interface |
| --- | --- | --- |
| Source-aligned | ERP order change feed | Bronze table or event stream for approved engineering consumers. |
| Domain entity | Customer master profile | Silver table and authorized views. |
| Analytical product | Daily sales performance | Gold/curated tables and semantic model. |
| Regulatory product | Capital or compliance report dataset | Certified dataset with immutable publication evidence. |
| Operational product | Fraud feature lookup | Bigtable, Spanner or protected API. |
| AI-ready product | Grounded knowledge corpus | Curated text/chunks, embeddings metadata and access policy. |
| Reference product | Country, currency or product hierarchy | Versioned table with steward ownership. |

## 11.2 Data Marketplace

The marketplace combines discovery in Knowledge Catalog with governed publication through BigQuery sharing and approved APIs. Marketplace entries show purpose, owner, sample schema, classification, quality, SLO, cost model, access conditions and consumer responsibilities. Search does not imply access. Request workflows capture purpose and duration and route to owner, security or privacy approval based on classification.

## 11.3 BigQuery Sharing

Exchanges group products by domain or audience. Listings expose a stable dataset or stream contract. Subscribers receive linked datasets where supported, reducing unmanaged copies. Publishers remain responsible for product SLO and schema compatibility; subscribers remain responsible for approved use and downstream access. Location alignment and feature support are validated before publication.

## 11.4 Enterprise-Data Access Model

![Enterprise data access and sharing model](/mnt/data/Volume_03_Enterprise_Data_Platform_Package/diagrams/08_enterprise_access.png){width=95%}

*Figure: Enterprise data access and sharing model*

| Access path | Use | Control |
| --- | --- | --- |
| Dataset IAM | Small number of producer and operator groups | Avoid broad consumer access to base datasets. |
| Authorized view or dataset | Stable filtered or joined consumer interface | Publisher controls source access and interface. |
| Row access policy | Restrict records by region, legal entity, tenant or entitlement | Use group/attribute logic and test policy combinations. |
| Column-level security | Restrict raw sensitive columns | Policy tags and fine-grained reader roles. |
| Dynamic masking | Expose transformed values by role | Data policies, masking rules and policy tags. |
| BigQuery sharing | Cross-project or cross-organization product publication | Exchange/listing roles and subscriber governance. |
| Protected API | Operational or externally controlled access | Apigee/Cloud Run, authentication, quotas and audit. |
| Export | Only when consumer cannot use managed access | Time-bound, encrypted, contract-controlled and monitored. |


[PAGEBREAK]


# 12. Data Classification, Fine-Grained Security and Encryption

Data controls are layered. Project and perimeter boundaries reduce blast radius. Dataset IAM controls broad roles. Authorized views provide stable interfaces. Row access policies filter records. Policy tags and column-level access restrict sensitive columns. Dynamic masking transforms visible values according to role. Encryption protects storage and approved key-control requirements. Audit and periodic review prove that the design remains effective.

## 12.1 Data Classification

| Class | Examples | Minimum controls |
| --- | --- | --- |
| Public | Approved public reference data | Integrity, provenance and controlled publication. |
| Internal | Operational metadata and nonpublic reference data | Employee groups, audit and standard encryption. |
| Confidential | Customer, commercial and employee records | Need-to-know groups, private access, DLP classification and monitoring. |
| Restricted | Payment, health, government ID and sensitive HR | Dedicated projects/perimeters, policy tags, masking, CMEK where required and enhanced review. |
| Regulated | Records governed by specific retention or reporting law | All restricted controls plus evidence, hold and regulatory approval. |

## 12.2 Row-Level Security

Row policies are used when the same table serves multiple approved populations and the filter is stable, testable and performant. Entitlement logic is maintained through managed groups or reference tables rather than hard-coded individuals. Policies are version-controlled and tested for policy intersection, privileged access and service-account behavior. Highly complex consumer-specific logic may be safer in authorized views.

## 12.3 Column-Level Security and Policy Tags

Policy tags classify columns and control access to original values. The taxonomy aligns to enterprise classification and data categories such as direct identifiers, payment data, health data and secrets. Tag assignment is deployed with schema code and validated in CI. Access to unmasked values is narrowly granted to governed groups.

## 12.4 Dynamic Data Masking

Dynamic masking provides role-dependent representations such as null, default, last-four, hash or email masking. It is not anonymization and does not change the stored base value. Masking policies are selected based on consumer purpose and reidentification risk. Negative tests confirm that users without privileged roles never receive raw values through views, extracts or indirect query paths.

## 12.5 Authorized Views

Authorized views are the preferred interface when consumers need a stable subset, calculated field or cross-table join without base-table access. Views are owned by the publishing domain, tested for performance and protected from accidental replacement. Breaking changes follow product versioning and deprecation.

## 12.6 Encryption

| Layer | Default | Enhanced control |
| --- | --- | --- |
| Cloud Storage | Google-managed encryption | CMEK for restricted/regulatory buckets; key rotation and separation of duties. |
| BigQuery | Google-managed encryption | CMEK at dataset/table-supported boundary where policy requires. |
| BigLake/Iceberg | Storage encryption plus service access controls | CMEK and external-engine key/access validation. |
| Pub/Sub | Service encryption | CMEK for approved topics where supported and required. |
| Dataflow | Service encryption and encrypted disks | CMEK and no public worker IPs where required. |
| Operational databases | Managed encryption | CMEK and database-specific backup key strategy. |
| Transfer | TLS or private connectivity | Partner encryption, signed manifests and customer-controlled keys where contract requires. |


[PAGEBREAK]


# 13. Data-Platform SLOs, Monitoring and Cost Model

Platform reliability is expressed through service-level indicators that consumers can understand: freshness, availability, completeness, quality, access latency and recovery. Infrastructure metrics are necessary but not sufficient. Each certified product publishes an SLO and an error budget with a named owner.

## 13.1 SLO Catalogue

| SLI | Measurement | Tier 0 target | Tier 1 target | Tier 2 target |
| --- | --- | --- | --- | --- |
| Freshness | Current source watermark minus product watermark | 99.9% within 5 minutes | 99.5% within 30 minutes | 99% within 24 hours |
| Pipeline success | Successful scheduled windows / expected windows | 99.95% | 99.9% | 99% |
| Availability | Successful governed queries or API requests | 99.99% | 99.9% | 99.5% |
| Completeness | Accepted source records or control total | 100% for financial controls | 99.99% | 99.5% |
| Quality | Weighted mandatory rule pass rate | 99.9% | 99.5% | 98% |
| Discoverability | Mandatory metadata fields complete | 100% | 100% | 95% |
| Access fulfillment | Approved request to usable access | 4 business hours | 1 business day | 3 business days |
| Recovery | Restore/replay within RTO/RPO | <1h / <5m | <4h / <15m | <24h / <24h |

## 13.2 Monitoring Architecture

| Layer | Signals | Alert examples |
| --- | --- | --- |
| Transfer | Objects, bytes, checksum, duration and failures | Missing batch, partial inventory, repeated transfer error. |
| Streaming | Publish rate, backlog, oldest unacked, watermark and DLQ | Backlog age exceeds freshness budget; DLQ spike. |
| CDC | Source lag, stream state, schema change and merge delay | Lag exceeds threshold; log retention risk. |
| Storage | Growth, object count, lifecycle, retention and egress | Unexpected region egress; lifecycle not reducing old data. |
| BigQuery | Jobs, slots, queue, bytes, storage and failures | Queued production workload; anomalous scan cost. |
| Quality | Rule pass, failed rows, score and exceptions | Critical rule blocks publication. |
| Metadata | Coverage, stale ownership and lineage gaps | Certified product missing lineage or owner. |
| Security | Denied access, policy change and data exfiltration indicators | Unexpected raw-column access or perimeter violation. |
| Cost | Daily spend, unit cost, forecast and anomaly | Product exceeds budget or unit cost trend. |

## 13.3 Product Scorecard

| Category | Measure | Weight |
| --- | --- | --- |
| Reliability | Freshness and availability SLO | 25% |
| Quality | Mandatory and advisory rule score | 25% |
| Governance | Metadata, lineage and ownership completeness | 15% |
| Security | Access review and policy conformance | 15% |
| Consumer | Usage, satisfaction and incidents | 10% |
| FinOps | Budget and unit-cost trend | 10% |

## 13.4 Cost Model

The architecture does not embed current price values. Cost is calculated from measurable workload variables and current Google Cloud pricing. Each product has an expected monthly range, a unit metric and optimization owner.

| Cost component | Model variables | Primary controls |
| --- | --- | --- |
| Cloud Storage | GB-month by class, operations, retrieval and egress | Lifecycle, compression, locality, compaction and retention. |
| BigQuery storage | Active and long-term GB-month | Table lifecycle, duplicate copy elimination and snapshots. |
| BigQuery compute | On-demand bytes processed or capacity/slot usage | Partitioning, clustering, reservations, workload assignment and query review. |
| Streaming | Pub/Sub throughput/retention and Dataflow workers/runtime | Message size, retention, autoscaling, state and at-least-once choice. |
| CDC | Datastream processed volume plus target merge compute | Filter unused objects and tune merge cadence. |
| Governance | Metadata storage/scans and profile/quality execution | Scope scans by risk and reuse rules. |
| Network | Inter-region, internet and cross-cloud egress | Regional locality and transfer architecture. |
| Logging | Log ingestion and retention | Exclusions, sampling and tiered retention without losing audit evidence. |
| Operational stores | Node/compute, storage, backups and network | Right-size, autoscale, workload-specific retention and capacity review. |

## 13.5 Unit Economics

| Unit metric | Formula |
| --- | --- |
| Batch ingestion cost per TB | Monthly batch transfer + processing + load cost / accepted TB. |
| Streaming cost per million events | Pub/Sub + Dataflow + serving writes / accepted million events. |
| Data product cost per active consumer | Attributed storage + compute + operations / monthly active consumers. |
| BigQuery cost per successful query | Attributed query compute / successful governed queries. |
| Quality cost per billion rows | Profile and rule execution cost / billion assessed rows. |
| Archive cost per retained TB-year | Storage + inventory + restore testing / retained TB-year. |


[PAGEBREAK]


# 14. Production Deployment Model

The platform inherits organization, network, identity and security foundations from Volume 02. Shared platform projects host reusable control-plane capabilities; domain projects host data-plane assets and product workloads. Production and nonproduction are separated. Regional data planes align to residency and recovery. Infrastructure, schemas, contracts and policies are promoted through CI/CD.

![Production deployment model](/mnt/data/Volume_03_Enterprise_Data_Platform_Package/diagrams/09_production_deployment.png){width=95%}

*Figure: Production deployment model*

## 14.1 Project Model

| Project type | Example purpose | Ownership |
| --- | --- | --- |
| Data platform control | Catalog integration, shared metadata, policy automation and product registry | Central platform |
| Ingestion shared service | Reusable transfer, validation, templates and DLQ services | Central platform |
| Domain data project | BigQuery datasets, buckets, topics and product pipelines for one domain/environment/region | Domain team within platform guardrails |
| Restricted domain project | Restricted data assets inside stronger service perimeter | Domain plus security |
| Operations project | Monitoring workspaces, dashboards and alert routing | SRE/platform operations |
| KMS project | Regional keys and separation of key administrators | Security platform |
| Sharing project | Exchanges, listings and controlled publication | Marketplace/platform team |
| Sandbox project | Time-bound exploration with quotas and no restricted raw data | Managed self-service |

## 14.2 Environment Strategy

| Environment | Data | Purpose | Promotion gate |
| --- | --- | --- | --- |
| Development | Synthetic or masked samples | Code, schema and contract development | Unit, lint, policy and schema tests. |
| Integration | Representative nonproduction data | Cross-service integration and migration tests | End-to-end reconciliation and security tests. |
| Performance | Generated or approved representative scale | Peak, skew, cost and failure testing | Capacity and cost acceptance. |
| Staging | Production-like configuration and masked/sampled data | Release rehearsal and operational readiness | Change approval and runbook validation. |
| Production | Approved business data | Consumer service | Automated deployment, monitoring and rollback. |
| Sandbox | Nonrestricted, time-bound copies | Exploration | Expiry and no production dependency. |

## 14.3 Regional and Recovery Model

Each data domain has a home geography and approved primary region. Data does not cross a residency boundary solely for centralized convenience. Critical products define a recovery region and a service-specific strategy: replay from retained events, rebuild from raw objects, copy or snapshot protected BigQuery tables, and reconstruct infrastructure from Terraform. Global metadata may describe assets across regions, but search and metadata visibility remain access-controlled.

## 14.4 Deployment Sequence

1. Create domain and shared projects through the landing-zone project factory.
2. Attach Shared VPC, service perimeter, logging, monitoring, budgets and KMS according to classification.
3. Deploy buckets, datasets, topics, service accounts and base IAM through approved modules.
4. Deploy contract, schema, policy tags, row policies and masking policies.
5. Deploy ingestion and transformation artifacts with immutable version identifiers.
6. Run automated schema, security, quality, reconciliation and performance tests.
7. Execute production-readiness review and approve SLO, runbook, cost owner and recovery plan.
8. Promote release, validate telemetry and record deployment evidence.
9. Publish or update the data product in Knowledge Catalog and BigQuery sharing.
10. Monitor error budget and rollback or disable publication on critical failure.

## 14.5 Production Acceptance Checklist

| Control domain | Acceptance evidence |
| --- | --- |
| Ownership | Business owner, product owner, steward and technical owner approved. |
| Architecture | Approved service selection and ADR references. |
| Security | Classification, IAM, perimeter, masking, encryption and threat test passed. |
| Data | Contract, schema evolution, reconciliation and quality rules passed. |
| Operations | SLO, dashboards, alerts, runbook, on-call and support path active. |
| Recovery | Replay, restore or rebuild demonstrated against target RTO/RPO. |
| FinOps | Budget, labels, forecast and unit-cost baseline recorded. |
| Governance | Catalog, glossary, lineage, retention and certification complete. |
| Change | CI/CD, rollback and consumer notification tested. |


[PAGEBREAK]


# 15. Architecture Decision Records

The following decisions form the enterprise baseline. Each implementation references the applicable ADRs and records any exception, compensating control and review date.

## ADR-DP-001: BigQuery is the primary analytical warehouse

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** The enterprise needs petabyte analytical scale, fine-grained governance and managed operations.  

**Alternatives considered.** BigQuery native tables; Iceberg-only lakehouse; third-party warehouse.  

**Decision.** Use BigQuery native tables for the majority of silver, gold, curated and semantic-serving data.  

**Rationale and benefits.** Native management and security reduce operating complexity. Iceberg is retained for real interoperability needs.  

**Trade-offs and risks.** Cost can grow with poor query design; regional boundaries and quotas apply.  

**Mitigations.** Partition/cluster standards, workload isolation, budgets and service-limit validation.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-002: Cloud Storage is the immutable raw and archive foundation

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Source evidence and open objects must be retained independently of compute.  

**Alternatives considered.** Cloud Storage; BigQuery-only; self-managed object store.  

**Decision.** Use Cloud Storage for landing, quarantine, raw, replay and archive.  

**Rationale and benefits.** Durable object semantics, open formats and lifecycle controls.  

**Trade-offs and risks.** Object management and small-file overhead require discipline.  

**Mitigations.** Compaction, manifest, inventory, lifecycle and access standards.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-003: Iceberg is selective, not universal

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Multiple engines sometimes need one authoritative open table.  

**Alternatives considered.** BigQuery native; Apache Iceberg; duplicate copies per engine.  

**Decision.** Use Apache Iceberg managed/external tables only when multi-engine or customer-owned storage is required.  

**Rationale and benefits.** Preserves interoperability without imposing lakehouse complexity everywhere.  

**Trade-offs and risks.** Writer compatibility and metadata operations add risk.  

**Mitigations.** Approved writers, one catalog authority, compaction and compatibility testing.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-004: Layer names have explicit contracts

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Raw, bronze, silver, gold and curated are often used inconsistently.  

**Alternatives considered.** Team-defined layers; enterprise definitions; no layers.  

**Decision.** Adopt the layer definitions in this volume.  

**Rationale and benefits.** Reduces duplicate zones and clarifies ownership and exit criteria.  

**Trade-offs and risks.** Migration from existing terminology requires mapping.  

**Mitigations.** Maintain a crosswalk and certify by controls, not folder name.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-005: Batch is the default latency pattern

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Streaming adds state, replay and cost complexity.  

**Alternatives considered.** Batch by default; streaming by default; case-by-case with no standard.  

**Decision.** Use the slowest pattern that meets the business decision latency.  

**Rationale and benefits.** Improves reliability and unit economics.  

**Trade-offs and risks.** Some teams may understate latency need.  

**Mitigations.** Business owner signs latency class and reviews consumer outcomes.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-006: Pub/Sub is the cloud-native event backbone

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Cloud consumers need decoupled event delivery.  

**Alternatives considered.** Pub/Sub; managed Kafka; direct producer-to-consumer calls.  

**Decision.** Use Pub/Sub for new Google Cloud-native events; bridge existing Kafka where needed.  

**Rationale and benefits.** Managed scale and independent subscriptions.  

**Trade-offs and risks.** At-least-once delivery requires idempotent consumers.  

**Mitigations.** Stable event IDs, schemas, DLQ and replay archive.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-007: Dataflow handles complex event processing

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Stateful streaming and large parallel batch require a managed engine.  

**Alternatives considered.** Dataflow; Spark; custom services.  

**Decision.** Use Dataflow when Beam semantics, windows, state or scale are required.  

**Rationale and benefits.** Managed autoscaling and common model.  

**Trade-offs and risks.** Engineering complexity for simple jobs.  

**Mitigations.** Use SQL or Cloud Run for simpler transformations.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-008: Datastream is preferred for supported CDC

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Custom CDC platforms create connector and recovery burden.  

**Alternatives considered.** Datastream; Debezium/Kafka; batch extracts; third-party CDC.  

**Decision.** Use Datastream where source, target and required behavior are supported.  

**Rationale and benefits.** Reduces platform operations.  

**Trade-offs and risks.** Coverage and schema behavior require validation.  

**Mitigations.** Pilot, reconcile and retain an approved fallback.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-009: Domain projects own production data products

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** One central project creates access, quota and cost blast radius.  

**Alternatives considered.** Central project; project per table; domain/environment projects.  

**Decision.** Use domain, environment, geography and sensitivity as project boundaries.  

**Rationale and benefits.** Balances autonomy, governance and attribution.  

**Trade-offs and risks.** More projects require automation.  

**Mitigations.** Project factory and standard modules.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-010: Knowledge Catalog is the enterprise governance surface

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Metadata is fragmented across tools and teams.  

**Alternatives considered.** Native catalog; third-party catalog; spreadsheets.  

**Decision.** Use Knowledge Catalog as the Google Cloud governance surface and integrate external enterprise metadata where required.  

**Rationale and benefits.** Native inventory, lineage, glossary, profiling and quality integration.  

**Trade-offs and risks.** Coverage and product evolution must be managed.  

**Mitigations.** Completeness SLO, integration architecture and quarterly feature review.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-011: Automatic data quality is the default managed quality service

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Quality must be repeatable and visible.  

**Alternatives considered.** Knowledge Catalog automatic quality; custom SQL only; legacy tasks; third-party.  

**Decision.** Use automatic data quality and reusable rules, with custom SQL where needed.  

**Rationale and benefits.** Managed execution and score integration.  

**Trade-offs and risks.** Complex business rules may need custom processing.  

**Mitigations.** Separate transport, domain and product quality layers.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-012: Contracts are stored and validated as code

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Schema and semantic changes cause consumer incidents.  

**Alternatives considered.** Wiki documents; schema only; versioned contracts.  

**Decision.** Use version-controlled contracts with CI and runtime validation.  

**Rationale and benefits.** Creates enforceable producer-consumer expectations.  

**Trade-offs and risks.** Requires governance and migration discipline.  

**Mitigations.** Templates, compatibility tests and deprecation policy.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-013: Authorized interfaces replace broad base-table access

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Direct table grants expose implementation detail and sensitive data.  

**Alternatives considered.** Base dataset access; views; extracts.  

**Decision.** Publish authorized views/datasets, row policies, masked columns or APIs.  

**Rationale and benefits.** Supports least privilege and stable contracts.  

**Trade-offs and risks.** View complexity can affect performance.  

**Mitigations.** Performance tests, materialization and interface versioning.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-014: BigQuery sharing is the default governed marketplace mechanism

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Consumers need cross-project and cross-organization access without unmanaged copies.  

**Alternatives considered.** Direct IAM; exports; BigQuery sharing; API.  

**Decision.** Use exchanges and listings for supported analytical datasets and streams.  

**Rationale and benefits.** Linked access and publisher control.  

**Trade-offs and risks.** Location and feature constraints apply.  

**Mitigations.** Validate consumer, location, contract and subscriber governance.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-015: CMEK is risk-based

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Universal CMEK increases key dependencies without equal value.  

**Alternatives considered.** Google-managed keys; universal CMEK; selective CMEK.  

**Decision.** Use CMEK for restricted/regulatory workloads or explicit customer control requirements.  

**Rationale and benefits.** Aligns key-control burden to risk.  

**Trade-offs and risks.** Classification errors could omit required CMEK.  

**Mitigations.** Policy automation, inventory and security review.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-016: Bigtable is conditional operational serving

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Some products need high-throughput low-latency key access.  

**Alternatives considered.** Bigtable; BigQuery; Spanner; cache.  

**Decision.** Use Bigtable only for access-pattern-driven wide-column/key-value workloads.  

**Rationale and benefits.** Scales serving independently of analytical compute.  

**Trade-offs and risks.** Schema mistakes create hotspots and weak query flexibility.  

**Mitigations.** Row-key review, load test and app-profile monitoring.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-017: Spanner is conditional for globally consistent transactions

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Global applications may need relational consistency and scale.  

**Alternatives considered.** Spanner; regional PostgreSQL; sharded databases.  

**Decision.** Use Spanner when consistency, availability and scale justify its model.  

**Rationale and benefits.** Mission-critical relational capability at scale.  

**Trade-offs and risks.** Higher design and cost complexity.  

**Mitigations.** Workload proof, schema review and configuration testing.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-018: AlloyDB is the preferred demanding PostgreSQL-compatible option

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Some operational products require PostgreSQL compatibility.  

**Alternatives considered.** AlloyDB; Cloud SQL; Spanner PostgreSQL dialect.  

**Decision.** Use AlloyDB for demanding regional PostgreSQL-compatible workloads.  

**Rationale and benefits.** Application compatibility and managed HA.  

**Trade-offs and risks.** Not globally distributed like Spanner.  

**Mitigations.** Connection, backup, read-pool and DR design.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-019: Retention and deletion are metadata-driven

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** Manual lifecycle settings lead to noncompliance and excess cost.  

**Alternatives considered.** Manual rules; platform defaults only; policy-driven lifecycle.  

**Decision.** Map record schedules and privacy obligations to deployable lifecycle controls.  

**Rationale and benefits.** Consistent evidence and automated disposition.  

**Trade-offs and risks.** Incorrect mapping can cause premature deletion.  

**Mitigations.** Legal approval, dry run, hold controls and deletion certificates.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.

## ADR-DP-020: Products are certified through measurable gates

**Status:** Approved reference baseline  
**Architecture domain:** Enterprise data platform  

**Problem.** A catalog label alone does not establish trust.  

**Alternatives considered.** Informal publication; documentation review; automated certification gates.  

**Decision.** Require contract, lineage, quality, security, SLO, recovery and cost evidence.  

**Rationale and benefits.** Creates reliable enterprise interfaces.  

**Trade-offs and risks.** Initial delivery takes longer.  

**Mitigations.** Tiered certification and reusable automated evidence.  

**Implementation implications.** Reference modules, contracts, monitoring and validation must implement this decision.  

**Review triggers.** Material service change, regulatory change, repeated SLO breach, cost anomaly or approved exception pattern.  

**Review date.** Quarterly architecture review.


[PAGEBREAK]


# Appendix A. Source-to-Target Mapping

The following representative mapping demonstrates the level of design detail required before implementation. Actual mappings are generated from the source registry and contract repository.

## A.1 Oracle CRM CUSTOMER

**Pattern.** CDC  
**Ingestion.** Datastream  
**Raw target.** `customer/raw/crm`  
**Bronze target.** `customer_bronze.customer_change`  
**Product target.** `customer_silver.customer`  
**Business key.** `customer_id`  
**Classification.** Restricted  
**Freshness objective.** <5 min

## A.2 SAP S/4 SALES_ORDER

**Pattern.** Batch delta  
**Ingestion.** Managed connector/file  
**Raw target.** `sales/raw/sap`  
**Bronze target.** `sales_bronze.sales_order`  
**Product target.** `sales_gold.daily_sales`  
**Business key.** `sales_order_id`  
**Classification.** Confidential  
**Freshness objective.** Hourly

## A.3 Salesforce Account

**Pattern.** SaaS transfer  
**Ingestion.** BQ Data Transfer or connector  
**Raw target.** `sales/raw/salesforce`  
**Bronze target.** `sales_bronze.account`  
**Product target.** `customer_silver.organization`  
**Business key.** `account_id`  
**Classification.** Confidential  
**Freshness objective.** Hourly

## A.4 Kafka clickstream

**Pattern.** Streaming  
**Ingestion.** Pub/Sub/Dataflow  
**Raw target.** `digital/replay/clickstream`  
**Bronze target.** `digital_bronze.click_event`  
**Product target.** `digital_gold.session_metrics`  
**Business key.** `event_id`  
**Classification.** Internal  
**Freshness objective.** <2 min

## A.5 IoT telemetry

**Pattern.** Streaming  
**Ingestion.** Pub/Sub/Dataflow  
**Raw target.** `operations/replay/iot`  
**Bronze target.** `operations_bronze.telemetry`  
**Product target.** `operations_gold.asset_health`  
**Business key.** `device_id,event_ts`  
**Classification.** Confidential  
**Freshness objective.** <1 min


[PAGEBREAK]


## A.6 Mainframe policy file

**Pattern.** Batch file  
**Ingestion.** MFT/Cloud Storage/Dataflow  
**Raw target.** `policy/raw/mainframe`  
**Bronze target.** `policy_bronze.policy`  
**Product target.** `policy_silver.policy`  
**Business key.** `policy_number`  
**Classification.** Restricted  
**Freshness objective.** Daily

## A.7 Workday worker

**Pattern.** SaaS API  
**Ingestion.** Cloud Run/Workflows  
**Raw target.** `hr/raw/workday`  
**Bronze target.** `hr_bronze.worker`  
**Product target.** `hr_curated.workforce_summary`  
**Business key.** `worker_id`  
**Classification.** Restricted  
**Freshness objective.** Daily

## A.8 Partner price file

**Pattern.** Partner file  
**Ingestion.** Cloud Storage validation  
**Raw target.** `supply/raw/partner`  
**Bronze target.** `supply_bronze.partner_price`  
**Product target.** `supply_silver.supplier_price`  
**Business key.** `partner_id,sku`  
**Classification.** Confidential  
**Freshness objective.** Daily

## A.9 AWS S3 web logs

**Pattern.** Cross-cloud transfer  
**Ingestion.** Storage Transfer Service  
**Raw target.** `digital/raw/aws`  
**Bronze target.** `digital_bronze.web_log`  
**Product target.** `digital_gold.traffic`  
**Business key.** `request_id`  
**Classification.** Internal  
**Freshness objective.** Hourly

## A.10 Payment events

**Pattern.** Streaming  
**Ingestion.** Pub/Sub/Dataflow  
**Raw target.** `finance/replay/payment`  
**Bronze target.** `finance_bronze.payment_event`  
**Product target.** `finance_curated.payment_control`  
**Business key.** `payment_id`  
**Classification.** Regulated  
**Freshness objective.** <30 sec


[PAGEBREAK]


## A.11 Product reference API

**Pattern.** API  
**Ingestion.** Cloud Run  
**Raw target.** `product/raw/reference`  
**Bronze target.** `product_bronze.product`  
**Product target.** `product_silver.product_master`  
**Business key.** `product_id`  
**Classification.** Internal  
**Freshness objective.** Hourly

## A.12 Document repository

**Pattern.** File/object  
**Ingestion.** Transfer + metadata extraction  
**Raw target.** `knowledge/raw/documents`  
**Bronze target.** `knowledge_bronze.document`  
**Product target.** `knowledge_curated.approved_corpus`  
**Business key.** `document_id,version`  
**Classification.** Restricted  
**Freshness objective.** Daily

# Appendix B. Data-Layer Standards Matrix

## B.1 Landing

**Required metadata.** source, batch, object generation, checksum  
**Required tests.** completion, checksum, malware, manifest  
**Allowed consumers.** ingestion service  
**Default lifecycle.** delete after accepted or quarantined

## B.2 Quarantine

**Required metadata.** error, rule, owner, correlation, remediation  
**Required tests.** none before isolation  
**Allowed consumers.** operations and steward  
**Default lifecycle.** delete after resolution and evidence period

## B.3 Raw

**Required metadata.** source, contract, schema, provenance, retention  
**Required tests.** integrity and source reconciliation  
**Allowed consumers.** restricted engineering/audit  
**Default lifecycle.** retain per replay/legal requirement

## B.4 Bronze

**Required metadata.** operation, source time, ingestion time, batch/offset  
**Required tests.** type, key, duplicate, basic validity  
**Allowed consumers.** domain engineering  
**Default lifecycle.** retain for operational rebuild

## B.5 Silver

**Required metadata.** domain entity, owner, history, references  
**Required tests.** conformance, quality, referential integrity  
**Allowed consumers.** approved domain consumers  
**Default lifecycle.** domain retention


[PAGEBREAK]


## B.6 Gold

**Required metadata.** product, consumer, SLO, cost  
**Required tests.** business rules, performance, freshness  
**Allowed consumers.** named consumers  
**Default lifecycle.** product retention

## B.7 Curated

**Required metadata.** enterprise definition, certification, lineage  
**Required tests.** strict quality, security and reconciliation  
**Allowed consumers.** broad approved enterprise users  
**Default lifecycle.** enterprise/regulatory schedule

## B.8 Semantic

**Required metadata.** metric owner, formula, version  
**Required tests.** metric test and reconciliation  
**Allowed consumers.** BI and application consumers  
**Default lifecycle.** version history

## B.9 Sandbox

**Required metadata.** user, purpose, expiry, source reference  
**Required tests.** sensitivity and expiry check  
**Allowed consumers.** sandbox group  
**Default lifecycle.** automatic expiry

## B.10 Archive

**Required metadata.** schedule, checksum, schema, restore owner  
**Required tests.** inventory and restore test  
**Allowed consumers.** privileged restore  
**Default lifecycle.** record schedule


[PAGEBREAK]


# Appendix C. BigQuery Design Standards

## C.1 Project/dataset boundary

**Standard.** Separate by domain, environment, geography and materially different classification.  

**Anti-pattern.** Avoid one enterprise dataset or dataset per table.

## C.2 Naming

**Standard.** Use lower_snake_case for datasets/tables and stable business names.  

**Anti-pattern.** Avoid vendor abbreviations in curated products.

## C.3 Location

**Standard.** Set dataset location from residency and recovery architecture.  

**Anti-pattern.** Do not mix locations in a product dependency without explicit design.

## C.4 Partitioning

**Standard.** Use dominant business date/time predicate; require filters where appropriate.  

**Anti-pattern.** Avoid date-sharded tables.

## C.5 Clustering

**Standard.** Use proven selective filters/joins; most valuable column first.  

**Anti-pattern.** Do not add four columns by default.

## C.6 Table grain

**Standard.** Document one row meaning, keys and duplicate behavior.  

**Anti-pattern.** No table without an explicit grain.

## C.7 Nested fields

**Standard.** Use for bounded one-to-many structures queried together.  

**Anti-pattern.** Avoid deeply nested structures that hide business entities.

## C.8 Views

**Standard.** Use authorized views for stable consumer interfaces.  

**Anti-pattern.** Do not expose base-table implementation as the product.

## C.9 Materialized results

**Standard.** Use where repeated expensive logic and freshness allow.  

**Anti-pattern.** Do not precompute without usage evidence.

## C.10 Row security

**Standard.** Use stable entitlement dimensions and negative tests.  

**Anti-pattern.** Avoid individual email logic.

## C.11 Column security

**Standard.** Apply policy tags and least-privilege fine-grained roles.  

**Anti-pattern.** Do not rely on naming conventions for sensitivity.

## C.12 Masking

**Standard.** Use policy-driven dynamic masking for approved reduced views.  

**Anti-pattern.** Masking is not anonymization.

## C.13 Reservations

**Standard.** Separate critical BI/ELT/data science based on observed workload.  

**Anti-pattern.** Do not purchase capacity before measuring.

## C.14 Query standards

**Standard.** Explicit columns, partition filters, bounded joins and dry-run checks.  

**Anti-pattern.** No production SELECT * in recurring jobs.

## C.15 Schema deployment

**Standard.** DDL and policy changes are version-controlled and promoted through CI/CD.  

**Anti-pattern.** No direct console-only production schema changes.

## C.16 Recovery

**Standard.** Use time travel, snapshots, source/raw rebuild and tested runbooks according to tier.  

**Anti-pattern.** Do not assume time travel alone meets all backup requirements.


[PAGEBREAK]


# Appendix D. Sample Dataset and Table Definitions

The package includes executable SQL files. The examples below illustrate the enterprise patterns and must be adapted for project IDs, regions, identities, policy-taxonomy IDs and retention schedules.

## D.1 Dataset Definition

```sql
CREATE SCHEMA IF NOT EXISTS `acme-customer-prd.customer_silver`
OPTIONS (
  location = 'us-central1',
  description = 'Standardized customer domain entities',
  default_table_expiration_days = NULL,
  labels = [('domain','customer'),('environment','prd'),('classification','confidential')]
);
```

## D.2 Partitioned and Clustered Table

```sql
CREATE TABLE IF NOT EXISTS `acme-customer-prd.customer_silver.customer_event` (
  event_id STRING NOT NULL,
  customer_id STRING NOT NULL,
  event_ts TIMESTAMP NOT NULL,
  event_date DATE NOT NULL,
  event_type STRING NOT NULL,
  region_code STRING,
  payload JSON,
  source_system STRING NOT NULL,
  schema_version STRING NOT NULL,
  ingestion_ts TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
PARTITION BY event_date
CLUSTER BY customer_id, event_type, region_code
OPTIONS (
  description = 'Standardized customer events; one row per source event',
  require_partition_filter = TRUE,
  labels = [('domain','customer'),('layer','silver'),('data_product','customer_events')]
);
```

## D.3 Authorized View

```sql
CREATE OR REPLACE VIEW `acme-customer-prd.customer_access.customer_summary_v1` AS
SELECT
  customer_id,
  region_code,
  COUNTIF(event_type = 'PURCHASE') AS purchase_count_90d,
  MAX(event_ts) AS last_activity_ts
FROM `acme-customer-prd.customer_silver.customer_event`
WHERE event_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 90 DAY)
GROUP BY customer_id, region_code;
```

## D.4 Row Access Policy

```sql
CREATE OR REPLACE ROW ACCESS POLICY region_entitlement
ON `acme-customer-prd.customer_curated.customer_360`
GRANT TO ('group:customer-emea-readers@example.com')
FILTER USING (region_code = 'EMEA');
```

## D.5 Snapshot Before High-Risk Change

```sql
CREATE SNAPSHOT TABLE `acme-customer-prd.customer_backup.customer_360_20260711`
CLONE `acme-customer-prd.customer_curated.customer_360`
OPTIONS (expiration_timestamp = TIMESTAMP_ADD(CURRENT_TIMESTAMP(), INTERVAL 30 DAY));
```


[PAGEBREAK]


# Appendix E. Validation Checklists

## E.1 Source Onboarding

- [ ] Business and technical owners are named.
- [ ] Source authority and consumer use case are approved.
- [ ] Sensitivity, residency, legal basis and retention are recorded.
- [ ] Latency is justified by a business outcome.
- [ ] Volume, change rate and peak behavior are measured.
- [ ] Contract and compatibility mode are version-controlled.
- [ ] Reconciliation and replay are demonstrated.
- [ ] Source credentials and network path pass security review.
- [ ] Monitoring, runbook, SLO and support owner are active.
- [ ] Monthly cost range and unit metric are approved.

## E.2 Data Product Certification

- [ ] Product owner, steward and consumer are named.
- [ ] Grain, keys, semantics and source authority are documented.
- [ ] Contract, lineage and glossary relationships are complete.
- [ ] Mandatory quality rules pass.
- [ ] Classification, access, masking and encryption controls pass negative tests.
- [ ] Freshness, availability and recovery meet the product tier.
- [ ] Cost allocation and budget are active.
- [ ] Versioning, deprecation and consumer notification are defined.
- [ ] Marketplace or API publication is approved.
- [ ] Quarterly recertification is scheduled.

## E.3 Production Readiness

- [ ] Infrastructure and schema deployed from source control.
- [ ] Regional service availability, quotas and limits validated.
- [ ] Failure, duplicate, late, malformed and replay tests passed.
- [ ] Dashboards and alerts route to the correct on-call group.
- [ ] Runbook includes stop, replay, backfill, rollback and escalation.
- [ ] Recovery exercise meets RTO/RPO.
- [ ] Security findings have no unresolved critical/high issues.
- [ ] Data-product scorecard is visible.
- [ ] Consumer acceptance and support handoff are recorded.
- [ ] Post-deployment validation and rollback criteria are automated.


[PAGEBREAK]


# Appendix F. Official Google Cloud Reference Sources

The architecture was aligned to the following official Google Cloud documentation current at publication. Implementation teams must revalidate product status, region support, quotas and limitations at design approval and before production rollout.

- **Knowledge Catalog overview:** `docs.cloud.google.com/dataplex/docs/introduction`
- **Knowledge Catalog metadata management:** `docs.cloud.google.com/dataplex/docs/catalog-overview`
- **Knowledge Catalog data lineage:** `docs.cloud.google.com/dataplex/docs/about-data-lineage`
- **Knowledge Catalog automatic data quality:** `docs.cloud.google.com/dataplex/docs/auto-data-quality-overview`
- **Knowledge Catalog data profiling:** `docs.cloud.google.com/dataplex/docs/data-profiling-overview`
- **BigQuery overview:** `docs.cloud.google.com/bigquery/docs/introduction`
- **BigQuery partitioned tables:** `docs.cloud.google.com/bigquery/docs/partitioned-tables`
- **BigQuery clustered tables:** `docs.cloud.google.com/bigquery/docs/clustered-tables`
- **BigQuery Storage Write API:** `docs.cloud.google.com/bigquery/docs/write-api`
- **BigQuery row-level security:** `docs.cloud.google.com/bigquery/docs/row-level-security-intro`
- **BigQuery column-level security:** `docs.cloud.google.com/bigquery/docs/column-level-security-intro`
- **BigQuery dynamic data masking:** `docs.cloud.google.com/bigquery/docs/column-data-masking-intro`
- **BigQuery authorized views:** `docs.cloud.google.com/bigquery/docs/authorized-views`
- **BigQuery sharing:** `docs.cloud.google.com/bigquery/docs/analytics-hub-introduction`
- **BigLake external tables:** `docs.cloud.google.com/bigquery/docs/biglake-intro`
- **Apache Iceberg managed tables:** `docs.cloud.google.com/bigquery/docs/biglake-iceberg-tables-in-bigquery`
- **Lakehouse for Apache Iceberg:** `docs.cloud.google.com/lakehouse/docs/introduction`
- **Bigtable overview:** `docs.cloud.google.com/bigtable/docs/overview`
- **Bigtable schema design:** `docs.cloud.google.com/bigtable/docs/schema-design`
- **Spanner documentation:** `docs.cloud.google.com/spanner/docs`
- **AlloyDB overview:** `docs.cloud.google.com/alloydb/docs/overview`
- **Cloud Storage object holds:** `docs.cloud.google.com/storage/docs/object-holds`
- **Cloud Storage Bucket Lock:** `docs.cloud.google.com/storage/docs/bucket-lock`
- **Cloud Storage classes:** `docs.cloud.google.com/storage/docs/storage-classes`


[PAGEBREAK]


# Appendix G. Core Google Cloud Service Reference Cards

These reference cards summarize the production role of the principal services used by this volume. They are architecture selection aids, not replacements for service-specific design reviews. Implementation teams must validate current quotas, regional support, preview or general-availability status, VPC Service Controls compatibility, CMEK support and pricing before production approval.

## G.1 Cloud Storage

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Durable object storage for landing, quarantine, immutable raw, replay and archive data. |
| Architecture role | Provides the evidence layer independent of transformation engines and supports open formats such as Parquet and Avro. |
| Benefits | Very high durability, lifecycle controls, object versioning, retention policies, event integration and broad ecosystem support. |
| Limitations | Object storage is not a transactional table engine; small-file proliferation, listing behavior and cross-region transfer require design. |
| Security | Use uniform bucket-level access, public-access prevention, least-privilege service accounts, VPC Service Controls where supported and CMEK for risk-qualified data. |
| Monitoring | Monitor request errors, latency, object growth, lifecycle transitions, retention exceptions and unexpected egress. |
| Cost optimization | Choose region and class from access and residency; compact small files; expire transient landing objects; prevent unnecessary replication. |
| Alternatives | BigQuery native storage for analytical tables; external object stores for portability; on-premises object storage for retained legacy workloads. |
| Common pitfalls | Treating folders as security boundaries, sharing object-admin roles, storing millions of tiny files and omitting restore tests. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.2 BigQuery

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Primary enterprise analytical warehouse and serving layer for standardized, gold, curated and semantic data products. |
| Architecture role | Separates managed storage and compute, supports SQL analytics, governance, sharing and integration with BI and AI. |
| Benefits | Serverless operation, elastic analytical scale, fine-grained security, reservations, native data sharing and integration with Google Cloud data services. |
| Limitations | Poor partition and query design can create cost and performance problems; location, quota and concurrency constraints require workload planning. |
| Security | Use dataset boundaries, IAM groups, policy tags, row policies, dynamic masking, authorized interfaces, audit logs and CMEK where required. |
| Monitoring | Monitor bytes processed, slot use, queue time, query failures, freshness, storage growth, policy changes and cost by product. |
| Cost optimization | Partition and cluster from observed predicates; materialize repeated expensive logic; separate workloads; enforce budgets and query controls. |
| Alternatives | Apache Iceberg for multi-engine tables; Bigtable, Spanner or AlloyDB for operational serving; third-party warehouses where mandated. |
| Common pitfalls | One global dataset, date-sharded tables, recurring SELECT *, direct base-table grants and purchasing reservations without workload evidence. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.3 BigLake

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Governed access layer for data in object storage and lakehouse patterns. |
| Architecture role | Extends BigQuery governance to external data while reducing direct bucket access for consumers. |
| Benefits | Centralized access control, interoperability with open data and separation of storage ownership from consumer permissions. |
| Limitations | Performance and feature behavior differ from native tables; metadata, file layout and supported feature combinations must be tested. |
| Security | Grant access through BigLake connections and governed tables rather than raw bucket permissions; isolate connection identities. |
| Monitoring | Monitor query latency, bytes scanned, file counts, metadata failures, connection errors and underlying object access. |
| Cost optimization | Use columnar files, compaction, partition pruning and caching where available; prefer native BigQuery when interoperability is not required. |
| Alternatives | BigQuery native tables; direct external tables; Apache Iceberg managed tables. |
| Common pitfalls | Using BigLake for every dataset, permitting consumers to bypass governed tables and ignoring object-layout optimization. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.4 Apache Iceberg Managed Tables

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Open table format for workloads that require multi-engine interoperability or customer-controlled object storage. |
| Architecture role | Provides table metadata, snapshots and open-format access while integrating with BigQuery lakehouse capabilities. |
| Benefits | Open ecosystem, schema evolution, partition evolution and reduced dependence on a single execution engine. |
| Limitations | Writer compatibility, catalog authority, compaction, snapshot retention and feature support add operational complexity. |
| Security | Restrict approved writers, protect catalog and storage identities, enforce data classification and review cross-engine access paths. |
| Monitoring | Monitor commit failures, metadata growth, snapshot count, small files, orphan files, compaction and engine compatibility. |
| Cost optimization | Use only for justified interoperability; establish one catalog authority; compact files; expire snapshots according to recovery needs. |
| Alternatives | BigQuery native tables for managed analytics; unmanaged Iceberg on external engines; duplicate domain-specific copies. |
| Common pitfalls | Multiple uncontrolled writers, long-lived orphan snapshots, untested engine versions and adopting Iceberg solely as a trend. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.5 Pub/Sub

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Managed event backbone for streaming ingestion, fan-out and decoupled producer-consumer integration. |
| Architecture role | Carries versioned business and technical events to independent ingestion, processing, replay and monitoring consumers. |
| Benefits | Elastic managed messaging, independent subscriptions, retention, dead-letter handling and integration with Dataflow and BigQuery. |
| Limitations | Delivery is at least once; ordering and exactly-once subscription features have scope and design implications; payload size and quotas apply. |
| Security | Use dedicated publisher/subscriber identities, schema controls, topic-level IAM, service perimeters where applicable and encryption controls. |
| Monitoring | Monitor oldest unacked age, backlog, delivery attempts, publish errors, throughput, DLQ volume and subscription health. |
| Cost optimization | Right-size retention, filter subscriptions, avoid unnecessary fan-out and compress or externalize oversized payloads. |
| Alternatives | Managed Kafka for Kafka-native requirements; direct API calls for synchronous interaction; batch files for non-event workloads. |
| Common pitfalls | Assuming exactly-once business processing without idempotency, shared subscriptions, unbounded retention and no replay ownership. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.6 Dataflow

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Managed Apache Beam execution for complex batch and streaming processing. |
| Architecture role | Implements stateful processing, windowing, enrichment, deduplication, validation and scalable file transformation. |
| Benefits | Unified programming model, autoscaling, managed worker lifecycle, templates and broad connector ecosystem. |
| Limitations | Pipeline engineering and state semantics are more complex than SQL; worker networking, quotas and hot keys require design. |
| Security | Use private workers, least-privilege service accounts, encrypted staging and temporary locations, restricted images and approved dependencies. |
| Monitoring | Monitor system lag, data freshness, throughput, worker CPU and memory, autoscaling, failed bundles, hot keys and DLQ rates. |
| Cost optimization | Use autoscaling, efficient coders, right-size workers, avoid unnecessary shuffles and select streaming only when justified. |
| Alternatives | BigQuery SQL or Dataform for SQL transformations; Serverless Spark for Spark workloads; Cloud Run for simple stateless processing. |
| Common pitfalls | Embedding business rules without contracts, ignoring event time, non-idempotent sinks, hard-coded secrets and no replay testing. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.7 Datastream

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Serverless change-data-capture service for supported operational databases and targets. |
| Architecture role | Captures inserts, updates and deletes with source metadata for low-latency ingestion into approved landing or analytical patterns. |
| Benefits | Reduces connector operations, supports continuous replication and integrates with Google Cloud data services. |
| Limitations | Source and target coverage, DDL behavior, backfill, network connectivity and schema evolution must be validated per workload. |
| Security | Use private connectivity where supported, dedicated database accounts, least-privilege destination identities and encrypted secrets. |
| Monitoring | Monitor stream state, lag, errors, rejected records, source log retention, backfill progress and reconciliation variance. |
| Cost optimization | Filter unnecessary objects and columns, tune backfill windows and avoid replicating data without consumer demand. |
| Alternatives | Debezium and Kafka for custom or unsupported CDC; third-party CDC; scheduled incremental extracts. |
| Common pitfalls | Treating CDC as source truth without reconciliation, allowing source logs to expire, ignoring deletes and deploying without schema-change tests. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.8 Storage Transfer Service

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Managed bulk and recurring transfer of objects from on-premises, Google Cloud and supported cross-cloud sources. |
| Architecture role | Moves historical and scheduled object data into controlled landing or raw zones with transfer evidence. |
| Benefits | Managed scheduling, incremental transfer, checksums, agent-based options and cross-cloud support. |
| Limitations | Network bandwidth, source API limits, object metadata differences and egress charges can dominate design. |
| Security | Use dedicated agents and identities, least privilege, private connectivity where available, encrypted transport and transfer logs. |
| Monitoring | Monitor transfer errors, skipped objects, checksum mismatch, throughput, backlog, source throttling and egress. |
| Cost optimization | Pre-size bandwidth, avoid duplicate copies, schedule around source limits and apply lifecycle after reconciliation. |
| Alternatives | Transfer Appliance for very large offline transfer; custom copy tools; partner integration services. |
| Common pitfalls | Migrating without inventory, no restart or reconciliation plan, underestimating egress and treating transfer completion as data validation. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.9 Cloud Run

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Serverless container platform for API ingestion, lightweight connectors, validation services and data-product APIs. |
| Architecture role | Provides stateless integration endpoints where managed connectors or data-processing engines are not the right fit. |
| Benefits | Rapid deployment, autoscaling, container portability, identity integration and request or event-driven execution. |
| Limitations | Request duration, concurrency, startup, outbound connectivity and state management require design; not a replacement for long-running data engines. |
| Security | Require authenticated invocation, dedicated service accounts, Secret Manager, controlled egress and private ingress where appropriate. |
| Monitoring | Monitor latency, error rate, instance count, concurrency, cold starts, outbound failures and dependency SLOs. |
| Cost optimization | Set concurrency and minimum instances from latency need; avoid polling; scale to zero for intermittent workloads. |
| Alternatives | Cloud Functions for small event handlers; Workflows for orchestration; GKE for specialized runtime or control needs. |
| Common pitfalls | Embedding credentials, storing state locally, unbounded retries, public endpoints by default and using Cloud Run for massive data shuffles. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.10 Knowledge Catalog

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Enterprise metadata, discovery and governance surface for Google Cloud data assets. |
| Architecture role | Publishes technical and business metadata, glossary terms, lineage, profiling, quality results, ownership and product certification. |
| Benefits | Native asset inventory, search, governance metadata and integration with BigQuery and Cloud Storage. |
| Limitations | Coverage varies by asset and lineage source; metadata quality still depends on ownership and operating process. |
| Security | Restrict metadata administration, protect sensitive descriptions, separate catalog roles and audit governance changes. |
| Monitoring | Monitor metadata completeness, stale ownership, lineage coverage, failed scans, quality execution and certification age. |
| Cost optimization | Automate metadata from contracts and deployments; avoid manual-only cataloging; tier scans by product criticality. |
| Alternatives | Third-party enterprise catalog integrated with Google Cloud; custom metadata repository; spreadsheets only for temporary discovery. |
| Common pitfalls | Cataloging everything without ownership, exposing sensitive metadata, treating glossary terms as optional and certifying without evidence. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.11 BigQuery Sharing

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Governed publication and subscription mechanism for analytical data and supported streams. |
| Architecture role | Implements an enterprise data marketplace without unmanaged extracts or broad producer-project access. |
| Benefits | Publisher control, linked datasets, cross-project or cross-organization discovery and reduced data copying. |
| Limitations | Location, object-type and feature restrictions apply; subscriber governance and product contracts remain necessary. |
| Security | Publish approved interfaces only, control exchange and listing administration, monitor subscribers and retain producer revocation capability. |
| Monitoring | Monitor listing changes, subscriptions, query usage, failed access, product freshness and unexpected consumer patterns. |
| Cost optimization | Prefer linked access to copies; publish only demanded products; retire unused listings and attribute producer costs. |
| Alternatives | Authorized views or datasets for internal sharing; exports for contractual offline exchange; APIs for operational interfaces. |
| Common pitfalls | Publishing raw datasets, omitting consumer terms, ignoring location alignment and assuming sharing transfers data-product support responsibility. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.12 Bigtable

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Operational wide-column store for high-throughput, low-latency key-based access. |
| Architecture role | Serves selected operational data products such as telemetry, time series, personalization or feature access. |
| Benefits | Horizontal scale, low-latency access, replication options and strong fit for sparse key-value or time-series patterns. |
| Limitations | No general relational joins; row-key design can create hotspots; query flexibility is intentionally limited. |
| Security | Use application profiles, IAM, private access, CMEK where required and tenant-aware row-key or access patterns. |
| Monitoring | Monitor node or cluster CPU, storage, latency, hotspot indicators, replication, garbage collection and request errors. |
| Cost optimization | Design row keys from access patterns, use autoscaling where appropriate and apply garbage-collection policies. |
| Alternatives | Spanner for relational transactions; BigQuery for analytics; cache services for ephemeral data. |
| Common pitfalls | Sequential hot keys, scanning without key bounds, treating Bigtable as a warehouse and failing to load-test the key design. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.13 Spanner

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Globally scalable relational database for mission-critical transactional applications needing strong consistency. |
| Architecture role | Supports operational data products that require relational semantics, high availability and scale beyond conventional regional databases. |
| Benefits | Managed distributed transactions, relational SQL, horizontal scale and multi-region configurations. |
| Limitations | Schema and query design differ from traditional databases; configuration and cost must match real global requirements. |
| Security | Use database roles and IAM, private access, CMEK where required, least-privilege applications and audit logs. |
| Monitoring | Monitor CPU, latency, storage, lock contention, query statistics, split behavior, replication and availability. |
| Cost optimization | Select configuration deliberately, use interleaving and indexes carefully, tune queries and avoid overprovisioning. |
| Alternatives | AlloyDB or Cloud SQL for regional PostgreSQL; Bigtable for key-value; BigQuery for analytics. |
| Common pitfalls | Selecting Spanner for brand value, importing monolithic schemas unchanged and ignoring commit-latency geography. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.14 AlloyDB

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Managed PostgreSQL-compatible database for demanding regional operational workloads. |
| Architecture role | Hosts operational applications, serving APIs and metadata services that need PostgreSQL compatibility and strong performance or HA. |
| Benefits | PostgreSQL ecosystem compatibility, managed high availability, read pools and analytical acceleration capabilities. |
| Limitations | Regional database characteristics remain; connection management, failover and cross-region DR require design. |
| Security | Use private IP, database IAM where suitable, Secret Manager, CMEK where required and least-privilege database roles. |
| Monitoring | Monitor CPU, memory, storage, connections, replication lag, query latency, failover and backup status. |
| Cost optimization | Use connection pooling, right-size read pools, tune indexes and queries and manage backup retention. |
| Alternatives | Cloud SQL for simpler workloads; Spanner for global consistency or scale; Bigtable for key-value serving. |
| Common pitfalls | Direct internet exposure, unlimited connections, using replicas as backup and assuming PostgreSQL compatibility eliminates performance testing. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.15 Cloud KMS and Cloud HSM

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Central key-management services for CMEK and cryptographic-control requirements. |
| Architecture role | Provide separation of duties and customer-controlled key lifecycle for restricted data-platform assets. |
| Benefits | Central policy, auditability, rotation, hardware-backed keys through Cloud HSM and integration with supported services. |
| Limitations | Key unavailability can stop data access; location, service integration, permissions and rotation procedures require coordination. |
| Security | Separate key administrators from service users, restrict encrypt or decrypt use, monitor key access and protect deletion schedules. |
| Monitoring | Monitor denied access, unusual encrypt or decrypt use, disabled versions, rotation age and dependent-service failures. |
| Cost optimization | Use risk-based CMEK, minimize cross-project complexity and avoid keys where no control requirement exists. |
| Alternatives | Google-managed encryption for standard workloads; External Key Manager for external control requirements. |
| Common pitfalls | Universal CMEK without operating ownership, deleting keys before data expiry and granting broad cryptographic roles. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

## G.16 Sensitive Data Protection

| Assessment area | Enterprise guidance |
| --- | --- |
| Purpose | Discovery, inspection and transformation of sensitive data such as personal identifiers and regulated content. |
| Architecture role | Supports classification, tokenization, de-identification and privacy controls in ingestion and governance workflows. |
| Benefits | Managed detectors, custom info types, scalable inspection and transformation patterns. |
| Limitations | False positives and negatives require tuning; inspection cost and data movement must be controlled; it does not replace access governance. |
| Security | Use scoped service identities, protected templates, regional processing validation and strict access to findings. |
| Monitoring | Monitor job failures, inspection coverage, finding trends, template changes, transformation errors and cost. |
| Cost optimization | Scan representative samples and high-risk assets first; reuse templates; avoid rescanning unchanged large data without purpose. |
| Alternatives | Application-native validation, custom classifiers and third-party privacy tools. |
| Common pitfalls | Treating detection as proof of absence, storing findings with broad access and tokenizing without re-identification-key governance. |

**Production readiness evidence.** Approved service configuration, IAM and network design, quota validation, monitoring dashboard, alert routes, recovery procedure, cost owner and service-specific load and security test results.

# Closing Recommendation

Implement the platform in capability slices rather than launching all services simultaneously. Establish the source registry, contract model, layer standards, catalog, access model, quality gates, product scorecard and cost allocation before scaling ingestion. Deliver one priority domain that exercises batch, CDC and streaming only where justified. Certify a small number of products, prove replay and recovery, measure unit cost, then expand through reusable modules and domain ownership.

The platform is successful when consumers choose governed products because they are easier and more reliable than bypassing the platform. Architecture controls must therefore be automated, observable and proportional to risk. Governance that cannot be executed in engineering workflows will be ignored; engineering that cannot provide evidence will not be trusted.
