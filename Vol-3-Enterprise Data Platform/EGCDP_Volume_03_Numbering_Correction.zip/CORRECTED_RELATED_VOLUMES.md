# Corrected Related Volumes - Volume 03

Volume 01 Executive Architecture Guide; Volume 02 Google Cloud Landing Zone; Volume 04 Data Engineering Pipelines; Volume 05 Enterprise Data Mesh; Volume 08 Security and Zero Trust; Volume 11 Monitoring, SRE and Operations
