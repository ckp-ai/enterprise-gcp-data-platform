# Workflows API-centric orchestration starter

## Purpose
Workflows API-centric orchestration starter.

## Prerequisites
Enabled Workflows and target service APIs, dedicated execution identity and approved private/API access path.

## Configuration
Pass project, region, immutable template spec and parameters. Add explicit retry policies only for idempotent calls.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
Deploy the YAML through CI/CD and invoke with authenticated service-to-service calls.

## Rollback instructions
Redeploy prior workflow revision and cancel only executions proven safe to cancel.

## Production limitations
Long-running service polling, compensation and error branches should be added for the workload; avoid using Workflows as a general data-processing engine.
