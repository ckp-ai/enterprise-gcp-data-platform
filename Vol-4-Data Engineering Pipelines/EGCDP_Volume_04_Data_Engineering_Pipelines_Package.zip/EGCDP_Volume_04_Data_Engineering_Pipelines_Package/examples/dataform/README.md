# Dataform SQLX incremental transformation and assertions

## Purpose
Dataform SQLX incremental transformation and assertions.

## Prerequisites
Dataform repository, BigQuery datasets, repository identity and release/workflow configuration.

## Configuration
Set project and location per regional data plane. Use environment-specific compilation variables and protected Git branches.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
Compile, execute assertions in test, create a release configuration and promote the same commit to production.

## Rollback instructions
Revert to the last approved commit and rerun the affected actions into controlled partitions; restore snapshots if a destructive change escaped.

## Production limitations
Incremental boundary logic must be designed for late updates; validate Dataform Core version and current regional/API behavior.
