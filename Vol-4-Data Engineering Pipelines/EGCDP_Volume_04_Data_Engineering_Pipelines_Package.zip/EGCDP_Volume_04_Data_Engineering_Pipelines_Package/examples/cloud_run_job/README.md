# Cloud Run Job utility starter

## Purpose
Cloud Run Job utility starter.

## Prerequisites
Artifact Registry, Cloud Run Jobs, dedicated runtime service account and target BigQuery control table.

## Configuration
RUN_ID and CONTROL_TABLE are environment variables; secrets belong in Secret Manager.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
Build an immutable image, scan it, deploy a versioned job and execute from Workflows or Managed Airflow.

## Rollback instructions
Point the job to the previous immutable image digest and execute compensating logic if required.

## Production limitations
Not for sustained distributed data processing; use for bounded utilities and control-plane tasks.
