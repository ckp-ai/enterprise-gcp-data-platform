import logging, os
from google.cloud import bigquery

def main():
    run_id=os.environ['RUN_ID']; table=os.environ['CONTROL_TABLE']
    bigquery.Client().insert_rows_json(table,[{'run_id':run_id,'status':'STARTED'}],row_ids=[run_id])
    logging.info('control_record_written',extra={'run_id':run_id})
if __name__=='__main__': logging.basicConfig(level=logging.INFO); main()
