terraform { required_version = ">= 1.7" required_providers { google = { source="hashicorp/google" version="~> 6.0" } } }
variable "project_id" { type=string }
variable "region" { type=string }
resource "google_pubsub_topic" "orders" { project=var.project_id; name="sales-orders-v1" labels={domain="sales",environment="prod"} }
resource "google_pubsub_topic" "orders_dlq" { project=var.project_id; name="sales-orders-v1-dlq" }
resource "google_pubsub_subscription" "orders" { project=var.project_id; name="sales-orders-dataflow"; topic=google_pubsub_topic.orders.id
  ack_deadline_seconds=60
  retry_policy { minimum_backoff="10s" maximum_backoff="300s" }
  dead_letter_policy { dead_letter_topic=google_pubsub_topic.orders_dlq.id max_delivery_attempts=10 }
}
resource "google_storage_bucket" "temp" { project=var.project_id; name="${var.project_id}-dataflow-temp"; location=var.region; uniform_bucket_level_access=true; public_access_prevention="enforced"; lifecycle_rule { condition { age=7 } action { type="Delete" } } }
