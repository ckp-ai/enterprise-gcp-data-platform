# Terraform pipeline-platform baseline

## Purpose
Terraform pipeline-platform baseline.

## Prerequisites
Approved Terraform backend, project factory output, provider credentials through federation and organization policies.

## Configuration
Supply project and region through environment-specific configuration; add CMEK and perimeter controls where mandated.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
Run fmt, validate, policy tests, plan review and controlled apply.

## Rollback instructions
Apply the previous approved module/version and use state recovery procedures; never edit remote state manually.

## Production limitations
Provider arguments, service-agent IAM, quotas and region support must be validated at implementation time.
