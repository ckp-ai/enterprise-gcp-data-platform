# Cloud Build pipeline starter

## Purpose
Cloud Build pipeline starter.

## Prerequisites
Private pool where required, Artifact Registry, source connection, build identity and security scanners.

## Configuration
_IMAGE is a substitution; use immutable commit/tag/digest and environment approvals.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
Trigger on protected branches; promote the same artifact digest through environments.

## Rollback instructions
Redeploy the prior digest and revert source through reviewed change control.

## Production limitations
Add SAST, dependency, container, IaC, policy, provenance and integration stages to meet enterprise supply-chain requirements.
