DECLARE run_id STRING DEFAULT @run_id;
BEGIN TRANSACTION;
UPDATE `egcdp-sales-prd.sales_curated.customer_dim` t
SET effective_to = s.change_ts, is_current = FALSE, updated_run_id = run_id
FROM `egcdp-sales-prd.sales_stage.customer_changes` s
WHERE t.customer_id=s.customer_id AND t.is_current AND t.row_hash!=s.row_hash;
INSERT `egcdp-sales-prd.sales_curated.customer_dim`
(customer_id,name,segment,effective_from,effective_to,is_current,row_hash,created_run_id)
SELECT customer_id,name,segment,change_ts,TIMESTAMP('9999-12-31'),TRUE,row_hash,run_id
FROM `egcdp-sales-prd.sales_stage.customer_changes` s
WHERE NOT EXISTS (SELECT 1 FROM `egcdp-sales-prd.sales_curated.customer_dim` t WHERE t.customer_id=s.customer_id AND t.is_current AND t.row_hash=s.row_hash);
COMMIT TRANSACTION;
