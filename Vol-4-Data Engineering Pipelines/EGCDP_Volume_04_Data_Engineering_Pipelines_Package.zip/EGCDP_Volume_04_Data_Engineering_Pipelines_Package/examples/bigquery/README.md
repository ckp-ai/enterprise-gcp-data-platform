# BigQuery SCD2 MERGE and reconciliation SQL

## Purpose
BigQuery SCD2 MERGE and reconciliation SQL.

## Prerequisites
Staging and curated tables with matching locations, parameterized execution identity and tested table snapshots.

## Configuration
Bind run_id parameters; never concatenate untrusted identifiers or values.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
Deploy SQL through Dataform or versioned orchestration and require dry-run/validation in non-production.

## Rollback instructions
Restore the prior snapshot or rerun the previous statement against the affected partition after root-cause approval.

## Production limitations
Concurrency, transaction scope, partition pruning and high-volume change patterns require workload tests.
