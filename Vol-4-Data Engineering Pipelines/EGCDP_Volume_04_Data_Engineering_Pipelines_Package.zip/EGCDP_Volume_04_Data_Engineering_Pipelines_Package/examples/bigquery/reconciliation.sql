SELECT @run_id run_id,
  COUNTIF(source_count != target_count) count_mismatch_partitions,
  SUM(ABS(source_amount-target_amount)) absolute_amount_difference
FROM `egcdp-ops-prd.pipeline_control.daily_reconciliation`
WHERE run_id=@run_id;
