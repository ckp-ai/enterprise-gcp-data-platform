# Pipeline contract YAML

## Purpose
Pipeline contract YAML.

## Prerequisites
Registered data product, owner, schema, security classification and approved SLOs.

## Configuration
Review values with producer, consumer, platform, security, privacy, SRE and FinOps stakeholders.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
Validate contract in CI and publish approved metadata to the catalog/control plane.

## Rollback instructions
Publish a new version or restore the previous contract; incompatible changes require a migration window.

## Production limitations
The schema is an enterprise example, not a Google Cloud product schema.
