import json, uuid
from google.cloud import pubsub_v1

def publish(project,topic,payload):
    event=dict(payload); event.setdefault('event_id',str(uuid.uuid4()))
    data=json.dumps(event,separators=(',',':')).encode()
    fut=pubsub_v1.PublisherClient().publish(f'projects/{project}/topics/{topic}',data=data,schema_version='1.0',data_product='sales.orders')
    return fut.result(timeout=30)
