import json, logging
from google.cloud import pubsub_v1

def run(subscription):
    client=pubsub_v1.SubscriberClient(); path=client.subscription_path(*subscription.split('/')[1::2])
    def cb(message):
        try:
            e=json.loads(message.data); assert e.get('event_id'); process_idempotently(e); message.ack()
        except ValueError: logging.exception('poison'); message.ack()
        except Exception: logging.exception('retryable'); message.nack()
    with client: client.subscribe(path,callback=cb).result()
def process_idempotently(event): pass
