# Pub/Sub publisher and subscriber starters

## Purpose
Pub/Sub publisher and subscriber starters.

## Prerequisites
Topic, pull subscription, schema/contract, runtime identities, retry policy and dead-letter topic.

## Configuration
Set fully qualified resources and required message attributes. Consumer must persist event_id before acknowledging.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
Build and deploy subscriber as a private Cloud Run service/job or GKE workload through CI/CD.

## Rollback instructions
Route traffic to previous revision; retain subscriptions and seek/replay only under approved runbook.

## Production limitations
Exactly-once subscription delivery does not remove the need for end-to-end idempotency, particularly across external side effects.
