terraform { required_providers { google = { source = "hashicorp/google" } } }
variable "project_id" { type=string }
variable "region" { type=string }
variable "source_profile_id" { type=string }
variable "bigquery_profile_id" { type=string }
resource "google_datastream_stream" "orders" {
  project=var.project_id; location=var.region; stream_id="sales-orders-cdc"
  source_config { source_connection_profile=var.source_profile_id mysql_source_config { include_objects { mysql_databases { database="sales" mysql_tables { table="orders" } } } } } }
  destination_config { destination_connection_profile=var.bigquery_profile_id bigquery_destination_config { single_target_dataset { dataset_id="egcdp-sales-prd:sales_replica" } data_freshness="900s" } }
  backfill_all {}
}
