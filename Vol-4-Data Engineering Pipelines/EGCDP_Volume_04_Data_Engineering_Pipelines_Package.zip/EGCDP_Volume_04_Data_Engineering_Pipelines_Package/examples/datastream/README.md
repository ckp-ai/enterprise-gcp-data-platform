# Datastream-to-BigQuery CDC Terraform starter

## Purpose
Datastream-to-BigQuery CDC Terraform starter.

## Prerequisites
Source database prerequisites, private connectivity, connection profiles, BigQuery destination dataset and Datastream service identity.

## Configuration
Supply project, region and existing connection profile IDs from protected environment configuration.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
Plan, review and apply through Terraform CI/CD; validate stream before starting and monitor backfill and CDC lag.

## Rollback instructions
Pause or stop the stream, preserve source log position and apply the prior approved configuration; reconcile before resuming.

## Production limitations
Resource arguments and supported source/destination features must be validated against current provider and service documentation.
