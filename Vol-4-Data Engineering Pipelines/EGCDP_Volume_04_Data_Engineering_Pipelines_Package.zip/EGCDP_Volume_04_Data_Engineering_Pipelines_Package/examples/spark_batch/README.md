# Managed Service for Apache Spark batch curation

## Purpose
Managed Service for Apache Spark batch curation.

## Prerequisites
PySpark job in Cloud Storage or Artifact Registry, BigQuery connector, private subnet and dedicated runtime identity.

## Configuration
Set region, subnet, service account, immutable input URI, output table and unique run ID.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
Submit through CI/CD or orchestration using the serverless batch API. Pin runtime and dependency versions.

## Rollback instructions
Run the previous artifact into a new staging partition and swap/merge after validation.

## Production limitations
Validate connector/runtime compatibility, shuffle volume, executor sizing, quotas and regional availability.
