import argparse, logging
from pyspark.sql import SparkSession, functions as F

def main():
    p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--output',required=True); p.add_argument('--run-id',required=True); a=p.parse_args()
    spark=SparkSession.builder.appName('egcdp-curation').getOrCreate()
    try:
        df=spark.read.parquet(a.input)
        required={'order_id','customer_id','amount','business_date'}
        missing=required-set(df.columns)
        if missing: raise ValueError(f'missing_columns={sorted(missing)}')
        out=(df.dropDuplicates(['order_id']).withColumn('run_id',F.lit(a.run_id)).withColumn('processed_at',F.current_timestamp()))
        out.write.format('bigquery').option('table',a.output).mode('append').save()
    except Exception: logging.exception('spark_job_failed'); raise
    finally: spark.stop()
if __name__=='__main__': main()
