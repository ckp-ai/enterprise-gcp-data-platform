#!/usr/bin/env bash
set -euo pipefail
: "${REGION:?}" "${SUBNET:?}" "${SERVICE_ACCOUNT:?}" "${INPUT_URI:?}" "${OUTPUT_TABLE:?}" "${RUN_ID:?}"
gcloud dataproc batches submit pyspark job.py --region="$REGION" --subnet="$SUBNET" --service-account="$SERVICE_ACCOUNT" -- --input="$INPUT_URI" --output="$OUTPUT_TABLE" --run-id="$RUN_ID"
