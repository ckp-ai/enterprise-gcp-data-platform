#!/usr/bin/env bash
set -euo pipefail
: "${SUBSCRIPTION:?}" "${SNAPSHOT:?}" "${CHANGE_TICKET:?}" "${REPLAY_ID:?}"
echo "Replay ${REPLAY_ID} approved by ${CHANGE_TICKET}"
gcloud pubsub subscriptions seek "$SUBSCRIPTION" --snapshot="$SNAPSHOT"
