# Replay and backfill runbook scripts

## Purpose
Replay and backfill runbook scripts.

## Prerequisites
Approved incident/change ticket, immutable source, retained Pub/Sub snapshot or Dataflow template, scoped input and destination.

## Configuration
Export all required variables from a protected change record; verify region and blast radius.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
Execute with two-person approval, observe dedicated dashboards and reconcile before publishing.

## Rollback instructions
Seek to a retained safe point or restore target snapshots; stop the replay if SLO/security gates fail.

## Production limitations
Replay availability is bounded by retention and source log availability; scripts must be adapted to environment identifiers and current CLI behavior.
