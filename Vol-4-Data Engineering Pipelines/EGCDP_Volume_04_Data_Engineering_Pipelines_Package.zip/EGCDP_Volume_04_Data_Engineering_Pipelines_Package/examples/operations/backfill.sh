#!/usr/bin/env bash
set -euo pipefail
: "${TEMPLATE_SPEC:?}" "${PROJECT:?}" "${REGION:?}" "${INPUT_PATTERN:?}" "${OUTPUT_TABLE:?}" "${RUN_ID:?}"
gcloud dataflow flex-template run "backfill-${RUN_ID}" --project="$PROJECT" --region="$REGION" --template-file-gcs-location="$TEMPLATE_SPEC" --parameters="input_pattern=${INPUT_PATTERN},output_table=${OUTPUT_TABLE},run_id=${RUN_ID}"
