# Managed Airflow DAG for governed batch orchestration

## Purpose
Managed Airflow DAG for governed batch orchestration.

## Prerequisites
Managed Airflow environment, provider packages, private access, approved connection model and Dataflow/BigQuery runtime identities.

## Configuration
Use environment variables and Secret Manager-backed connections; set owner, schedule, retry, timeout, concurrency and tags.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
DAGs are deployed through CI/CD after parse, unit and integration tests; production deploy uses immutable commit evidence.

## Rollback instructions
Revert DAG code to prior commit and redeploy; do not delete successful task history or manually mark failed data-quality gates as successful.

## Production limitations
DAG is a starter; production requires callbacks, lineage, SLA/SLO integration, pools, data intervals and run-ledger updates.
