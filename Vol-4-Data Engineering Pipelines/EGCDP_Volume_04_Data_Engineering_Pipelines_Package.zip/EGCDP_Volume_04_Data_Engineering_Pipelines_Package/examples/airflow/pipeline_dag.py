from datetime import datetime, timedelta
from airflow import DAG
from airflow.providers.google.cloud.operators.dataflow import DataflowStartFlexTemplateOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryCheckOperator
from airflow.utils.trigger_rule import TriggerRule

DEFAULT={'owner':'sales-data-product','retries':2,'retry_delay':timedelta(minutes=5),'execution_timeout':timedelta(hours=2)}
with DAG('sales_orders_daily',start_date=datetime(2026,1,1),schedule='0 3 * * *',catchup=False,max_active_runs=1,default_args=DEFAULT,tags=['sales','tier1']) as dag:
    ingest=DataflowStartFlexTemplateOperator(task_id='ingest',location='us-central1',body={'launchParameter':{'jobName':'sales-orders-{{ ds_nodash }}','containerSpecGcsPath':'gs://egcdp-templates-prd/dataflow/orders/spec.json','parameters':{'input_pattern':'gs://egcdp-sales-landing-prd/orders/{{ ds_nodash }}/*.json','output_table':'egcdp-sales-prd:sales_stage.orders'}}})
    validate=BigQueryCheckOperator(task_id='validate',sql='SELECT COUNT(*)>0 FROM `egcdp-sales-prd.sales_stage.orders` WHERE business_date="{{ ds }}"',use_legacy_sql=False,location='us-central1')
    ingest >> validate
