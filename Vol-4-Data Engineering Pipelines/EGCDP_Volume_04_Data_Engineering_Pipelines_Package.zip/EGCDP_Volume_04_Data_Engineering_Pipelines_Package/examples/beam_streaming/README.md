# Apache Beam/Dataflow streaming pipeline

## Purpose
Apache Beam/Dataflow streaming pipeline.

## Prerequisites
Python, Apache Beam SDK, Pub/Sub subscription, existing BigQuery target and DLQ tables, Artifact Registry and Dataflow worker service account.

## Configuration
Pass project, region, subscription, target tables, staging and temp locations as runtime parameters. Do not hardcode secrets or project IDs.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
Build an immutable Flex Template image, publish metadata to Cloud Storage and deploy through the approved CI/CD pipeline.

## Rollback instructions
Launch the previously approved template version as a replacement job; drain the superseded job after validation.

## Production limitations
Example demonstrates key controls but workload-specific schemas, windowing, state TTL, throughput tuning, quotas and regional support require validation.
