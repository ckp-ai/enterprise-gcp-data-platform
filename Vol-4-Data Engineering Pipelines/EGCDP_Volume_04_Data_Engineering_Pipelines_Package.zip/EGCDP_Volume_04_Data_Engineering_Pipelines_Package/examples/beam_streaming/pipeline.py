import argparse, json, logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions

class ParseValidate(beam.DoFn):
    def process(self, raw):
        try:
            obj=json.loads(raw.decode('utf-8') if isinstance(raw,bytes) else raw)
            for f in ('event_id','event_time','customer_id'):
                if not obj.get(f): raise ValueError(f'missing_{f}')
            yield beam.pvalue.TaggedOutput('valid',obj)
        except Exception as exc:
            logging.exception('validation_failed')
            yield beam.pvalue.TaggedOutput('invalid',{'raw':str(raw)[:4096],'reason':str(exc)})

def run(argv=None):
    ap=argparse.ArgumentParser(); ap.add_argument('--input_subscription',required=True); ap.add_argument('--output_table',required=True); ap.add_argument('--dead_letter_table',required=True); ap.add_argument('--project'); ap.add_argument('--region'); ap.add_argument('--temp_location'); ap.add_argument('--staging_location'); args,beam_args=ap.parse_known_args(argv)
    opts=PipelineOptions(beam_args,project=args.project,region=args.region,temp_location=args.temp_location,staging_location=args.staging_location,save_main_session=True)
    opts.view_as(StandardOptions).streaming=True
    with beam.Pipeline(options=opts) as p:
        parsed=(p|'Read'>>beam.io.ReadFromPubSub(subscription=args.input_subscription,with_attributes=False)|'Parse'>>beam.ParDo(ParseValidate()).with_outputs('valid','invalid'))
        valid=(parsed.valid|'Key'>>beam.Map(lambda x:(x['event_id'],x))|'Deduplicate'>>beam.CombinePerKey(lambda xs:list(xs)[0])|'Values'>>beam.Values())
        valid|'WriteBQ'>>beam.io.WriteToBigQuery(args.output_table,method=beam.io.WriteToBigQuery.Method.STORAGE_WRITE_API,create_disposition=beam.io.BigQueryDisposition.CREATE_NEVER,write_disposition=beam.io.BigQueryDisposition.WRITE_APPEND)
        parsed.invalid|'WriteDLQ'>>beam.io.WriteToBigQuery(args.dead_letter_table,method=beam.io.WriteToBigQuery.Method.FILE_LOADS)
if __name__=='__main__': logging.getLogger().setLevel(logging.INFO); run()
