import argparse, logging
import apache_beam as beam
from apache_beam.options.pipeline_options import PipelineOptions

def parse(line):
    parts=line.rstrip().split(',')
    if len(parts)!=4: raise ValueError('invalid_column_count')
    return {'order_id':parts[0],'customer_id':parts[1],'amount':float(parts[2]),'business_date':parts[3]}

def run(argv=None):
    ap=argparse.ArgumentParser(); ap.add_argument('--input_pattern',required=True); ap.add_argument('--output_table',required=True); args,extra=ap.parse_known_args(argv)
    with beam.Pipeline(options=PipelineOptions(extra,save_main_session=True)) as p:
        (p|'Read'>>beam.io.ReadFromText(args.input_pattern,skip_header_lines=1)|'Parse'>>beam.Map(parse)|'Write'>>beam.io.WriteToBigQuery(args.output_table,method='FILE_LOADS',write_disposition='WRITE_APPEND',create_disposition='CREATE_NEVER'))
if __name__=='__main__': logging.getLogger().setLevel(logging.INFO); run()
