# Apache Beam/Dataflow batch ingestion

## Purpose
Apache Beam/Dataflow batch ingestion.

## Prerequisites
Validated file manifest and Cloud Storage input, existing BigQuery staging table and Dataflow runtime identity.

## Configuration
Provide immutable input pattern and target table; use manifest IDs and run IDs in orchestration metadata.

## Error handling and logging
All failures are classified as retryable or non-retryable. Structured logs contain pipeline ID, run ID, data product, region and error reason without exposing payload data. Poison records are routed to quarantine or a dead-letter path.

## Security considerations
Use a dedicated runtime service account, no user-managed keys, least-privilege IAM, approved regions, private access, VPC Service Controls where supported, Secret Manager for secrets and CMEK where mandated by classification.

## Testing instructions
Run unit tests, contract tests, integration tests against isolated datasets, data-quality assertions and representative performance tests before promotion.

## Deployment instructions
Deploy as a Flex Template and invoke with a unique run ID from Managed Airflow or Workflows.

## Rollback instructions
Re-run the prior template version into a new staging partition, validate, then atomically replace or MERGE the affected partition.

## Production limitations
CSV parsing is illustrative; production uses explicit schemas, escaped-field handling, quarantine output, checksum validation and scale tests.
