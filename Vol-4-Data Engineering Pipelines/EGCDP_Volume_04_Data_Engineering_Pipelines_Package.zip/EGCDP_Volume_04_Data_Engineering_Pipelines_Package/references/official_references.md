# Official references

- [Dataflow pipeline best practices](https://cloud.google.com/dataflow/docs/guides/pipeline-best-practices)
- [Dataflow streaming modes](https://cloud.google.com/dataflow/docs/guides/streaming-modes)
- [Dataflow Flex Templates](https://cloud.google.com/dataflow/docs/guides/templates/configuring-flex-templates)
- [Managed Service for Apache Spark](https://cloud.google.com/dataproc-serverless/docs)
- [Dataform SQL workflows](https://cloud.google.com/dataform/docs/sql-workflows)
- [Dataform assertions](https://cloud.google.com/dataform/docs/assertions)
- [Managed Service for Apache Airflow](https://cloud.google.com/composer/docs)
- [Pub/Sub exactly-once delivery](https://cloud.google.com/pubsub/docs/exactly-once-delivery)
- [Pub/Sub dead-letter topics](https://cloud.google.com/pubsub/docs/dead-letter-topics)
- [Datastream BigQuery destination](https://cloud.google.com/datastream/docs/configure-bigquery-destination)
- [BigQuery Storage Write API](https://cloud.google.com/bigquery/docs/write-api)

Validate product names, lifecycle, regions, quotas, IAM, VPC Service Controls, CMEK, SLA and pricing at implementation time.
